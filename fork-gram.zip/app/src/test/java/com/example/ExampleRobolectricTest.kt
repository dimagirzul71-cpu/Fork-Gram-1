package com.example

import android.content.Context
import android.net.Uri
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.ForkGramDatabase
import com.example.data.local.UserPreferences
import com.example.data.model.ChatType
import com.example.data.model.GiftKind
import com.example.data.model.MessageKind
import com.example.data.model.PollData
import com.example.data.repository.ForkGramRepository
import com.example.ui.components.TelegramChatBubbleShape
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Fork Gram", appName)
    }

    @Test
    fun `email registration seeds workspace gifts and nft usernames`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, ForkGramDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val repo = ForkGramRepository(context, db, UserPreferences(context), remoteApi = null)

        val account = repo.completeAuthOrRegister(
            rawEmail = "tester@forkgram.me",
            firstName = "Дмитрий",
            lastName = "Волков",
            avatarUri = null
        )
        assertEquals("tester@forkgram.me", account.email)
        assertEquals("Дмитрий Волков", account.fullName)
        assertEquals(1000L, account.starsBalance)
        assertTrue(account.isPremium)
        assertEquals(100.0, account.gramBalance, 0.01)
        assertEquals(1, account.level)
        assertTrue(repo.observeGifts("tester@forkgram.me").first().isEmpty())

        val chats = repo.observeChats("tester@forkgram.me").first()
        assertEquals(2, chats.size)
        assertTrue(chats.any { it.chatType == ChatType.SERVICE && it.title == "Fork Gram" })
        assertTrue(chats.any { it.chatType == ChatType.SAVED && it.title == "Избранное" })

        val savedChat = chats.first { it.chatType == ChatType.SAVED }
        repo.saveChatDraft(savedChat.id, "Черновик текста")
        val withDraft = repo.observeChat(savedChat.id).first()
        assertEquals("Черновик текста", withDraft?.draftText)

        repo.sendTextMessage("tester@forkgram.me", savedChat.id, "Тест сообщения", null)
        repo.sendTextMessage("tester@forkgram.me", savedChat.id, "Тихое сообщение", null, isSilent = true)
        repo.sendTextMessage("tester@forkgram.me", savedChat.id, "Отложенное сообщение", null, scheduleDelayMinutes = 10)
        val afterSend = repo.observeChat(savedChat.id).first()
        assertEquals("", afterSend?.draftText)

        val savedMessages = repo.observeMessages(savedChat.id).first()
        assertTrue(savedMessages.any { it.text == "Тест сообщения" && it.isOutgoing })
        assertTrue(savedMessages.any { it.text == "Тихое сообщение" && it.timestampText.startsWith("🔇") })
        assertTrue(savedMessages.any { it.text == "Отложенное сообщение" && it.timestampText.startsWith("⏰") })

        repo.sendPollMessage("tester@forkgram.me", savedChat.id, "Лучший мессенджер?", listOf("Fork Gram", "Другой"))
        val pollMsg = repo.observeMessages(savedChat.id).first().firstOrNull { it.kind == MessageKind.POLL }
        assertNotNull(pollMsg)
        repo.votePoll("tester@forkgram.me", pollMsg!!.id, 0)
        val updatedPollMsg = repo.observeMessages(savedChat.id).first().first { it.id == pollMsg.id }
        val parsedPoll = PollData.fromJson(updatedPollMsg.text)
        assertNotNull(parsedPoll)
        assertEquals(1, parsedPoll!!.totalVotes)

        val mintOk = repo.buyOrMintNftUsername("tester@forkgram.me", customHandle = "forkdev")
        assertTrue(mintOk)
        val updatedAccount = repo.observeAccount("tester@forkgram.me").first()
        assertNotNull(updatedAccount)
        assertEquals("@forkdev", updatedAccount?.activeNftUsername)

        val giftOk = repo.purchaseAndSendGift(
            ownerEmail = "tester@forkgram.me",
            giftKind = GiftKind.PLUSH_PEPE,
            asNft = false,
            targetChatId = null,
            giftComment = "Тест подарка"
        )
        assertTrue(giftOk)

        val gifts = repo.observeGifts("tester@forkgram.me").first()
        val upgradable = gifts.firstOrNull { !it.isNft }
        assertNotNull(upgradable)
        val upgraded = repo.upgradeGiftToNft("tester@forkgram.me", upgradable!!.id)
        assertNotNull(upgraded)
        assertTrue(upgraded!!.isNft)
        assertEquals("PlushPepe", GiftKind.PLUSH_PEPE.linkSlug)
        assertTrue(upgraded.nftUrl.startsWith("http://forkgram.xsph.ru/nft/"))
        assertTrue(upgraded.forkGramNftUrl.startsWith("http://forkgram.xsph.ru/nft/"))

        repo.createGiftCollection("tester@forkgram.me", "Редкие")
        repo.assignGiftToCollection(upgraded.id, "Редкие")
        val collections = repo.observeGiftCollections("tester@forkgram.me").first()
        assertTrue(collections.any { it.name == "Редкие" })
        db.close()
    }

    @Test
    fun `profile post lifecycle publishes archives and deletes`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, ForkGramDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val repo = ForkGramRepository(context, db, UserPreferences(context), remoteApi = null)
        repo.completeAuthOrRegister("posttest@forkgram.me", "Анна", "", null)

        val tempImg = File(context.cacheDir, "sample_post.jpg").apply {
            writeBytes(byteArrayOf(1, 2, 3, 4, 5, 6))
        }
        val post = repo.publishProfilePost(
            ownerEmail = "posttest@forkgram.me",
            sourceUri = Uri.fromFile(tempImg),
            caption = "Первый кадр"
        )
        assertNotNull(post)
        assertFalse(post!!.isArchived)

        val activePosts = repo.observeProfilePosts("posttest@forkgram.me").first()
        assertEquals(1, activePosts.size)
        assertEquals("Первый кадр", activePosts.first().caption)

        repo.toggleArchiveProfilePost("posttest@forkgram.me", post.id)
        val archivedPosts = repo.observeProfilePosts("posttest@forkgram.me").first()
        assertTrue(archivedPosts.first().isArchived)

        repo.deleteProfilePost("posttest@forkgram.me", post.id)
        val afterDelete = repo.observeProfilePosts("posttest@forkgram.me").first()
        assertTrue(afterDelete.isEmpty())
        db.close()
    }

    @Test
    fun `cache computation and cleanup removes cached files`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, ForkGramDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val repo = ForkGramRepository(context, db, UserPreferences(context), remoteApi = null)

        val cachedFile = File(context.cacheDir, "voice_sample.m4a").apply {
            writeBytes(ByteArray(2048) { 7 })
        }
        val beforeClear = repo.computeCacheBytes()
        assertTrue(beforeClear >= 2048L)

        val afterClear = repo.clearAppCache()
        assertFalse(cachedFile.exists())
        assertTrue(afterClear < beforeClear)
        db.close()
    }

    @Test
    fun `telegram bubble shape creates valid outlines with and without tails`() {
        val density = Density(2f)
        val outgoingWithTail = TelegramChatBubbleShape(isOutgoing = true, hasTail = true, isFirstInGroup = true)
            .createOutline(Size(400f, 120f), LayoutDirection.Ltr, density)
        val incomingGroupedNoTail = TelegramChatBubbleShape(isOutgoing = false, hasTail = false, isFirstInGroup = false)
            .createOutline(Size(320f, 90f), LayoutDirection.Ltr, density)

        assertTrue(!outgoingWithTail.bounds.isEmpty)
        assertTrue(!incomingGroupedNoTail.bounds.isEmpty)
    }
}
