package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.outlined.AddAPhoto
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Archive
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.CardGiftcard
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.Unarchive
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.model.ChatThread
import com.example.data.model.GiftBackdrop
import com.example.data.model.GiftCollectionTab
import com.example.data.model.GiftKind
import com.example.data.model.GiftSymbol
import com.example.data.model.OwnedGift
import com.example.data.model.PeerProfileData
import com.example.data.model.ProfilePost
import com.example.data.model.UserAccount
import com.example.ui.components.AvatarView
import com.example.ui.components.GiftDetailBottomSheet
import com.example.ui.components.GiftShopBottomSheet
import com.example.ui.components.TelegramOutlinedField
import com.example.ui.components.TelegramQrDialog
import com.example.ui.svg.AnimatedTelegramGift
import com.example.ui.svg.SvgGramGemIcon
import com.example.ui.svg.SvgHexLevelBadge
import com.example.ui.svg.SvgStarIcon
import com.example.ui.svg.TelegramGiftBackdropBox
import com.example.ui.theme.DangerRed
import com.example.ui.theme.GramCyan
import com.example.ui.theme.LocalForkPalette
import com.example.ui.theme.TgBlue
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.sin

@Composable
fun ProfileScreen(
    account: UserAccount?,
    gifts: List<OwnedGift>,
    collections: List<GiftCollectionTab>,
    posts: List<ProfilePost> = emptyList(),
    allChats: List<ChatThread> = emptyList(),
    onUpdateProfile: (firstName: String, lastName: String, username: String, bio: String, birthday: String?, avatarUri: String?) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenNftUsernames: () -> Unit,
    onSendGiftToSelf: (GiftKind, Boolean, String) -> Unit,
    onCreateGiftCollection: (String) -> Unit,
    onAssignGiftToCollection: (giftId: String, collectionName: String) -> Unit,
    onTogglePinGift: (String) -> Unit,
    onToggleWearGiftStatus: (String) -> Unit,
    onUpgradeGiftToNft: (String, (OwnedGift) -> Unit) -> Unit,
    onConvertGiftToStars: (String) -> Unit,
    onTransferGift: ((String, String) -> Unit)? = null,
    onListGiftOnFragment: ((String, Double) -> Unit)? = null,
    onPublishPost: (Uri, String) -> Unit = { _, _ -> },
    onToggleArchivePost: (String) -> Unit = {},
    onDeletePost: (String) -> Unit = {},
    onShowToast: (String) -> Unit = {},
    onLogout: () -> Unit
) {
    val palette = LocalForkPalette.current
    var selectedSegment by remember { mutableIntStateOf(2) }
    var selectedCollection by remember { mutableStateOf("Все подарки") }
    var showEditDialog by remember { mutableStateOf(false) }
    var showAddCollectionDialog by remember { mutableStateOf(false) }
    var showQrDialog by remember { mutableStateOf(false) }
    var showGiftShop by remember { mutableStateOf(false) }
    var selectedGiftDetail by remember { mutableStateOf<OwnedGift?>(null) }
    var selectedPostDetail by remember { mutableStateOf<ProfilePost?>(null) }
    var pendingPostUri by remember { mutableStateOf<Uri?>(null) }
    var pendingPostCaption by remember { mutableStateOf("") }
    var showMenu by remember { mutableStateOf(false) }

    val avatarPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null && account != null) {
            onUpdateProfile(
                account.firstName,
                account.lastName,
                account.username,
                account.bio,
                account.birthday,
                uri.toString()
            )
        }
    }

    val postPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            pendingPostUri = uri
            pendingPostCaption = ""
        }
    }

    val pinnedGifts = remember(gifts) { gifts.filter { it.isPinned }.take(6) }
    val wornGift = remember(gifts) { gifts.firstOrNull { it.isWornAsStatus } }
    val hasThemedHero = wornGift != null

    val orbitFloat by rememberInfiniteTransition(label = "profileOrbit").animateFloat(
        initialValue = 0f,
        targetValue = (Math.PI * 2.0).toFloat(),
        animationSpec = infiniteRepeatable(tween(4200), RepeatMode.Restart),
        label = "profileOrbitPhase"
    )

    val filteredGifts = remember(gifts, selectedCollection) {
        when (selectedCollection) {
            "Все подарки" -> gifts
            "NFT Коллекция" -> gifts.filter { it.isNft }
            "Обычные подарки" -> gifts.filter { !it.isNft }
            else -> gifts.filter { it.collectionName == selectedCollection }
        }
    }
    val visiblePosts = remember(posts, selectedSegment) {
        posts.filter { if (selectedSegment == 1) it.isArchived else !it.isArchived }
    }

    val listState = rememberLazyListState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
    ) {
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 148.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Dynamic 1:1 Telegram Profile Hero Header (Themed Gift Backdrop when worn + Orbiting Gifts + Action Pills)
            item {
                val primaryTextColor = if (hasThemedHero) Color.White else palette.textPrimary
                val secondaryTextColor = if (hasThemedHero) Color.White.copy(alpha = 0.82f) else palette.textSecondary

                val heroHeaderContent: @Composable () -> Unit = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .then(
                                if (hasThemedHero) {
                                    Modifier.background(
                                        Brush.verticalGradient(
                                            listOf(
                                                Color.Black.copy(alpha = 0.22f),
                                                Color.Black.copy(alpha = 0.60f)
                                            )
                                        )
                                    )
                                } else Modifier
                            )
                            .statusBarsPadding()
                            .padding(bottom = 18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { showQrDialog = true }) {
                                Icon(
                                    imageVector = Icons.Rounded.QrCode2,
                                    contentDescription = "QR-код",
                                    tint = primaryTextColor
                                )
                            }
                            Box {
                                IconButton(onClick = { showMenu = true }) {
                                    Icon(
                                        imageVector = Icons.Rounded.MoreVert,
                                        contentDescription = "Меню",
                                        tint = primaryTextColor
                                    )
                                }
                                DropdownMenu(
                                    expanded = showMenu,
                                    onDismissRequest = { showMenu = false },
                                    shape = RoundedCornerShape(18.dp),
                                    containerColor = palette.surface
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("Изменить профиль", color = palette.textPrimary) },
                                        onClick = {
                                            showMenu = false
                                            showEditDialog = true
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("NFT-юзернеймы", color = palette.textPrimary) },
                                        onClick = {
                                            showMenu = false
                                            onOpenNftUsernames()
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Выход", color = DangerRed) },
                                        onClick = {
                                            showMenu = false
                                            onLogout()
                                        }
                                    )
                                }
                            }
                        }

                        // Orbiting Animated Collectible Gifts around Avatar
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(142.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            val orbitOffsets = listOf(
                                Offset(-108f, -38f),
                                Offset(-134f, 16f),
                                Offset(-84f, 48f),
                                Offset(108f, -38f),
                                Offset(134f, 16f),
                                Offset(84f, 48f)
                            )
                            pinnedGifts.forEachIndexed { idx, gift ->
                                val off = orbitOffsets[idx % orbitOffsets.size]
                                val bobY = sin(orbitFloat + idx * 1.15f) * 3.5f
                                Box(
                                    modifier = Modifier
                                        .offset(x = off.x.dp, y = (off.y + bobY).dp)
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(
                                            Brush.radialGradient(
                                                listOf(
                                                    Color(gift.backdrop.centerHex).copy(alpha = 0.55f),
                                                    Color.Transparent
                                                )
                                            )
                                        )
                                        .clickable { selectedGiftDetail = gift },
                                    contentAlignment = Alignment.Center
                                ) {
                                    AnimatedTelegramGift(
                                        giftKind = gift.giftKind,
                                        phaseOffsetMs = idx * 180,
                                        editionNumber = gift.editionNumber,
                                        useRemoteEdition = gift.isNft,
                                        modifier = Modifier.size(38.dp)
                                    )
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .size(102.dp)
                                    .clip(CircleShape)
                                    .then(
                                        if (hasThemedHero) Modifier.border(2.5.dp, Color.White.copy(alpha = 0.35f), CircleShape)
                                        else Modifier
                                    )
                                    .clickable {
                                        avatarPicker.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                AvatarView(
                                    title = account?.fullName ?: "Fork Gram",
                                    avatarUri = account?.avatarUri,
                                    colorHex = 0xFF2AABEE,
                                    size = 98.dp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = account?.fullName ?: "Пользователь",
                                fontSize = 23.sp,
                                fontWeight = FontWeight.Bold,
                                color = primaryTextColor
                            )
                            if (account?.statusGiftKind != null) {
                                Spacer(modifier = Modifier.width(6.dp))
                                AnimatedTelegramGift(
                                    giftKind = account.statusGiftKind,
                                    modifier = Modifier.size(22.dp)
                                )
                            } else if (account?.isPremium == true) {
                                Spacer(modifier = Modifier.width(6.dp))
                                SvgStarIcon(modifier = Modifier.size(18.dp), color = if (hasThemedHero) Color.White else TgBlue)
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            SvgHexLevelBadge(
                                level = account?.level ?: 1,
                                modifier = Modifier.size(18.dp),
                                strokeColor = secondaryTextColor
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (wornGift != null) {
                                    "в сети • ${wornGift.modelName}"
                                } else {
                                    "в сети"
                                },
                                fontSize = 13.5.sp,
                                color = secondaryTextColor
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // 3 Translucent Liquid Glass Action Pills (Выбрать фото | Изменить | Настройки)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            ProfileActionPill(
                                icon = Icons.Outlined.AddAPhoto,
                                label = "Выбрать фото",
                                isOnThemedHero = hasThemedHero,
                                onClick = {
                                    avatarPicker.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                modifier = Modifier.weight(1f)
                            )
                            ProfileActionPill(
                                icon = Icons.Outlined.Edit,
                                label = "Изменить",
                                isOnThemedHero = hasThemedHero,
                                onClick = { showEditDialog = true },
                                modifier = Modifier.weight(1f)
                            )
                            ProfileActionPill(
                                icon = Icons.Outlined.Settings,
                                label = "Настройки",
                                isOnThemedHero = hasThemedHero,
                                onClick = onOpenSettings,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                if (wornGift != null) {
                    TelegramGiftBackdropBox(
                        backdrop = wornGift.backdrop,
                        symbol = wornGift.symbol,
                        radialCenterBiasY = 0.36f,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        heroHeaderContent()
                    }
                } else {
                    heroHeaderContent()
                }
            }

            // Info Card (Email + Username/NFT + Bio + Birthday)
            item {
                Spacer(modifier = Modifier.height(12.dp))
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = palette.surface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 13.dp)) {
                            Text(
                                text = account?.email ?: "",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium,
                                color = palette.textPrimary
                            )
                            Text(
                                text = "Электронная почта",
                                fontSize = 12.5.sp,
                                color = palette.textSecondary
                            )
                        }

                        HorizontalDivider(color = palette.divider, modifier = Modifier.padding(start = 16.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onOpenNftUsernames() }
                                .padding(horizontal = 16.dp, vertical = 13.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = account?.displayHandle ?: "@forkgram",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = if (account?.activeNftUsername != null) GramCyan else palette.textPrimary
                                    )
                                    if (account?.activeNftUsername != null) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        SvgGramGemIcon(modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "NFT",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = GramCyan
                                        )
                                    }
                                }
                                Text(
                                    text = if (account?.activeNftUsername != null) {
                                        "Коллекционный NFT-юзернейм"
                                    } else {
                                        "Имя пользователя"
                                    },
                                    fontSize = 12.5.sp,
                                    color = palette.textSecondary
                                )
                            }
                            IconButton(
                                onClick = { showQrDialog = true },
                                modifier = Modifier.size(34.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.QrCode2,
                                    contentDescription = "QR",
                                    tint = TgBlue,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }

                        if (!account?.bio.isNullOrBlank()) {
                            HorizontalDivider(color = palette.divider, modifier = Modifier.padding(start = 16.dp))
                            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 13.dp)) {
                                Text(
                                    text = account?.bio ?: "",
                                    fontSize = 15.sp,
                                    color = palette.textPrimary
                                )
                                Text(
                                    text = "О себе",
                                    fontSize = 12.5.sp,
                                    color = palette.textSecondary
                                )
                            }
                        }

                        HorizontalDivider(color = palette.divider, modifier = Modifier.padding(start = 16.dp))
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showEditDialog = true }
                                .padding(horizontal = 16.dp, vertical = 13.dp)
                        ) {
                            Text(
                                text = account?.birthday?.takeIf { it.isNotBlank() } ?: "Добавить день рождения",
                                fontSize = 15.sp,
                                color = if (account?.birthday.isNullOrBlank()) TgBlue else palette.textPrimary,
                                fontWeight = if (account?.birthday.isNullOrBlank()) FontWeight.Medium else FontWeight.Normal
                            )
                            if (!account?.birthday.isNullOrBlank()) {
                                Text(
                                    text = "День рождения",
                                    fontSize = 12.5.sp,
                                    color = palette.textSecondary
                                )
                            }
                        }
                    }
                }
            }

            // Segmented Pill: Публикации | Архив публикаций | Подарки (1:1 to Screenshot 74b03354 & 0243d441)
            item {
                Spacer(modifier = Modifier.height(14.dp))
                Surface(
                    shape = RoundedCornerShape(26.dp),
                    color = palette.surface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        listOf("Публикации", "Архив публикаций", "Подарки").forEachIndexed { idx, label ->
                            val selected = selectedSegment == idx
                            Box(
                                modifier = Modifier
                                    .weight(if (idx == 1) 1.18f else 1f)
                                    .clip(RoundedCornerShape(22.dp))
                                    .background(if (selected) palette.accentSoft else Color.Transparent)
                                    .clickable { selectedSegment = idx }
                                    .padding(vertical = 8.dp, horizontal = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = label,
                                        fontSize = 12.5.sp,
                                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                                        color = if (selected) TgBlue else palette.textSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (idx == 2 && gifts.isNotEmpty()) {
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy((-5).dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            gifts.take(3).forEach { miniGift ->
                                                AnimatedTelegramGift(
                                                    giftKind = miniGift.giftKind,
                                                    animate = false,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Content per Segment
            if (selectedSegment == 2) {
                item {
                    Spacer(modifier = Modifier.height(12.dp))
                    val allTabNames = remember(collections) {
                        listOf("Все подарки", "NFT Коллекция", "Обычные подарки") + collections.map { it.name }
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        allTabNames.forEach { col ->
                            val active = selectedCollection == col
                            Surface(
                                shape = RoundedCornerShape(18.dp),
                                color = if (active) palette.surface else Color.Transparent,
                                modifier = Modifier.clickable { selectedCollection = col }
                            ) {
                                Text(
                                    text = col,
                                    fontSize = 13.sp,
                                    fontWeight = if (active) FontWeight.SemiBold else FontWeight.Medium,
                                    color = if (active) palette.textPrimary else palette.textSecondary,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = Color.Transparent,
                            modifier = Modifier
                                .clickable { showAddCollectionDialog = true }
                                .testTag("add_gift_collection_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Add,
                                    contentDescription = null,
                                    tint = palette.textSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "Добавить коллекцию",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = palette.textSecondary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (filteredGifts.isEmpty()) {
                        Surface(
                            shape = RoundedCornerShape(22.dp),
                            color = palette.surface,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.CardGiftcard,
                                    contentDescription = null,
                                    tint = TgBlue,
                                    modifier = Modifier.size(40.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (gifts.isEmpty()) "Подарков пока нет" else "В этой коллекции пока нет подарков",
                                    fontSize = 15.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = palette.textPrimary,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (gifts.isEmpty()) {
                                        "Получайте коллекционные NFT-подарки от друзей, покупайте в магазине или на маркетплейсе Fragment."
                                    } else {
                                        "Нажмите на любой подарок, чтобы переместить его сюда."
                                    },
                                    fontSize = 13.sp,
                                    color = palette.textSecondary,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(9.dp)
                        ) {
                            filteredGifts.chunked(3).forEachIndexed { rowIdx, rowGifts ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(9.dp)
                                ) {
                                    rowGifts.forEachIndexed { colIdx, gift ->
                                        GiftGridCard(
                                            gift = gift,
                                            phaseOffsetMs = (rowIdx * 3 + colIdx) * 160,
                                            onClick = { selectedGiftDetail = gift },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                    repeat(3 - rowGifts.size) {
                                        Spacer(modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Нажмите на подарок, чтобы обменять его на звёзды или изменить настройки показа.",
                        fontSize = 13.sp,
                        color = palette.textSecondary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 28.dp)
                    )
                }
            } else {
                item {
                    if (visiblePosts.isEmpty()) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 48.dp, horizontal = 32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = if (selectedSegment == 0) "Публикаций пока нет..." else "Архив публикаций пуст",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = palette.textPrimary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Публикуйте фотографии в своём профиле, как в Telegram",
                                fontSize = 13.5.sp,
                                color = palette.textSecondary,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            visiblePosts.chunked(3).forEach { rowPosts ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    rowPosts.forEach { post ->
                                        val model = remember(post.mediaUrl) {
                                            if (post.mediaUrl.startsWith("/")) File(post.mediaUrl) else post.mediaUrl
                                        }
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .aspectRatio(1f)
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(palette.surfaceVariant)
                                                .clickable { selectedPostDetail = post }
                                        ) {
                                            AsyncImage(
                                                model = model,
                                                contentDescription = post.caption.ifBlank { "Публикация" },
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.fillMaxSize()
                                            )
                                            if (post.caption.isNotBlank()) {
                                                Box(
                                                    modifier = Modifier
                                                        .align(Alignment.BottomStart)
                                                        .fillMaxWidth()
                                                        .background(
                                                            Brush.verticalGradient(
                                                                listOf(Color.Transparent, Color.Black.copy(alpha = 0.58f))
                                                            )
                                                        )
                                                        .padding(horizontal = 6.dp, vertical = 4.dp)
                                                ) {
                                                    Text(
                                                        text = post.caption,
                                                        color = Color.White,
                                                        fontSize = 10.5.sp,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    repeat(3 - rowPosts.size) {
                                        Spacer(modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Floating Blue Pill CTA above bottom bar (1:1 to Screenshot 74b03354 & 0243d441)
        if (selectedSegment == 0) {
            Button(
                onClick = {
                    postPicker.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                shape = RoundedCornerShape(26.dp),
                colors = ButtonDefaults.buttonColors(containerColor = TgBlue),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 92.dp)
                    .height(44.dp)
                    .testTag("profile_add_post_button")
            ) {
                Icon(Icons.Outlined.AddAPhoto, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Добавить", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.5.sp)
            }
        } else if (selectedSegment == 2) {
            Button(
                onClick = { showGiftShop = true },
                shape = RoundedCornerShape(26.dp),
                colors = ButtonDefaults.buttonColors(containerColor = TgBlue),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 92.dp)
                    .height(44.dp)
                    .testTag("profile_send_gifts_button")
            ) {
                Icon(Icons.Rounded.CardGiftcard, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Отправить подарки", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.5.sp)
            }
        }
    }

    if (showGiftShop) {
        GiftShopBottomSheet(
            starsBalance = account?.starsBalance ?: 0L,
            recipientName = "Себе в коллекцию",
            onDismiss = { showGiftShop = false },
            onSendGift = { kind, asNft, comment ->
                onSendGiftToSelf(kind, asNft, comment)
                showGiftShop = false
            }
        )
    }

    selectedGiftDetail?.let { gift ->
        GiftDetailBottomSheet(
            gift = gift,
            collections = collections,
            starsBalance = account?.starsBalance ?: 0L,
            isOwnGift = true,
            ownerName = account?.fullName.orEmpty(),
            availableChats = allChats,
            onDismiss = { selectedGiftDetail = null },
            onTogglePin = { onTogglePinGift(gift.id) },
            onToggleWearStatus = { onToggleWearGiftStatus(gift.id) },
            onAssignCollection = { colName -> onAssignGiftToCollection(gift.id, colName) },
            onUpgradeToNft = { onDone -> onUpgradeGiftToNft(gift.id, onDone) },
            onConvertToStars = {
                onConvertGiftToStars(gift.id)
                selectedGiftDetail = null
            },
            onTransferGift = if (onTransferGift != null) { targetChatId ->
                onTransferGift(gift.id, targetChatId)
                selectedGiftDetail = null
            } else null,
            onListOnFragment = if (onListGiftOnFragment != null) { priceGram ->
                onListGiftOnFragment(gift.id, priceGram)
                selectedGiftDetail = null
            } else null,
            onShowToast = onShowToast
        )
    }

    pendingPostUri?.let { uri ->
        AlertDialog(
            onDismissRequest = { pendingPostUri = null },
            containerColor = palette.surface,
            shape = RoundedCornerShape(24.dp),
            title = { Text("Новая публикация", fontWeight = FontWeight.Bold, color = palette.textPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    AsyncImage(
                        model = uri,
                        contentDescription = "Предпросмотр",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(14.dp))
                    )
                    TelegramOutlinedField(
                        value = pendingPostCaption,
                        onValueChange = { pendingPostCaption = it },
                        label = "Подпись к фото (необязательно)",
                        singleLine = false,
                        maxLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onPublishPost(uri, pendingPostCaption.trim())
                        pendingPostUri = null
                    },
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TgBlue)
                ) {
                    Text("Опубликовать", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingPostUri = null }) {
                    Text("Отмена", color = palette.textSecondary)
                }
            }
        )
    }

    selectedPostDetail?.let { post ->
        ProfilePostDetailDialog(
            post = post,
            canManage = true,
            onToggleArchive = {
                onToggleArchivePost(post.id)
                selectedPostDetail = null
            },
            onDelete = {
                onDeletePost(post.id)
                selectedPostDetail = null
            },
            onDismiss = { selectedPostDetail = null }
        )
    }

    if (showAddCollectionDialog) {
        var colName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddCollectionDialog = false },
            containerColor = palette.surface,
            shape = RoundedCornerShape(24.dp),
            title = { Text("Новая коллекция", fontWeight = FontWeight.Bold, color = palette.textPrimary) },
            text = {
                TelegramOutlinedField(
                    value = colName,
                    onValueChange = { colName = it },
                    label = "Название коллекции",
                    placeholder = "Например: Редкие NFT"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (colName.isNotBlank()) {
                            onCreateGiftCollection(colName)
                            selectedCollection = colName.trim()
                            showAddCollectionDialog = false
                        }
                    },
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TgBlue)
                ) {
                    Text("Создать", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddCollectionDialog = false }) {
                    Text("Отмена", color = palette.textSecondary)
                }
            }
        )
    }

    if (showEditDialog && account != null) {
        var first by remember { mutableStateOf(account.firstName) }
        var last by remember { mutableStateOf(account.lastName) }
        var handle by remember { mutableStateOf(account.username) }
        var bio by remember { mutableStateOf(account.bio) }
        var birthday by remember { mutableStateOf(account.birthday) }

        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            containerColor = palette.surface,
            shape = RoundedCornerShape(24.dp),
            title = { Text("Изменить профиль", fontWeight = FontWeight.Bold, color = palette.textPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    TelegramOutlinedField(value = first, onValueChange = { first = it }, label = "Имя")
                    TelegramOutlinedField(value = last, onValueChange = { last = it }, label = "Фамилия")
                    TelegramOutlinedField(value = handle, onValueChange = { handle = it }, label = "Имя пользователя")
                    TelegramOutlinedField(value = bio, onValueChange = { bio = it }, label = "О себе", singleLine = false, maxLines = 2)
                    TelegramOutlinedField(value = birthday, onValueChange = { birthday = it }, label = "День рождения", placeholder = "14 мая")
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onUpdateProfile(first, last, handle, bio, birthday, null)
                        showEditDialog = false
                    },
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TgBlue)
                ) {
                    Text("Сохранить", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditDialog = false }) { Text("Отмена", color = palette.textSecondary) }
            }
        )
    }

    if (showQrDialog && account != null) {
        TelegramQrDialog(
            title = account.fullName,
            handle = account.displayHandle,
            subtitle = "Отсканируйте код, чтобы открыть ваш профиль Fork Gram",
            onDismiss = { showQrDialog = false },
            onShowToast = onShowToast
        )
    }
}

@Composable
fun PeerProfileScreen(
    chat: ChatThread?,
    starsBalance: Long,
    onBack: () -> Unit,
    onOpenChat: () -> Unit,
    onToggleMute: () -> Unit,
    onToggleBlock: () -> Unit,
    onSetAutoDelete: (Int) -> Unit,
    onStartSecretChat: () -> Unit,
    onSendGift: (GiftKind, Boolean, String) -> Unit,
    onLoadPeerProfile: ((String, (PeerProfileData?) -> Unit) -> Unit)? = null,
    onAddToContacts: () -> Unit = {},
    onStartCall: (Boolean) -> Unit = {},
    onShowToast: (String) -> Unit
) {
    val palette = LocalForkPalette.current
    var showOverflow by remember { mutableStateOf(false) }
    var showGiftShop by remember { mutableStateOf(false) }
    var showPeerQrDialog by remember { mutableStateOf(false) }
    var selectedPeerGift by remember { mutableStateOf<OwnedGift?>(null) }
    var selectedPeerPost by remember { mutableStateOf<ProfilePost?>(null) }
    var selectedFilter by remember { mutableStateOf("Все подарки") }
    var remotePeerProfile by remember(chat?.email) { mutableStateOf<PeerProfileData?>(null) }

    LaunchedEffect(chat?.email) {
        val peerEmail = chat?.email?.takeIf { it.contains("@") } ?: return@LaunchedEffect
        onLoadPeerProfile?.invoke(peerEmail) { data ->
            remotePeerProfile = data
        }
    }

    val peerName = remotePeerProfile?.account?.fullName?.ifBlank { null } ?: chat?.title ?: "Пользователь"
    val allPeerGifts = remotePeerProfile?.gifts ?: emptyList()
    val displayedPeerGifts = remember(allPeerGifts, selectedFilter) {
        if (selectedFilter == "Коллекционные") allPeerGifts.filter { it.isNft } else allPeerGifts
    }
    val orbitingPeerGifts = remember(allPeerGifts) {
        val pinned = allPeerGifts.filter { it.isPinned }
        (if (pinned.isNotEmpty()) pinned else allPeerGifts).take(6)
    }
    val peerPosts = remotePeerProfile?.posts ?: emptyList()
    val peerBio = remotePeerProfile?.account?.bio?.ifBlank { null } ?: chat?.bio
    val peerHandle = remotePeerProfile?.account?.displayHandle?.ifBlank { null } ?: chat?.username
    val peerLevel = remotePeerProfile?.account?.level ?: 1
    val wornPeerGift = allPeerGifts.firstOrNull { it.isWornAsStatus }

    val peerOrbitFloat by rememberInfiniteTransition(label = "peerOrbit").animateFloat(
        initialValue = 0f,
        targetValue = (Math.PI * 2.0).toFloat(),
        animationSpec = infiniteRepeatable(tween(4200), RepeatMode.Restart),
        label = "peerOrbitPhase"
    )

    val headerBackdrop = wornPeerGift?.backdrop ?: chat?.statusGiftKind?.defaultBackdrop ?: GiftBackdrop.ONYX_BLACK
    val headerSymbol = wornPeerGift?.symbol ?: chat?.statusGiftKind?.defaultSymbol ?: GiftSymbol.DIAMOND

    val peerStatusLabel = when {
        chat?.isTyping == true -> "печатает..."
        remotePeerProfile?.isTypingToMe == true -> "печатает..."
        chat?.isOnline == true || remotePeerProfile?.isOnline == true -> "в сети"
        else -> chat?.subtitle ?: "был(а) недавно"
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 96.dp)
        ) {
            // 1:1 Dark Telegram Peer Profile Hero with Orbiting Gifts + Scrim + 4 Translucent Action Pills
            item {
                TelegramGiftBackdropBox(
                    backdrop = headerBackdrop,
                    symbol = headerSymbol,
                    radialCenterBiasY = 0.36f,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        Color.Black.copy(alpha = 0.25f),
                                        Color.Black.copy(alpha = 0.65f)
                                    )
                                )
                            )
                            .statusBarsPadding()
                            .padding(bottom = 16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            IconButton(onClick = onBack) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                    contentDescription = "Назад",
                                    tint = Color.White
                                )
                            }
                            Box {
                                IconButton(onClick = { showOverflow = true }) {
                                    Icon(Icons.Rounded.MoreVert, contentDescription = "Меню", tint = Color.White)
                                }
                                DropdownMenu(
                                    expanded = showOverflow,
                                    onDismissRequest = { showOverflow = false },
                                    shape = RoundedCornerShape(18.dp),
                                    containerColor = palette.surface
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("Автоудаление (1 мин)", color = palette.textPrimary) },
                                        onClick = {
                                            showOverflow = false
                                            onSetAutoDelete(60)
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Добавить контакт", color = palette.textPrimary) },
                                        onClick = {
                                            showOverflow = false
                                            onAddToContacts()
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Отправить подарок", color = palette.textPrimary) },
                                        onClick = {
                                            showOverflow = false
                                            showGiftShop = true
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Начать секретный чат", color = palette.textPrimary) },
                                        onClick = {
                                            showOverflow = false
                                            onStartSecretChat()
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                if (chat?.isBlocked == true) "Разблокировать" else "Заблокировать",
                                                color = DangerRed
                                            )
                                        },
                                        onClick = {
                                            showOverflow = false
                                            onToggleBlock()
                                        }
                                    )
                                }
                            }
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(132.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            val orbitOffsets = listOf(
                                Offset(-108f, -34f),
                                Offset(-132f, 16f),
                                Offset(-84f, 44f),
                                Offset(108f, -34f),
                                Offset(132f, 16f),
                                Offset(84f, 44f)
                            )
                            orbitingPeerGifts.forEachIndexed { idx, gift ->
                                val off = orbitOffsets[idx % orbitOffsets.size]
                                val bobY = sin(peerOrbitFloat + idx * 1.15f) * 3.5f
                                Box(
                                    modifier = Modifier
                                        .offset(x = off.x.dp, y = (off.y + bobY).dp)
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(
                                            Brush.radialGradient(
                                                listOf(
                                                    Color(gift.backdrop.centerHex).copy(alpha = 0.55f),
                                                    Color.Transparent
                                                )
                                            )
                                        )
                                        .clickable { selectedPeerGift = gift },
                                    contentAlignment = Alignment.Center
                                ) {
                                    AnimatedTelegramGift(
                                        giftKind = gift.giftKind,
                                        phaseOffsetMs = idx * 180,
                                        editionNumber = gift.editionNumber,
                                        useRemoteEdition = gift.isNft,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }
                            }

                            AvatarView(
                                title = peerName,
                                avatarUri = remotePeerProfile?.account?.avatarUri ?: chat?.avatarUri,
                                colorHex = chat?.avatarColorHex ?: 0xFF5C6BC0,
                                size = 96.dp,
                                chatType = chat?.chatType
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = peerName,
                                fontSize = 23.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            val activeStatusGift = wornPeerGift?.giftKind ?: chat?.statusGiftKind
                            if (activeStatusGift != null) {
                                Spacer(modifier = Modifier.width(6.dp))
                                AnimatedTelegramGift(
                                    giftKind = activeStatusGift,
                                    editionNumber = wornPeerGift?.editionNumber ?: activeStatusGift.validDemoEditions.firstOrNull(),
                                    useRemoteEdition = true,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            SvgHexLevelBadge(
                                level = peerLevel,
                                modifier = Modifier.size(17.dp),
                                strokeColor = Color.White.copy(alpha = 0.78f)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = peerStatusLabel,
                                fontSize = 14.sp,
                                color = Color.White.copy(alpha = 0.85f)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            PeerActionPill(Icons.Outlined.ChatBubbleOutline, "Чат", onOpenChat, Modifier.weight(1f))
                            PeerActionPill(
                                Icons.Outlined.Notifications,
                                if (chat?.isMuted == true) "Вкл. звук" else "Звук",
                                onToggleMute,
                                Modifier.weight(1f)
                            )
                            PeerActionPill(Icons.Rounded.Call, "Звонок", { onStartCall(false) }, Modifier.weight(1f))
                            PeerActionPill(Icons.Rounded.Videocam, "Видео", { onStartCall(true) }, Modifier.weight(1f))
                        }
                    }
                }
            }

            if (!peerHandle.isNullOrBlank() || !peerBio.isNullOrBlank()) {
                item {
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        shape = RoundedCornerShape(22.dp),
                        color = palette.surface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            if (!peerHandle.isNullOrBlank()) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { showPeerQrDialog = true },
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(peerHandle, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = palette.textPrimary)
                                        Text("Имя пользователя", fontSize = 12.5.sp, color = palette.textSecondary)
                                    }
                                    IconButton(onClick = { showPeerQrDialog = true }, modifier = Modifier.size(32.dp)) {
                                        Icon(Icons.Rounded.QrCode2, contentDescription = "QR-код", tint = TgBlue)
                                    }
                                }
                            }
                            if (!peerBio.isNullOrBlank()) {
                                if (!peerHandle.isNullOrBlank()) Spacer(modifier = Modifier.height(12.dp))
                                Text(peerBio, fontSize = 15.sp, color = palette.textPrimary)
                                Text("О себе", fontSize = 12.5.sp, color = palette.textSecondary)
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = palette.surface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp)
                        .clickable { onAddToContacts() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PersonAdd,
                            contentDescription = null,
                            tint = TgBlue,
                            modifier = Modifier.size(21.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Добавить в контакты",
                            fontSize = 15.5.sp,
                            fontWeight = FontWeight.Medium,
                            color = palette.textPrimary
                        )
                    }
                }
            }

            if (peerPosts.isNotEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Публикации (${peerPosts.size})",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TgBlue,
                        modifier = Modifier.padding(horizontal = 18.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        peerPosts.chunked(3).forEach { rowPosts ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                rowPosts.forEach { post ->
                                    val model = remember(post.mediaUrl) {
                                        if (post.mediaUrl.startsWith("/")) File(post.mediaUrl) else post.mediaUrl
                                    }
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .aspectRatio(1f)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(palette.surfaceVariant)
                                            .clickable { selectedPeerPost = post }
                                    ) {
                                        AsyncImage(
                                            model = model,
                                            contentDescription = post.caption.ifBlank { "Публикация" },
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    }
                                }
                                repeat(3 - rowPosts.size) {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Surface(
                        shape = RoundedCornerShape(22.dp),
                        color = palette.surface
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Подарки",
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TgBlue
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy((-5).dp)) {
                                allPeerGifts.take(3).forEach { mini ->
                                    AnimatedTelegramGift(
                                        giftKind = mini.giftKind,
                                        animate = false,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                if (allPeerGifts.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        listOf("Все подарки", "Коллекционные").forEach { tab ->
                            val active = selectedFilter == tab
                            Surface(
                                shape = RoundedCornerShape(18.dp),
                                color = if (active) palette.surface else Color.Transparent,
                                modifier = Modifier
                                    .padding(horizontal = 4.dp)
                                    .clickable { selectedFilter = tab }
                            ) {
                                Text(
                                    text = tab,
                                    fontSize = 13.sp,
                                    fontWeight = if (active) FontWeight.SemiBold else FontWeight.Medium,
                                    color = if (active) palette.textPrimary else palette.textSecondary,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                if (displayedPeerGifts.isEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = palette.surface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.CardGiftcard,
                                contentDescription = null,
                                tint = TgBlue,
                                modifier = Modifier.size(34.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Подарков пока нет",
                                fontSize = 14.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = palette.textPrimary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Подарите первый подарок с помощью кнопки ниже",
                                fontSize = 12.5.sp,
                                color = palette.textSecondary,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp),
                        verticalArrangement = Arrangement.spacedBy(9.dp)
                    ) {
                        displayedPeerGifts.chunked(3).forEachIndexed { rIdx, row ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(9.dp)
                            ) {
                                row.forEachIndexed { cIdx, gift ->
                                    GiftGridCard(
                                        gift = gift,
                                        phaseOffsetMs = (rIdx * 3 + cIdx) * 160,
                                        onClick = { selectedPeerGift = gift },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                repeat(3 - row.size) {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
        }

        Button(
            onClick = { showGiftShop = true },
            shape = RoundedCornerShape(26.dp),
            colors = ButtonDefaults.buttonColors(containerColor = TgBlue),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 24.dp)
                .height(46.dp)
        ) {
            Icon(Icons.Rounded.CardGiftcard, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color.White)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Отправить подарок $peerName", color = Color.White, fontWeight = FontWeight.SemiBold)
        }
    }

    if (showGiftShop) {
        GiftShopBottomSheet(
            starsBalance = starsBalance,
            recipientName = chat?.title ?: "Собеседник",
            onDismiss = { showGiftShop = false },
            onSendGift = { kind, asNft, comment ->
                onSendGift(kind, asNft, comment)
                showGiftShop = false
            }
        )
    }

    selectedPeerGift?.let { gift ->
        GiftDetailBottomSheet(
            gift = gift,
            collections = emptyList(),
            starsBalance = starsBalance,
            isOwnGift = false,
            ownerName = remotePeerProfile?.account?.fullName?.ifBlank { null } ?: chat?.title.orEmpty(),
            onDismiss = { selectedPeerGift = null },
            onTogglePin = {},
            onToggleWearStatus = {},
            onAssignCollection = {},
            onUpgradeToNft = {},
            onConvertToStars = {},
            onShowToast = onShowToast
        )
    }

    selectedPeerPost?.let { post ->
        ProfilePostDetailDialog(
            post = post,
            canManage = false,
            onToggleArchive = {},
            onDelete = {},
            onDismiss = { selectedPeerPost = null }
        )
    }

    if (showPeerQrDialog && !peerHandle.isNullOrBlank()) {
        TelegramQrDialog(
            title = peerName,
            handle = peerHandle,
            subtitle = "QR-код пользователя Fork Gram",
            onDismiss = { showPeerQrDialog = false },
            onShowToast = onShowToast
        )
    }
}

@Composable
private fun ProfilePostDetailDialog(
    post: ProfilePost,
    canManage: Boolean,
    onToggleArchive: () -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalForkPalette.current
    val model = remember(post.mediaUrl) {
        if (post.mediaUrl.startsWith("/")) File(post.mediaUrl) else post.mediaUrl
    }
    val dateText = remember(post.createdAt) {
        SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault()).format(Date(post.createdAt))
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.94f))
                .statusBarsPadding()
                .padding(16.dp)
        ) {
            IconButton(
                onClick = onDismiss,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.16f))
            ) {
                Icon(Icons.Rounded.Close, contentDescription = "Закрыть", tint = Color.White)
            }

            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                AsyncImage(
                    model = model,
                    contentDescription = post.caption.ifBlank { "Публикация" },
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(420.dp)
                        .clip(RoundedCornerShape(16.dp))
                )
                Spacer(modifier = Modifier.height(12.dp))
                if (post.caption.isNotBlank()) {
                    Text(
                        text = post.caption,
                        color = Color.White,
                        fontSize = 15.5.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                }
                Text(
                    text = dateText,
                    color = Color.White.copy(alpha = 0.65f),
                    fontSize = 12.5.sp
                )
                if (canManage) {
                    Spacer(modifier = Modifier.height(18.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = onToggleArchive,
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Icon(
                                imageVector = if (post.isArchived) Icons.Rounded.Unarchive else Icons.Rounded.Archive,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (post.isArchived) "Из архива" else "В архив",
                                color = Color.White
                            )
                        }
                        Button(
                            onClick = onDelete,
                            shape = RoundedCornerShape(18.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = DangerRed)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.DeleteOutline,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Удалить", color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PeerActionPill(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = Color.White.copy(alpha = 0.14f),
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(21.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(label, color = Color.White, fontSize = 11.5.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun ProfileActionPill(
    icon: ImageVector,
    label: String,
    isOnThemedHero: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalForkPalette.current
    val bgColor = if (isOnThemedHero) Color.White.copy(alpha = 0.16f) else palette.surface
    val fgColor = if (isOnThemedHero) Color.White else palette.textPrimary

    Surface(
        shape = RoundedCornerShape(18.dp),
        color = bgColor,
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 11.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = fgColor,
                modifier = Modifier.size(21.dp)
            )
            Spacer(modifier = Modifier.height(5.dp))
            Text(
                text = label,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Medium,
                color = fgColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun GiftGridCard(
    gift: OwnedGift,
    phaseOffsetMs: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    TelegramGiftBackdropBox(
        backdrop = gift.backdrop,
        symbol = gift.symbol,
        showShimmer = gift.isNft,
        modifier = modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(14.dp))
            .clipToBounds()
            .clickable(onClick = onClick)
    ) {
        if (gift.isPinned) {
            Icon(
                imageVector = Icons.Rounded.PushPin,
                contentDescription = "Закреплён",
                tint = Color.White.copy(alpha = 0.88f),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(7.dp)
                    .size(14.dp)
            )
        }

        // Angled edition / rarity ribbon flush-clipped to top-right corner
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .offset(x = 15.dp, y = 8.dp)
                .rotate(42f)
                .background(
                    if (gift.isNft) Color.Black.copy(alpha = 0.36f)
                    else Color.White.copy(alpha = 0.25f)
                )
                .padding(horizontal = 16.dp, vertical = 1.dp)
        ) {
            Text(
                text = if (gift.isNft) "#${gift.editionNumber}" else "Подарок",
                color = Color.White,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold
            )
        }

        AnimatedTelegramGift(
            giftKind = gift.giftKind,
            phaseOffsetMs = phaseOffsetMs,
            editionNumber = gift.editionNumber,
            useRemoteEdition = gift.isNft,
            modifier = Modifier
                .size(88.dp)
                .align(Alignment.Center)
        )
    }
}
