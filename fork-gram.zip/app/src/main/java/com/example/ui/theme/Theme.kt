package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

@Immutable
data class ForkGramPalette(
    val isDark: Boolean,
    val background: Color,
    val surface: Color,
    val surfaceVariant: Color,
    val divider: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val accent: Color,
    val accentSoft: Color,
    val bubbleIncoming: Color,
    val bubbleOutgoing: Color,
    val bubbleOutgoingMeta: Color,
    val navPill: Color,
    val navActivePill: Color,
    val datePillBg: Color,
)

private val LightForkPalette = ForkGramPalette(
    isDark = false,
    background = LightBackground,
    surface = LightSurface,
    surfaceVariant = LightSurfaceVariant,
    divider = LightDivider,
    textPrimary = LightTextPrimary,
    textSecondary = LightTextSecondary,
    accent = TgBlue,
    accentSoft = TgBlueSoft,
    bubbleIncoming = LightBubbleIncoming,
    bubbleOutgoing = LightBubbleOutgoing,
    bubbleOutgoingMeta = LightBubbleOutgoingMeta,
    navPill = LightNavPill,
    navActivePill = LightNavActivePill,
    datePillBg = Color(0x52345326),
)

private val DarkForkPalette = ForkGramPalette(
    isDark = true,
    background = DarkBackground,
    surface = DarkSurface,
    surfaceVariant = DarkSurfaceVariant,
    divider = DarkDivider,
    textPrimary = DarkTextPrimary,
    textSecondary = DarkTextSecondary,
    accent = TgBlue,
    accentSoft = TgBlueSoftDark,
    bubbleIncoming = DarkBubbleIncoming,
    bubbleOutgoing = DarkBubbleOutgoing,
    bubbleOutgoingMeta = DarkBubbleOutgoingMeta,
    navPill = DarkNavPill,
    navActivePill = DarkNavActivePill,
    datePillBg = Color(0x660B1219),
)

val LocalForkPalette = staticCompositionLocalOf { LightForkPalette }

private val ForkDarkColorScheme = darkColorScheme(
    primary = TgBlue,
    onPrimary = Color.White,
    primaryContainer = TgBlueSoftDark,
    onPrimaryContainer = Color.White,
    secondary = GramCyan,
    onSecondary = Color.White,
    tertiary = StarGold,
    background = DarkBackground,
    onBackground = DarkTextPrimary,
    surface = DarkSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkTextSecondary,
    outline = Color(0xFF2D3C4B),
    error = DangerRed
)

private val ForkLightColorScheme = lightColorScheme(
    primary = TgBlue,
    onPrimary = Color.White,
    primaryContainer = TgBlueSoft,
    onPrimaryContainer = TgBlueDark,
    secondary = GramCyan,
    onSecondary = Color.White,
    tertiary = StarGold,
    background = LightBackground,
    onBackground = LightTextPrimary,
    surface = LightSurface,
    onSurface = LightTextPrimary,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightTextSecondary,
    outline = Color(0xFFD5D8DC),
    error = DangerRed
)

@Composable
fun ForkGramTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val palette = if (darkTheme) DarkForkPalette else LightForkPalette
    val colorScheme = if (darkTheme) ForkDarkColorScheme else ForkLightColorScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    CompositionLocalProvider(LocalForkPalette provides palette) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
