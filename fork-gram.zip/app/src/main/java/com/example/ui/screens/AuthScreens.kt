package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.AddAPhoto
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.components.TelegramOutlinedField
import com.example.ui.svg.SvgPaperPlaneIcon
import com.example.ui.theme.LocalForkPalette
import com.example.ui.theme.TgBlue
import com.example.ui.theme.TgBlueDark
import kotlinx.coroutines.launch

private enum class AuthStep {
    WELCOME,
    EMAIL,
    NAME
}

@Composable
fun AuthFlowScreen(
    onCheckExistingAccount: suspend (String) -> com.example.data.model.UserAccount?,
    onCompleteAuth: (email: String, firstName: String, lastName: String, avatarUri: String?) -> Unit
) {
    val palette = LocalForkPalette.current
    val scope = rememberCoroutineScope()

    var step by remember { mutableStateOf(AuthStep.WELCOME) }
    var email by remember { mutableStateOf("") }
    var emailError by remember { mutableStateOf<String?>(null) }
    var syncContacts by remember { mutableStateOf(true) }

    var firstName by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    var nameError by remember { mutableStateOf<String?>(null) }
    var avatarUri by remember { mutableStateOf<Uri?>(null) }
    var isReturningUser by remember { mutableStateOf(false) }
    var isBusy by remember { mutableStateOf(false) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) avatarUri = uri
    }

    BackHandler(enabled = step != AuthStep.WELCOME && !isBusy) {
        step = when (step) {
            AuthStep.NAME -> AuthStep.EMAIL
            AuthStep.EMAIL -> AuthStep.WELCOME
            AuthStep.WELCOME -> AuthStep.WELCOME
        }
    }

    fun submitEmail() {
        if (isBusy) return
        val clean = email.trim()
        if (!clean.contains("@") || !clean.contains(".") || clean.length < 5) {
            emailError = "Введите корректный адрес электронной почты"
            return
        }
        emailError = null
        isBusy = true
        scope.launch {
            try {
                val existing = onCheckExistingAccount(clean)
                if (existing != null) {
                    isReturningUser = true
                    firstName = existing.firstName
                    lastName = existing.lastName
                } else {
                    isReturningUser = false
                }
                step = AuthStep.NAME
            } finally {
                isBusy = false
            }
        }
    }

    fun submitName() {
        if (isBusy) return
        val cleanFirst = firstName.trim()
        if (cleanFirst.isEmpty()) {
            nameError = "Введите имя аккаунта"
            return
        }
        nameError = null
        isBusy = true
        onCompleteAuth(email.trim(), cleanFirst, lastName.trim(), avatarUri?.toString())
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.surface)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        AnimatedContent(
            targetState = step,
            transitionSpec = {
                (slideInHorizontally { it / 3 } + fadeIn()) togetherWith
                    (slideOutHorizontally { -it / 3 } + fadeOut())
            },
            label = "authStepTransition"
        ) { currentStep ->
            when (currentStep) {
                AuthStep.WELCOME -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 28.dp, vertical = 32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Spacer(modifier = Modifier.height(24.dp))

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                modifier = Modifier
                                    .size(120.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.linearGradient(listOf(TgBlue, TgBlueDark))
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                SvgPaperPlaneIcon(
                                    modifier = Modifier.size(66.dp),
                                    color = Color.White
                                )
                            }
                            Spacer(modifier = Modifier.height(28.dp))
                            Text(
                                text = "Fork Gram",
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Bold,
                                color = palette.textPrimary
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "Быстрый и безопасный мессенджер со Звёздами, валютой Gram, подарками и NFT-юзернеймами.",
                                fontSize = 15.sp,
                                lineHeight = 22.sp,
                                color = palette.textSecondary,
                                textAlign = TextAlign.Center
                            )
                        }

                        Button(
                            onClick = { step = AuthStep.EMAIL },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("auth_start_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = TgBlue)
                        ) {
                            Text(
                                text = "Начать общение",
                                fontSize = 15.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White
                            )
                        }
                    }
                }

                // 1:1 to Screenshot 14, with Email instead of Phone Number
                AuthStep.EMAIL -> {
                    Box(modifier = Modifier.fillMaxSize()) {
                        IconButton(
                            onClick = { step = AuthStep.WELCOME },
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Назад",
                                tint = palette.textPrimary
                            )
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "Ваша почта",
                                fontSize = 21.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = palette.textPrimary
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "Укажите свой адрес электронной почты.\nКод подтверждения не требуется.",
                                fontSize = 14.5.sp,
                                lineHeight = 20.sp,
                                color = palette.textSecondary,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(26.dp))

                            TelegramOutlinedField(
                                value = email,
                                onValueChange = {
                                    email = it
                                    emailError = null
                                },
                                label = "Электронная почта",
                                placeholder = "example@mail.com",
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Rounded.Email,
                                        contentDescription = null,
                                        tint = TgBlue
                                    )
                                },
                                isError = emailError != null,
                                supportingText = emailError,
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Email,
                                    imeAction = ImeAction.Done
                                ),
                                keyboardActions = KeyboardActions(onDone = { submitEmail() }),
                                modifier = Modifier.testTag("auth_email_input")
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { syncContacts = !syncContacts }
                                    .padding(vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = syncContacts,
                                    onCheckedChange = { syncContacts = it },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = TgBlue,
                                        checkmarkColor = Color.White
                                    )
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Синхронизировать контакты",
                                    fontSize = 14.5.sp,
                                    color = palette.textPrimary
                                )
                            }

                            Spacer(modifier = Modifier.height(68.dp))
                        }

                        FloatingActionButton(
                            onClick = { submitEmail() },
                            shape = CircleShape,
                            containerColor = TgBlue,
                            contentColor = Color.White,
                            elevation = FloatingActionButtonDefaults.elevation(4.dp),
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(20.dp)
                                .size(56.dp)
                                .testTag("auth_email_next_fab")
                        ) {
                            if (isBusy) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    strokeWidth = 2.5.dp,
                                    modifier = Modifier.size(24.dp)
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                                    contentDescription = "Далее",
                                    modifier = Modifier.size(25.dp)
                                )
                            }
                        }
                    }
                }

                // Step 3: Your Name screen (like Telegram registration after email)
                AuthStep.NAME -> {
                    Box(modifier = Modifier.fillMaxSize()) {
                        IconButton(
                            onClick = { step = AuthStep.EMAIL },
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Назад",
                                tint = palette.textPrimary
                            )
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(84.dp)
                                    .clip(CircleShape)
                                    .background(TgBlue)
                                    .clickable {
                                        photoPicker.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                if (avatarUri != null) {
                                    AsyncImage(
                                        model = avatarUri,
                                        contentDescription = "Фото профиля",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Rounded.AddAPhoto,
                                        contentDescription = "Выбрать фото",
                                        tint = Color.White,
                                        modifier = Modifier.size(34.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(20.dp))

                            Text(
                                text = if (isReturningUser) "С возвращением!" else "Ваше имя",
                                fontSize = 21.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = palette.textPrimary
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (isReturningUser) {
                                    "Аккаунт найден для $email. Проверьте имя или войдите сразу."
                                } else {
                                    "Введите имя и при желании добавьте фото профиля."
                                },
                                fontSize = 14.5.sp,
                                lineHeight = 20.sp,
                                color = palette.textSecondary,
                                textAlign = TextAlign.Center
                            )

                            Spacer(modifier = Modifier.height(24.dp))

                            TelegramOutlinedField(
                                value = firstName,
                                onValueChange = {
                                    firstName = it
                                    nameError = null
                                },
                                label = "Имя (обязательно)",
                                leadingIcon = {
                                    Icon(Icons.Rounded.Person, contentDescription = null, tint = TgBlue)
                                },
                                isError = nameError != null,
                                supportingText = nameError,
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                                modifier = Modifier.testTag("auth_first_name_input")
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            TelegramOutlinedField(
                                value = lastName,
                                onValueChange = { lastName = it },
                                label = "Фамилия (необязательно)",
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                keyboardActions = KeyboardActions(onDone = { submitName() }),
                                modifier = Modifier.testTag("auth_last_name_input")
                            )

                            Spacer(modifier = Modifier.height(68.dp))
                        }

                        FloatingActionButton(
                            onClick = { submitName() },
                            shape = CircleShape,
                            containerColor = TgBlue,
                            contentColor = Color.White,
                            elevation = FloatingActionButtonDefaults.elevation(4.dp),
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(20.dp)
                                .size(56.dp)
                                .testTag("auth_complete_fab")
                        ) {
                            if (isBusy) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    strokeWidth = 2.5.dp,
                                    modifier = Modifier.size(24.dp)
                                )
                            } else {
                                Icon(
                                    imageVector = if (isReturningUser) Icons.Rounded.Check else Icons.AutoMirrored.Rounded.ArrowForward,
                                    contentDescription = "Войти",
                                    modifier = Modifier.size(25.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
