package com.example.ui.svg

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.model.GiftKind
import com.example.data.model.ReactionType
import com.example.data.model.WallpaperTheme
import com.example.ui.theme.GramCyan
import com.example.ui.theme.PremiumViolet
import com.example.ui.theme.StarGold
import com.example.ui.theme.TgBlue
import com.example.ui.theme.WallpaperDarkBottom
import com.example.ui.theme.WallpaperDarkPattern
import com.example.ui.theme.WallpaperDarkTop
import com.example.ui.theme.WallpaperGreenBottom
import com.example.ui.theme.WallpaperGreenPattern
import com.example.ui.theme.WallpaperGreenTop
import com.example.ui.theme.WallpaperLavenderBottom
import com.example.ui.theme.WallpaperLavenderPattern
import com.example.ui.theme.WallpaperLavenderTop
import com.example.ui.theme.WallpaperOceanBottom
import com.example.ui.theme.WallpaperOceanPattern
import com.example.ui.theme.WallpaperOceanTop
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SvgPaperPlaneIcon(
    modifier: Modifier = Modifier,
    color: Color = Color.White
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val path = Path().apply {
            moveTo(w * 0.10f, h * 0.48f)
            lineTo(w * 0.88f, h * 0.16f)
            lineTo(w * 0.72f, h * 0.84f)
            lineTo(w * 0.48f, h * 0.65f)
            lineTo(w * 0.34f, h * 0.76f)
            lineTo(w * 0.36f, h * 0.56f)
            close()
        }
        drawPath(path, color = color)
        // Wing fold crease
        val fold = Path().apply {
            moveTo(w * 0.36f, h * 0.56f)
            lineTo(w * 0.80f, h * 0.24f)
            lineTo(w * 0.48f, h * 0.65f)
            close()
        }
        drawPath(fold, color = color.copy(alpha = 0.72f))
    }
}

@Composable
fun SvgStarIcon(
    modifier: Modifier = Modifier,
    color: Color = TgBlue,
    innerHighlight: Color = Color.White.copy(alpha = 0.35f)
) {
    Canvas(modifier = modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val outerR = size.minDimension * 0.48f
        val innerR = outerR * 0.46f
        val starPath = buildStarPath(cx, cy, outerR, innerR, points = 5)
        drawPath(starPath, color = color)
        val highlight = buildStarPath(cx - outerR * 0.06f, cy - outerR * 0.06f, outerR * 0.45f, innerR * 0.45f, 5)
        drawPath(highlight, color = innerHighlight)
    }
}

@Composable
fun SvgVerifiedBadge(
    modifier: Modifier = Modifier,
    badgeColor: Color = TgBlue
) {
    Canvas(modifier = modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val r = size.minDimension * 0.46f
        // Scalloped 10-point Telegram verified rosette
        val rosette = Path()
        val steps = 20
        for (i in 0 until steps) {
            val angle = (i * 2.0 * PI / steps) - PI / 2.0
            val rad = if (i % 2 == 0) r else r * 0.84f
            val x = cx + (rad * cos(angle)).toFloat()
            val y = cy + (rad * sin(angle)).toFloat()
            if (i == 0) rosette.moveTo(x, y) else rosette.lineTo(x, y)
        }
        rosette.close()
        drawPath(rosette, color = badgeColor)

        val check = Path().apply {
            moveTo(cx - r * 0.36f, cy + r * 0.02f)
            lineTo(cx - r * 0.08f, cy + r * 0.30f)
            lineTo(cx + r * 0.38f, cy - r * 0.24f)
        }
        drawPath(
            check,
            color = Color.White,
            style = Stroke(width = size.minDimension * 0.13f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}

@Composable
fun SvgGramGemIcon(
    modifier: Modifier = Modifier,
    color: Color = GramCyan
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val outer = Path().apply {
            moveTo(w * 0.24f, h * 0.16f)
            lineTo(w * 0.76f, h * 0.16f)
            lineTo(w * 0.92f, h * 0.40f)
            lineTo(w * 0.50f, h * 0.88f)
            lineTo(w * 0.08f, h * 0.40f)
            close()
        }
        drawPath(outer, color = color)
        val facet = Path().apply {
            moveTo(w * 0.24f, h * 0.16f)
            lineTo(w * 0.50f, h * 0.40f)
            lineTo(w * 0.76f, h * 0.16f)
            moveTo(w * 0.08f, h * 0.40f)
            lineTo(w * 0.92f, h * 0.40f)
            moveTo(w * 0.50f, h * 0.40f)
            lineTo(w * 0.50f, h * 0.88f)
        }
        drawPath(
            facet,
            color = Color.White.copy(alpha = 0.75f),
            style = Stroke(width = size.minDimension * 0.07f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}

@Composable
fun SvgHexLevelBadge(
    level: Int,
    modifier: Modifier = Modifier,
    strokeColor: Color = Color(0xFF6B7280)
) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val r = size.minDimension * 0.44f
            val hex = Path()
            for (i in 0 until 6) {
                val angle = (i * 60.0 - 90.0) * PI / 180.0
                val x = cx + (r * cos(angle)).toFloat()
                val y = cy + (r * sin(angle)).toFloat()
                if (i == 0) hex.moveTo(x, y) else hex.lineTo(x, y)
            }
            hex.close()
            drawPath(hex, color = strokeColor, style = Stroke(width = size.minDimension * 0.09f, join = StrokeJoin.Round))
        }
        androidx.compose.material3.Text(
            text = level.toString(),
            style = androidx.compose.material3.MaterialTheme.typography.labelSmall.copy(
                fontSize = androidx.compose.ui.unit.TextUnit(9f, androidx.compose.ui.unit.TextUnitType.Sp),
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                color = strokeColor
            )
        )
    }
}

@Composable
fun SvgNavChatsIcon(
    isSelected: Boolean,
    color: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val stroke = Stroke(width = size.minDimension * 0.09f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        val backBubble = Path().apply {
            moveTo(w * 0.36f, h * 0.24f)
            lineTo(w * 0.74f, h * 0.24f)
            quadraticTo(w * 0.88f, h * 0.24f, w * 0.88f, h * 0.38f)
            lineTo(w * 0.88f, h * 0.56f)
            quadraticTo(w * 0.88f, h * 0.70f, w * 0.74f, h * 0.70f)
            lineTo(w * 0.78f, h * 0.80f)
            lineTo(w * 0.64f, h * 0.70f)
        }
        val frontBubble = Path().apply {
            moveTo(w * 0.14f, h * 0.44f)
            quadraticTo(w * 0.14f, h * 0.30f, w * 0.28f, h * 0.30f)
            lineTo(w * 0.60f, h * 0.30f)
            quadraticTo(w * 0.74f, h * 0.30f, w * 0.74f, h * 0.44f)
            lineTo(w * 0.74f, h * 0.64f)
            quadraticTo(w * 0.74f, h * 0.78f, w * 0.60f, h * 0.78f)
            lineTo(w * 0.32f, h * 0.78f)
            lineTo(w * 0.16f, h * 0.88f)
            lineTo(w * 0.20f, h * 0.74f)
            quadraticTo(w * 0.14f, h * 0.70f, w * 0.14f, h * 0.64f)
            close()
        }
        if (isSelected) {
            drawPath(backBubble, color = color.copy(alpha = 0.45f))
            drawPath(frontBubble, color = color)
        } else {
            drawPath(backBubble, color = color, style = stroke)
            drawPath(frontBubble, color = color, style = stroke)
        }
    }
}

@Composable
fun SvgReactionIcon(
    type: ReactionType,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        when (type) {
            ReactionType.HEART -> {
                val p = Path().apply {
                    moveTo(w * 0.5f, h * 0.84f)
                    cubicTo(w * 0.12f, h * 0.60f, w * 0.08f, h * 0.26f, w * 0.30f, h * 0.20f)
                    cubicTo(w * 0.42f, h * 0.17f, w * 0.50f, h * 0.28f, w * 0.50f, h * 0.33f)
                    cubicTo(w * 0.50f, h * 0.28f, w * 0.58f, h * 0.17f, w * 0.70f, h * 0.20f)
                    cubicTo(w * 0.92f, h * 0.26f, w * 0.88f, h * 0.60f, w * 0.50f, h * 0.84f)
                    close()
                }
                drawPath(p, brush = Brush.verticalGradient(listOf(Color(0xFFFF5C7A), Color(0xFFE02448))))
            }
            ReactionType.THUMBS_UP -> {
                drawRoundRect(
                    color = Color(0xFFFFB74D),
                    topLeft = Offset(w * 0.18f, h * 0.44f),
                    size = Size(w * 0.16f, h * 0.40f),
                    cornerRadius = CornerRadius(w * 0.05f, w * 0.05f)
                )
                val hand = Path().apply {
                    moveTo(w * 0.36f, h * 0.46f)
                    lineTo(w * 0.50f, h * 0.18f)
                    quadraticTo(w * 0.60f, h * 0.14f, w * 0.60f, h * 0.28f)
                    lineTo(w * 0.56f, h * 0.42f)
                    lineTo(w * 0.80f, h * 0.42f)
                    quadraticTo(w * 0.88f, h * 0.44f, w * 0.84f, h * 0.56f)
                    lineTo(w * 0.78f, h * 0.80f)
                    quadraticTo(w * 0.74f, h * 0.86f, w * 0.62f, h * 0.86f)
                    lineTo(w * 0.36f, h * 0.86f)
                    close()
                }
                drawPath(hand, color = Color(0xFFFFCA28))
            }
            ReactionType.FIRE -> {
                val outer = Path().apply {
                    moveTo(w * 0.52f, h * 0.10f)
                    cubicTo(w * 0.86f, h * 0.36f, w * 0.88f, h * 0.84f, w * 0.50f, h * 0.88f)
                    cubicTo(w * 0.14f, h * 0.86f, w * 0.14f, h * 0.46f, w * 0.36f, h * 0.28f)
                    cubicTo(w * 0.34f, h * 0.42f, w * 0.44f, h * 0.44f, w * 0.52f, h * 0.10f)
                    close()
                }
                drawPath(outer, brush = Brush.verticalGradient(listOf(Color(0xFFFF9800), Color(0xFFE53935))))
                val inner = Path().apply {
                    moveTo(w * 0.50f, h * 0.46f)
                    cubicTo(w * 0.68f, h * 0.60f, w * 0.68f, h * 0.84f, w * 0.50f, h * 0.84f)
                    cubicTo(w * 0.34f, h * 0.84f, w * 0.34f, h * 0.60f, w * 0.50f, h * 0.46f)
                    close()
                }
                drawPath(inner, color = Color(0xFFFFEB3B))
            }
            ReactionType.STAR -> {
                val s = buildStarPath(w * 0.5f, h * 0.5f, w * 0.44f, w * 0.20f, 5)
                drawPath(s, brush = Brush.verticalGradient(listOf(Color(0xFFFFD54F), StarGold)))
            }
            ReactionType.SPARKLES -> {
                val big = buildStarPath(w * 0.46f, h * 0.52f, w * 0.36f, w * 0.11f, 4)
                val small = buildStarPath(w * 0.76f, h * 0.26f, w * 0.18f, w * 0.06f, 4)
                drawPath(big, color = TgBlue)
                drawPath(small, color = StarGold)
            }
            ReactionType.CROWN -> {
                val crown = Path().apply {
                    moveTo(w * 0.16f, h * 0.76f)
                    lineTo(w * 0.12f, h * 0.34f)
                    lineTo(w * 0.34f, h * 0.52f)
                    lineTo(w * 0.50f, h * 0.22f)
                    lineTo(w * 0.66f, h * 0.52f)
                    lineTo(w * 0.88f, h * 0.34f)
                    lineTo(w * 0.84f, h * 0.76f)
                    close()
                }
                drawPath(crown, brush = Brush.verticalGradient(listOf(Color(0xFFFFD740), Color(0xFFFF9100))))
            }
        }
    }
}

@Composable
fun SvgGiftArtwork(
    giftKind: GiftKind,
    modifier: Modifier = Modifier
) {
    AnimatedTelegramGift(
        giftKind = giftKind,
        animate = false,
        modifier = modifier
    )
}

@Composable
fun SvgDuckDetective(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val cx = w / 2f

        // Duck body
        drawOval(
            brush = Brush.verticalGradient(listOf(Color(0xFFFFE066), Color(0xFFFFB703))),
            topLeft = Offset(w * 0.24f, h * 0.44f),
            size = Size(w * 0.52f, h * 0.42f)
        )
        // Duck head
        drawCircle(
            brush = Brush.verticalGradient(listOf(Color(0xFFFFEA85), Color(0xFFFFCA28))),
            radius = w * 0.21f,
            center = Offset(cx, h * 0.34f)
        )
        // Detective hat
        val brim = Path().apply {
            moveTo(w * 0.22f, h * 0.22f)
            quadraticTo(cx, h * 0.16f, w * 0.78f, h * 0.22f)
            lineTo(w * 0.70f, h * 0.25f)
            quadraticTo(cx, h * 0.20f, w * 0.30f, h * 0.25f)
            close()
        }
        drawPath(brim, color = Color(0xFF8D6E63))
        drawOval(
            color = Color(0xFFA1887F),
            topLeft = Offset(w * 0.32f, h * 0.10f),
            size = Size(w * 0.36f, h * 0.13f)
        )
        // Eyes
        drawCircle(color = Color(0xFF212121), radius = w * 0.028f, center = Offset(cx - w * 0.07f, h * 0.32f))
        drawCircle(color = Color(0xFF212121), radius = w * 0.028f, center = Offset(cx + w * 0.07f, h * 0.32f))
        // Orange beak
        drawOval(
            color = Color(0xFFFF7043),
            topLeft = Offset(cx - w * 0.07f, h * 0.36f),
            size = Size(w * 0.14f, h * 0.07f)
        )
        // Open blue book
        val leftPage = Path().apply {
            moveTo(cx, h * 0.62f)
            lineTo(w * 0.22f, h * 0.52f)
            lineTo(w * 0.24f, h * 0.80f)
            lineTo(cx, h * 0.88f)
            close()
        }
        val rightPage = Path().apply {
            moveTo(cx, h * 0.62f)
            lineTo(w * 0.78f, h * 0.52f)
            lineTo(w * 0.76f, h * 0.80f)
            lineTo(cx, h * 0.88f)
            close()
        }
        drawPath(leftPage, color = Color(0xFF29B6F6))
        drawPath(rightPage, color = Color(0xFF039BE5))
        drawPath(leftPage, color = Color(0xFFE1F5FE), style = Stroke(width = w * 0.02f))
        drawPath(rightPage, color = Color(0xFFE1F5FE), style = Stroke(width = w * 0.02f))

        // Magnifying glass
        drawCircle(
            color = Color(0xFF37474F),
            radius = w * 0.11f,
            center = Offset(cx + w * 0.11f, h * 0.42f),
            style = Stroke(width = w * 0.032f)
        )
        drawCircle(
            color = Color(0x66B3E5FC),
            radius = w * 0.095f,
            center = Offset(cx + w * 0.11f, h * 0.42f)
        )
        drawLine(
            color = Color(0xFF37474F),
            start = Offset(cx + w * 0.18f, h * 0.49f),
            end = Offset(cx + w * 0.28f, h * 0.60f),
            strokeWidth = w * 0.04f,
            cap = StrokeCap.Round
        )
    }
}

@Composable
fun SvgDoodleWallpaper(
    theme: WallpaperTheme,
    isDark: Boolean,
    modifier: Modifier = Modifier
) {
    val (topColor, bottomColor, patternColor) = when {
        isDark || theme == WallpaperTheme.MIDNIGHT_DARK ->
            Triple(WallpaperDarkTop, WallpaperDarkBottom, WallpaperDarkPattern)
        theme == WallpaperTheme.OCEAN_BLUE ->
            Triple(WallpaperOceanTop, WallpaperOceanBottom, WallpaperOceanPattern)
        theme == WallpaperTheme.LAVENDER_DUSK ->
            Triple(WallpaperLavenderTop, WallpaperLavenderBottom, WallpaperLavenderPattern)
        else ->
            Triple(WallpaperGreenTop, WallpaperGreenBottom, WallpaperGreenPattern)
    }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(topColor, bottomColor)))
    ) {
        val step = 110.dp.toPx()
        val cols = (size.width / step).toInt() + 2
        val rows = (size.height / step).toInt() + 2
        val stroke = Stroke(width = 1.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)

        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val x = c * step + if (r % 2 == 1) step * 0.45f else 0f
                val y = r * step
                val kind = (r * 3 + c) % 5
                when (kind) {
                    0 -> drawDoodlePlane(x, y, 22.dp.toPx(), patternColor, stroke)
                    1 -> drawDoodleStar(x, y, 16.dp.toPx(), patternColor, stroke)
                    2 -> drawDoodleMoon(x, y, 16.dp.toPx(), patternColor, stroke)
                    3 -> drawDoodleCrown(x, y, 18.dp.toPx(), patternColor, stroke)
                    else -> drawDoodleCloud(x, y, 24.dp.toPx(), patternColor, stroke)
                }
            }
        }
    }
}

private fun DrawScope.drawDoodlePlane(cx: Float, cy: Float, s: Float, color: Color, stroke: Stroke) {
    val p = Path().apply {
        moveTo(cx - s * 0.5f, cy)
        lineTo(cx + s * 0.5f, cy - s * 0.4f)
        lineTo(cx + s * 0.2f, cy + s * 0.45f)
        lineTo(cx - s * 0.05f, cy + s * 0.15f)
        close()
    }
    drawPath(p, color = color, style = stroke)
}

private fun DrawScope.drawDoodleStar(cx: Float, cy: Float, s: Float, color: Color, stroke: Stroke) {
    drawPath(buildStarPath(cx, cy, s, s * 0.45f, 5), color = color, style = stroke)
}

private fun DrawScope.drawDoodleMoon(cx: Float, cy: Float, s: Float, color: Color, stroke: Stroke) {
    val p = Path().apply {
        moveTo(cx + s * 0.25f, cy - s * 0.7f)
        cubicTo(cx - s * 0.6f, cy - s * 0.4f, cx - s * 0.6f, cy + s * 0.5f, cx + s * 0.25f, cy + s * 0.7f)
        cubicTo(cx - s * 0.1f, cy + s * 0.35f, cx - s * 0.1f, cy - s * 0.35f, cx + s * 0.25f, cy - s * 0.7f)
        close()
    }
    drawPath(p, color = color, style = stroke)
}

private fun DrawScope.drawDoodleCrown(cx: Float, cy: Float, s: Float, color: Color, stroke: Stroke) {
    val p = Path().apply {
        moveTo(cx - s * 0.55f, cy + s * 0.35f)
        lineTo(cx - s * 0.65f, cy - s * 0.30f)
        lineTo(cx - s * 0.25f, cy + s * 0.02f)
        lineTo(cx, cy - s * 0.45f)
        lineTo(cx + s * 0.25f, cy + s * 0.02f)
        lineTo(cx + s * 0.65f, cy - s * 0.30f)
        lineTo(cx + s * 0.55f, cy + s * 0.35f)
        close()
    }
    drawPath(p, color = color, style = stroke)
}

private fun DrawScope.drawDoodleCloud(cx: Float, cy: Float, s: Float, color: Color, stroke: Stroke) {
    drawRoundRect(
        color = color,
        topLeft = Offset(cx - s * 0.5f, cy - s * 0.2f),
        size = Size(s, s * 0.52f),
        cornerRadius = CornerRadius(s * 0.26f, s * 0.26f),
        style = stroke
    )
}

private fun buildStarPath(cx: Float, cy: Float, outerR: Float, innerR: Float, points: Int): Path {
    val path = Path()
    val total = points * 2
    for (i in 0 until total) {
        val angle = (i * PI / points) - PI / 2.0
        val r = if (i % 2 == 0) outerR else innerR
        val x = cx + (r * cos(angle)).toFloat()
        val y = cy + (r * sin(angle)).toFloat()
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    return path
}

@Composable
fun SvgComposeNewChatIcon(
    modifier: Modifier = Modifier,
    color: Color = Color.White,
    plusCutoutColor: Color = TgBlue
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val bubble = Path().apply {
            moveTo(w * 0.16f, h * 0.28f)
            quadraticTo(w * 0.16f, h * 0.14f, w * 0.30f, h * 0.14f)
            lineTo(w * 0.72f, h * 0.14f)
            quadraticTo(w * 0.86f, h * 0.14f, w * 0.86f, h * 0.28f)
            lineTo(w * 0.86f, h * 0.62f)
            quadraticTo(w * 0.86f, h * 0.76f, w * 0.72f, h * 0.76f)
            lineTo(w * 0.36f, h * 0.76f)
            lineTo(w * 0.18f, h * 0.88f)
            lineTo(w * 0.21f, h * 0.72f)
            quadraticTo(w * 0.16f, h * 0.68f, w * 0.16f, h * 0.62f)
            close()
        }
        drawPath(bubble, color = color)

        val strokeW = size.minDimension * 0.10f
        drawLine(
            color = plusCutoutColor,
            start = Offset(w * 0.51f, h * 0.31f),
            end = Offset(w * 0.51f, h * 0.59f),
            strokeWidth = strokeW,
            cap = StrokeCap.Round
        )
        drawLine(
            color = plusCutoutColor,
            start = Offset(w * 0.37f, h * 0.45f),
            end = Offset(w * 0.65f, h * 0.45f),
            strokeWidth = strokeW,
            cap = StrokeCap.Round
        )
    }
}

@Composable
fun SvgGreetingIllustration(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val cx = w * 0.5f

        // Soft glowing circle base
        drawCircle(
            brush = Brush.radialGradient(listOf(Color(0x33FFFFFF), Color.Transparent)),
            radius = w * 0.46f,
            center = Offset(cx, h * 0.52f)
        )
        // Friendly mascot body
        drawOval(
            brush = Brush.verticalGradient(listOf(Color(0xFFFFEA75), Color(0xFFFFB703))),
            topLeft = Offset(w * 0.26f, h * 0.42f),
            size = Size(w * 0.46f, h * 0.42f)
        )
        // Mascot head
        drawCircle(
            brush = Brush.verticalGradient(listOf(Color(0xFFFFF099), Color(0xFFFFCA28))),
            radius = w * 0.21f,
            center = Offset(cx, h * 0.34f)
        )
        // Eyes
        drawCircle(color = Color(0xFF1B1E23), radius = w * 0.028f, center = Offset(cx - w * 0.07f, h * 0.32f))
        drawCircle(color = Color(0xFF1B1E23), radius = w * 0.028f, center = Offset(cx + w * 0.07f, h * 0.32f))
        // Orange beak
        drawOval(
            color = Color(0xFFFF6D3B),
            topLeft = Offset(cx - w * 0.07f, h * 0.36f),
            size = Size(w * 0.14f, h * 0.065f)
        )
        // Waving wing raised with sparkles
        rotate(degrees = -26f, pivot = Offset(w * 0.72f, h * 0.48f)) {
            drawOval(
                brush = Brush.verticalGradient(listOf(Color(0xFFFFE566), Color(0xFFFFA000))),
                topLeft = Offset(w * 0.64f, h * 0.28f),
                size = Size(w * 0.18f, h * 0.28f)
            )
        }
        // Motion arcs
        drawArc(
            color = Color.White.copy(alpha = 0.85f),
            startAngle = -70f,
            sweepAngle = 55f,
            useCenter = false,
            topLeft = Offset(w * 0.68f, h * 0.16f),
            size = Size(w * 0.22f, h * 0.22f),
            style = Stroke(width = w * 0.028f, cap = StrokeCap.Round)
        )
        // Small sparkling paper plane badge held by mascot
        val plane = Path().apply {
            moveTo(w * 0.18f, h * 0.56f)
            lineTo(w * 0.44f, h * 0.48f)
            lineTo(w * 0.34f, h * 0.70f)
            lineTo(w * 0.27f, h * 0.62f)
            close()
        }
        drawPath(plane, color = TgBlue)
    }
}

