package com.example.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Forward
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.rounded.Reply
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.outlined.AttachFile
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.NotificationsOff
import androidx.compose.material.icons.outlined.Poll
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.SentimentSatisfied
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.CardGiftcard
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Done
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.example.audio.VoicePlaybackState
import com.example.audio.VoiceRecordingState
import com.example.data.model.ChatMessage
import com.example.data.model.ChatThread
import com.example.data.model.ChatType
import com.example.data.model.GiftKind
import com.example.data.model.MessageKind
import com.example.data.model.OwnedGift
import com.example.data.model.PollData
import com.example.data.model.ReactionType
import com.example.data.model.WallpaperTheme
import com.example.data.repository.ForkGramRepository
import com.example.ui.components.AvatarView
import com.example.ui.components.GiftDetailBottomSheet
import com.example.ui.components.GiftShopBottomSheet
import com.example.ui.components.TelegramChatBubbleShape
import com.example.ui.components.TelegramOutlinedField
import com.example.ui.svg.AnimatedTelegramGift
import com.example.ui.svg.SvgDoodleWallpaper
import com.example.ui.svg.SvgGiftArtwork
import com.example.ui.svg.SvgGramGemIcon
import com.example.ui.svg.SvgReactionIcon
import com.example.ui.svg.SvgStarIcon
import com.example.ui.svg.SvgVerifiedBadge
import com.example.ui.svg.TelegramGiftBackdropBox
import com.example.ui.theme.DangerRed
import com.example.ui.theme.GramCyan
import com.example.ui.theme.LocalForkPalette
import com.example.ui.theme.PremiumViolet
import com.example.ui.theme.StarGold
import com.example.ui.theme.TgBlue
import androidx.compose.runtime.CompositionLocalProvider
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.roundToInt

private sealed interface ChatRowEntry {
    data class DateHeader(val label: String) : ChatRowEntry
    data class MessageRow(
        val message: ChatMessage,
        val isFirstInGroup: Boolean,
        val hasTail: Boolean,
        val isHighlighted: Boolean
    ) : ChatRowEntry
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ChatDetailScreen(
    chat: ChatThread?,
    messages: List<ChatMessage>,
    allChats: List<ChatThread>,
    starsBalance: Long,
    gramBalance: Double,
    wallpaperTheme: WallpaperTheme,
    chatTextSizeSp: Int,
    voiceRecordingState: VoiceRecordingState,
    voicePlaybackState: VoicePlaybackState,
    currentUserEmail: String = "",
    onBack: () -> Unit,
    onOpenPeerProfile: () -> Unit,
    onSendText: (String, ChatMessage?, Boolean, Int) -> Unit,
    onSendPhoto: (Uri, String, ChatMessage?) -> Unit,
    onSendFile: (Uri) -> Unit,
    onStartVoiceRecording: (Boolean) -> Unit,
    onFinishVoiceRecording: (Boolean) -> Unit,
    onToggleVoicePlay: (ChatMessage) -> Unit,
    onSeekVoice: (String, Float) -> Unit = { _, _ -> },
    onCycleVoiceSpeed: () -> Unit = {},
    onSendLocation: (String) -> Unit,
    onSendPoll: (String, List<String>) -> Unit = { _, _ -> },
    onVotePoll: (String, Int) -> Unit = { _, _ -> },
    onSendGift: (GiftKind, Boolean, String) -> Unit,
    onSendGram: (Double, String) -> Unit,
    onForwardMessage: (ChatMessage, String) -> Unit,
    onEditMessage: (String, String) -> Unit,
    onDeleteMessage: (String) -> Unit,
    onTogglePinMessage: (String) -> Unit,
    onToggleReaction: (String, String) -> Unit,
    onToggleBlockChat: () -> Unit,
    onToggleMuteChat: () -> Unit,
    onDraftChanged: (String) -> Unit = {},
    onTypingChanged: (Boolean) -> Unit = {},
    onAddContact: () -> Unit = {},
    onStartCall: (Boolean) -> Unit = {},
    onLookupNft: suspend (GiftKind, Int) -> OwnedGift? = { _, _ -> null },
    onShowToast: (String) -> Unit
) {
    val palette = LocalForkPalette.current
    val context = LocalContext.current
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    var inputText by remember(chat?.id) { mutableStateOf(chat?.draftText.orEmpty()) }
    var draftLoaded by remember(chat?.id) { mutableStateOf(false) }
    var replyingTo by remember { mutableStateOf<ChatMessage?>(null) }
    var editingMessage by remember { mutableStateOf<ChatMessage?>(null) }
    var selectedContextMessage by remember { mutableStateOf<ChatMessage?>(null) }
    var forwardingMessage by remember { mutableStateOf<ChatMessage?>(null) }
    var showAttachmentSheet by remember { mutableStateOf(false) }
    var showStickerGiftPanel by remember { mutableStateOf(false) }
    var stickerTabIndex by remember { mutableIntStateOf(0) }
    var showGiftShop by remember { mutableStateOf(false) }
    var showGramSendDialog by remember { mutableStateOf(false) }
    var showOverflowMenu by remember { mutableStateOf(false) }
    var showContactBanner by remember { mutableStateOf(true) }
    var selectedGiftDetailMessage by remember { mutableStateOf<ChatMessage?>(null) }
    var nftSheetGift by remember { mutableStateOf<OwnedGift?>(null) }
    val openNftLink: (GiftKind, Int) -> Unit = { kind, number ->
        scope.launch {
            val found = onLookupNft(kind, number)
            if (found != null) nftSheetGift = found else onShowToast("NFT ${kind.title} #$number не найден")
        }
    }
    var fullscreenPhotoUri by remember { mutableStateOf<String?>(null) }
    var showInChatSearch by remember { mutableStateOf(false) }
    var inChatSearchQuery by remember { mutableStateOf("") }
    var activeMatchCursor by remember { mutableIntStateOf(0) }
    var showSendOptionsMenu by remember { mutableStateOf(false) }
    var showCreatePollDialog by remember { mutableStateOf(false) }

    LaunchedEffect(chat?.id, chat?.draftText) {
        if (!draftLoaded && chat != null) {
            if (inputText.isEmpty() && chat.draftText.isNotBlank()) {
                inputText = chat.draftText
            }
            draftLoaded = true
        }
    }

    DisposableEffect(chat?.id) {
        onDispose {
            onDraftChanged(inputText)
            onTypingChanged(false)
        }
    }

    val handleBack: () -> Unit = {
        onDraftChanged(inputText)
        onTypingChanged(false)
        onBack()
    }

    BackHandler {
        when {
            fullscreenPhotoUri != null -> fullscreenPhotoUri = null
            selectedContextMessage != null -> selectedContextMessage = null
            showInChatSearch -> {
                showInChatSearch = false
                inChatSearchQuery = ""
            }
            showStickerGiftPanel -> showStickerGiftPanel = false
            else -> handleBack()
        }
    }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onSendPhoto(uri, inputText, replyingTo)
            inputText = ""
            onDraftChanged("")
            onTypingChanged(false)
            replyingTo = null
        }
    }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onSendFile(uri)
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        onStartVoiceRecording(granted)
    }

    val searchQueryClean = inChatSearchQuery.trim().lowercase()
    val matchingMessageIds = remember(messages, searchQueryClean) {
        if (searchQueryClean.isEmpty()) emptyList()
        else messages.filter {
            it.text.lowercase().contains(searchQueryClean) ||
                (it.fileName?.lowercase()?.contains(searchQueryClean) == true)
        }.map { it.id }
    }
    val focusedMatchId = matchingMessageIds.getOrNull(
        activeMatchCursor.coerceIn(0, (matchingMessageIds.size - 1).coerceAtLeast(0))
    )

    val rowEntries = remember(messages, focusedMatchId) {
        val out = mutableListOf<ChatRowEntry>()
        val groupedByDate = messages.groupBy { it.dateGroup }
        groupedByDate.forEach { (dateLabel, dayMsgs) ->
            out.add(ChatRowEntry.DateHeader(dateLabel))
            dayMsgs.forEachIndexed { idx, msg ->
                val prev = dayMsgs.getOrNull(idx - 1)
                val next = dayMsgs.getOrNull(idx + 1)
                val isFirstInGroup = prev == null ||
                    prev.kind == MessageKind.SYSTEM ||
                    prev.isOutgoing != msg.isOutgoing ||
                    (msg.timestampMillis - prev.timestampMillis) > 120_000L
                val hasTail = next == null ||
                    next.kind == MessageKind.SYSTEM ||
                    next.isOutgoing != msg.isOutgoing ||
                    (next.timestampMillis - msg.timestampMillis) > 120_000L
                out.add(
                    ChatRowEntry.MessageRow(
                        message = msg,
                        isFirstInGroup = isFirstInGroup,
                        hasTail = hasTail,
                        isHighlighted = msg.id == focusedMatchId
                    )
                )
            }
        }
        out
    }

    val showScrollToBottom by remember {
        derivedStateOf {
            val lastVisible = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            rowEntries.isNotEmpty() && lastVisible < rowEntries.lastIndex - 1
        }
    }

    LaunchedEffect(rowEntries.size) {
        if (rowEntries.isNotEmpty() && !showInChatSearch) {
            listState.animateScrollToItem(rowEntries.lastIndex)
        }
    }

    LaunchedEffect(focusedMatchId) {
        if (focusedMatchId != null) {
            val idx = rowEntries.indexOfFirst { it is ChatRowEntry.MessageRow && it.message.id == focusedMatchId }
            if (idx >= 0) {
                listState.animateScrollToItem(idx)
            }
        }
    }

    CompositionLocalProvider(LocalNftLinkHandler provides openNftLink) {
    Box(modifier = Modifier.fillMaxSize()) {
        // Classic Telegram SVG Doodle Wallpaper
        SvgDoodleWallpaper(
            theme = wallpaperTheme,
            isDark = palette.isDark
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
        ) {
            val glassBorder = BorderStroke(0.5.dp, palette.divider.copy(alpha = 0.65f))

            // Top Header: In-Chat Search OR Floating Pill Header (1:1 Telegram)
            if (showInChatSearch) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = palette.surface.copy(alpha = 0.96f),
                    border = glassBorder,
                    shadowElevation = 3.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                        .height(44.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = {
                                showInChatSearch = false
                                inChatSearchQuery = ""
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Закрыть поиск", tint = palette.textPrimary)
                        }
                        Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                            if (inChatSearchQuery.isEmpty()) {
                                Text("Поиск по сообщениям...", color = palette.textSecondary, fontSize = 14.5.sp)
                            }
                            BasicTextField(
                                value = inChatSearchQuery,
                                onValueChange = {
                                    inChatSearchQuery = it
                                    activeMatchCursor = 0
                                },
                                singleLine = true,
                                textStyle = TextStyle(color = palette.textPrimary, fontSize = 14.5.sp),
                                cursorBrush = SolidColor(TgBlue),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        if (matchingMessageIds.isNotEmpty()) {
                            Text(
                                text = "${activeMatchCursor + 1}/${matchingMessageIds.size}",
                                fontSize = 12.sp,
                                color = palette.textSecondary,
                                modifier = Modifier.padding(end = 4.dp)
                            )
                            IconButton(
                                onClick = {
                                    activeMatchCursor = if (activeMatchCursor > 0) activeMatchCursor - 1 else matchingMessageIds.lastIndex
                                },
                                modifier = Modifier.size(30.dp)
                            ) {
                                Icon(Icons.Rounded.KeyboardArrowUp, contentDescription = "Предыдущее", tint = palette.textPrimary)
                            }
                            IconButton(
                                onClick = {
                                    activeMatchCursor = (activeMatchCursor + 1) % matchingMessageIds.size
                                },
                                modifier = Modifier.size(30.dp)
                            ) {
                                Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = "Следующее", tint = palette.textPrimary)
                            }
                        }
                    }
                }
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = CircleShape,
                        color = palette.surface.copy(alpha = 0.93f),
                        border = glassBorder,
                        shadowElevation = 3.dp,
                        modifier = Modifier.size(42.dp)
                    ) {
                        IconButton(onClick = handleBack, modifier = Modifier.testTag("chat_back_button")) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Назад",
                                tint = palette.textPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        color = palette.surface.copy(alpha = 0.93f),
                        border = glassBorder,
                        shadowElevation = 3.dp,
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .clickable { onOpenPeerProfile() }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AvatarView(
                                title = chat?.title ?: "Чат",
                                avatarUri = chat?.avatarUri,
                                colorHex = chat?.avatarColorHex ?: 0xFF2AABEE,
                                size = 34.dp,
                                chatType = chat?.chatType
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = chat?.title ?: "Чат",
                                        fontSize = 15.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = palette.textPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f, fill = false)
                                    )
                                    if (chat?.isVerified == true) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        SvgVerifiedBadge(modifier = Modifier.size(15.dp), badgeColor = TgBlue)
                                    } else if (chat?.statusGiftKind != null) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        SvgGiftArtwork(giftKind = chat.statusGiftKind, modifier = Modifier.size(15.dp))
                                    }
                                }
                                Text(
                                    text = when {
                                        chat?.isTyping == true -> "печатает..."
                                        chat?.isOnline == true -> "в сети"
                                        else -> chat?.subtitle ?: ""
                                    },
                                    fontSize = 12.sp,
                                    color = if (chat?.isTyping == true || chat?.isOnline == true) TgBlue else palette.textSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        color = palette.surface.copy(alpha = 0.93f),
                        border = glassBorder,
                        shadowElevation = 3.dp,
                        modifier = Modifier.height(42.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (chat?.chatType == ChatType.DIRECT || chat?.chatType == ChatType.SECRET) {
                                IconButton(
                                    onClick = { onStartCall(false) },
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Call,
                                        contentDescription = "Позвонить",
                                        tint = palette.textPrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                            Box {
                                IconButton(
                                    onClick = { showOverflowMenu = true },
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.MoreVert,
                                        contentDescription = "Опции",
                                        tint = palette.textPrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                DropdownMenu(
                                    expanded = showOverflowMenu,
                                    onDismissRequest = { showOverflowMenu = false },
                                    shape = RoundedCornerShape(16.dp),
                                    containerColor = palette.surface
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("Поиск", color = palette.textPrimary) },
                                        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = palette.textPrimary) },
                                        onClick = {
                                            showOverflowMenu = false
                                            showInChatSearch = true
                                        }
                                    )
                                    if (chat?.chatType == ChatType.DIRECT || chat?.chatType == ChatType.SECRET) {
                                        DropdownMenuItem(
                                            text = { Text("Видеозвонок", color = palette.textPrimary) },
                                            leadingIcon = { Icon(Icons.Rounded.Videocam, contentDescription = null, tint = TgBlue) },
                                            onClick = {
                                                showOverflowMenu = false
                                                onStartCall(true)
                                            }
                                        )
                                    }
                                    DropdownMenuItem(
                                        text = { Text("Отправить подарок", color = palette.textPrimary) },
                                        leadingIcon = {
                                            Icon(Icons.Rounded.CardGiftcard, contentDescription = null, tint = TgBlue)
                                        },
                                        onClick = {
                                            showOverflowMenu = false
                                            showGiftShop = true
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Перевести Gram", color = palette.textPrimary) },
                                        leadingIcon = {
                                            SvgGramGemIcon(modifier = Modifier.size(20.dp))
                                        },
                                        onClick = {
                                            showOverflowMenu = false
                                            showGramSendDialog = true
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                if (chat?.isMuted == true) "Включить звук" else "Без звука",
                                                color = palette.textPrimary
                                            )
                                        },
                                        onClick = {
                                            showOverflowMenu = false
                                            onToggleMuteChat()
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                if (chat?.isBlocked == true) "Разблокировать" else "Заблокировать",
                                                color = DangerRed
                                            )
                                        },
                                        onClick = {
                                            showOverflowMenu = false
                                            onToggleBlockChat()
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Top Two-Row Action Banner
            if (showContactBanner && (chat?.chatType == ChatType.DIRECT || chat?.chatType == ChatType.SERVICE)) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = palette.surface.copy(alpha = 0.94f),
                    border = glassBorder,
                    shadowElevation = 2.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 2.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Добавить контакт",
                                color = TgBlue,
                                fontWeight = FontWeight.Medium,
                                fontSize = 14.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        onAddContact()
                                        showContactBanner = false
                                    }
                                    .padding(vertical = 2.dp)
                            )
                            Text(
                                text = if (chat.isBlocked) "Разблокировать" else "Заблокировать",
                                color = DangerRed,
                                fontWeight = FontWeight.Medium,
                                fontSize = 14.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onToggleBlockChat() }
                                    .padding(vertical = 2.dp)
                            )
                            IconButton(
                                onClick = { showContactBanner = false },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = "Скрыть",
                                    tint = palette.textSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        if (chat.chatType == ChatType.DIRECT) {
                            HorizontalDivider(
                                color = palette.divider.copy(alpha = 0.7f),
                                thickness = 0.5.dp
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { showGiftShop = true }
                                    .padding(horizontal = 14.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                AnimatedTelegramGift(
                                    giftKind = GiftKind.PLUSH_PEPE,
                                    editionNumber = 144,
                                    animate = true,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "— значок для Premium-пользователей",
                                    color = palette.textPrimary,
                                    fontSize = 13.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Icon(
                                    imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                                    contentDescription = "Открыть подарки",
                                    tint = palette.textSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Pinned Message Banner
            val pinnedMsg = messages.firstOrNull { it.isPinned }
            if (pinnedMsg != null) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = palette.surface.copy(alpha = 0.94f),
                    shadowElevation = 2.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 3.dp)
                        .clickable {
                            val idx = rowEntries.indexOfFirst { it is ChatRowEntry.MessageRow && it.message.id == pinnedMsg.id }
                            if (idx >= 0) scope.launch { listState.animateScrollToItem(idx) }
                        }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height(26.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(TgBlue)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Закреплённое сообщение",
                                color = TgBlue,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = pinnedMsg.text,
                                color = palette.textPrimary,
                                fontSize = 13.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(
                            onClick = { onTogglePinMessage(pinnedMsg.id) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = "Открепить",
                                tint = palette.textSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            // Messages List or Empty DM Greeting Card
            if (messages.isEmpty() && chat?.chatType == ChatType.DIRECT) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = if (palette.isDark) Color(0xBD1D2E3E) else Color(0xB83A6334),
                        modifier = Modifier
                            .widthIn(max = 264.dp)
                            .clickable { onSendText("Привет!", null, false, 0) }
                            .testTag("empty_chat_greeting_card")
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Здесь пока ничего нет...",
                                color = Color.White,
                                fontSize = 15.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Отправьте сообщение или нажмите на приветствие ниже.",
                                color = Color.White.copy(alpha = 0.88f),
                                fontSize = 13.5.sp,
                                lineHeight = 18.sp,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            AnimatedTelegramGift(
                                giftKind = GiftKind.PLUSH_PEPE,
                                editionNumber = 144,
                                animate = true,
                                modifier = Modifier.size(112.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Отправить «Привет!»",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp)
                    ) {
                        itemsIndexed(
                            items = rowEntries,
                            key = { _, entry ->
                                when (entry) {
                                    is ChatRowEntry.DateHeader -> "date_${entry.label}"
                                    is ChatRowEntry.MessageRow -> entry.message.id
                                }
                            }
                        ) { _, entry ->
                            when (entry) {
                                is ChatRowEntry.DateHeader -> {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Surface(
                                            shape = RoundedCornerShape(14.dp),
                                            color = palette.datePillBg
                                        ) {
                                            Text(
                                                text = entry.label,
                                                color = Color.White,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Medium,
                                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 3.dp)
                                            )
                                        }
                                    }
                                }

                                is ChatRowEntry.MessageRow -> {
                                    val msg = entry.message
                                    val bottomGap = if (entry.hasTail) 7.dp else 2.dp
                                    if (msg.kind == MessageKind.SYSTEM) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 4.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Surface(
                                                shape = RoundedCornerShape(14.dp),
                                                color = palette.datePillBg
                                            ) {
                                                Text(
                                                    text = msg.text,
                                                    color = Color.White,
                                                    fontSize = 12.5.sp,
                                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                                                )
                                            }
                                        }
                                    } else {
                                        Column {
                                            MessageBubbleItem(
                                                message = msg,
                                                currentUserEmail = currentUserEmail,
                                                isFirstInGroup = entry.isFirstInGroup,
                                                hasTail = entry.hasTail,
                                                isHighlighted = entry.isHighlighted,
                                                textSizeSp = chatTextSizeSp,
                                                playbackState = voicePlaybackState,
                                                onLongPress = { selectedContextMessage = msg },
                                                onSwipeReply = {
                                                    replyingTo = msg
                                                    editingMessage = null
                                                },
                                                onTapPhoto = { uri -> fullscreenPhotoUri = uri },
                                                onTapVoicePlay = { onToggleVoicePlay(msg) },
                                                onSeekVoice = { fraction -> onSeekVoice(msg.id, fraction) },
                                                onCycleVoiceSpeed = onCycleVoiceSpeed,
                                                onTapReplyQuote = { replyId ->
                                                    val targetIdx = rowEntries.indexOfFirst {
                                                        it is ChatRowEntry.MessageRow && it.message.id == replyId
                                                    }
                                                    if (targetIdx >= 0) {
                                                        scope.launch { listState.animateScrollToItem(targetIdx) }
                                                    }
                                                },
                                                onTapReaction = { key -> onToggleReaction(msg.id, key) },
                                                onTapGift = { clicked ->
                                                    val k = clicked.giftKind
                                                    if (clicked.isNftGift && k != null) {
                                                        openNftLink(k, clicked.giftNumber ?: 1)
                                                    } else {
                                                        selectedGiftDetailMessage = clicked
                                                    }
                                                },
                                                onVotePoll = { optionIdx -> onVotePoll(msg.id, optionIdx) }
                                            )
                                            Spacer(modifier = Modifier.height(bottomGap))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Scroll-to-Bottom Floating Button (1:1 Telegram)
                    androidx.compose.animation.AnimatedVisibility(
                        visible = showScrollToBottom,
                        enter = fadeIn() + scaleIn(),
                        exit = fadeOut() + scaleOut(),
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(end = 14.dp, bottom = 12.dp)
                    ) {
                        SmallFloatingActionButton(
                            onClick = {
                                if (rowEntries.isNotEmpty()) {
                                    scope.launch { listState.animateScrollToItem(rowEntries.lastIndex) }
                                }
                            },
                            shape = CircleShape,
                            containerColor = palette.surface.copy(alpha = 0.95f),
                            contentColor = palette.textPrimary
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.KeyboardArrowDown,
                                contentDescription = "Вниз"
                            )
                        }
                    }
                }
            }

            // Reply or Edit Bar above Input
            val activeBannerMessage = editingMessage ?: replyingTo
            if (activeBannerMessage != null) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = palette.surface.copy(alpha = 0.96f),
                    shadowElevation = 2.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (editingMessage != null) Icons.Outlined.Edit else Icons.AutoMirrored.Rounded.Reply,
                            contentDescription = null,
                            tint = TgBlue,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (editingMessage != null) "Редактирование" else "Ответ: ${activeBannerMessage.senderName}",
                                color = TgBlue,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.5.sp
                            )
                            Text(
                                text = activeBannerMessage.text.ifBlank { activeBannerMessage.kind.name },
                                color = palette.textSecondary,
                                fontSize = 13.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(
                            onClick = {
                                replyingTo = null
                                if (editingMessage != null) {
                                    editingMessage = null
                                    inputText = ""
                                    onDraftChanged("")
                                }
                            },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(Icons.Rounded.Close, contentDescription = "Отмена", tint = palette.textSecondary)
                        }
                    }
                }
            }

            // Floating Pill Input Bar (1:1 Telegram!)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                if (voiceRecordingState.isRecording) {
                    Surface(
                        shape = RoundedCornerShape(26.dp),
                        color = palette.surface,
                        shadowElevation = 4.dp,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(DangerRed)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = ForkGramRepository.formatDuration(voiceRecordingState.durationSec),
                                color = palette.textPrimary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            WaveformBars(
                                amplitudes = voiceRecordingState.liveAmplitudes.ifEmpty { listOf(0.3f, 0.5f, 0.7f) },
                                progress = 1f,
                                activeColor = TgBlue,
                                inactiveColor = palette.textSecondary.copy(alpha = 0.35f),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(22.dp)
                            )
                            TextButton(onClick = { onFinishVoiceRecording(false) }) {
                                Text("Отмена", color = DangerRed, fontSize = 13.sp)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        shape = CircleShape,
                        color = TgBlue,
                        shadowElevation = 4.dp,
                        modifier = Modifier
                            .size(48.dp)
                            .clickable { onFinishVoiceRecording(true) }
                            .testTag("chat_voice_send_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Rounded.Stop,
                                contentDescription = "Отправить голосовое",
                                tint = Color.White
                            )
                        }
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(26.dp),
                        color = palette.surface.copy(alpha = 0.96f),
                        shadowElevation = 4.dp,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { showStickerGiftPanel = !showStickerGiftPanel },
                                modifier = Modifier.size(38.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.SentimentSatisfied,
                                    contentDescription = "Эмодзи, стикеры и подарки",
                                    tint = if (showStickerGiftPanel) TgBlue else palette.textSecondary
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(horizontal = 4.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                if (inputText.isEmpty()) {
                                    Text(
                                        text = "Сообщение",
                                        color = palette.textSecondary,
                                        fontSize = 16.sp
                                    )
                                }
                                BasicTextField(
                                    value = inputText,
                                    onValueChange = { next ->
                                        inputText = next
                                        onDraftChanged(next)
                                        onTypingChanged(next.isNotBlank())
                                    },
                                    maxLines = 4,
                                    textStyle = TextStyle(
                                        color = palette.textPrimary,
                                        fontSize = 16.sp
                                    ),
                                    cursorBrush = SolidColor(TgBlue),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("chat_message_input")
                                )
                            }

                            IconButton(
                                onClick = { showAttachmentSheet = true },
                                modifier = Modifier
                                    .size(38.dp)
                                    .testTag("chat_attach_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.AttachFile,
                                    contentDescription = "Вложение",
                                    tint = palette.textSecondary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Box {
                        Surface(
                            shape = CircleShape,
                            color = TgBlue,
                            shadowElevation = 4.dp,
                            modifier = Modifier
                                .size(48.dp)
                                .combinedClickable(
                                    onClick = {
                                        if (inputText.isNotBlank()) {
                                            val editing = editingMessage
                                            if (editing != null) {
                                                onEditMessage(editing.id, inputText)
                                                editingMessage = null
                                            } else {
                                                onSendText(inputText, replyingTo, false, 0)
                                                replyingTo = null
                                            }
                                            inputText = ""
                                            onDraftChanged("")
                                            onTypingChanged(false)
                                        } else {
                                            val granted = ContextCompat.checkSelfPermission(
                                                context,
                                                Manifest.permission.RECORD_AUDIO
                                            ) == PackageManager.PERMISSION_GRANTED
                                            if (granted) {
                                                onStartVoiceRecording(true)
                                            } else {
                                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                            }
                                        }
                                    },
                                    onLongClick = {
                                        if (inputText.isNotBlank() && editingMessage == null) {
                                            showSendOptionsMenu = true
                                        }
                                    }
                                )
                                .testTag("chat_send_or_mic_button")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = if (inputText.isNotBlank()) Icons.AutoMirrored.Rounded.Send else Icons.Outlined.Mic,
                                    contentDescription = if (inputText.isNotBlank()) "Отправить" else "Голосовое сообщение",
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = showSendOptionsMenu,
                            onDismissRequest = { showSendOptionsMenu = false },
                            shape = RoundedCornerShape(16.dp),
                            containerColor = palette.surface
                        ) {
                            DropdownMenuItem(
                                text = { Text("Отправить без звука", color = palette.textPrimary) },
                                leadingIcon = { Icon(Icons.Outlined.NotificationsOff, contentDescription = null, tint = TgBlue) },
                                onClick = {
                                    showSendOptionsMenu = false
                                    if (inputText.isNotBlank()) {
                                        onSendText(inputText, replyingTo, true, 0)
                                        replyingTo = null
                                        inputText = ""
                                        onDraftChanged("")
                                        onTypingChanged(false)
                                    }
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Запланировать (+10 мин)", color = palette.textPrimary) },
                                leadingIcon = { Icon(Icons.Outlined.Schedule, contentDescription = null, tint = TgBlue) },
                                onClick = {
                                    showSendOptionsMenu = false
                                    if (inputText.isNotBlank()) {
                                        onSendText(inputText, replyingTo, false, 10)
                                        replyingTo = null
                                        inputText = ""
                                        onDraftChanged("")
                                        onTypingChanged(false)
                                    }
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Запланировать (+1 час)", color = palette.textPrimary) },
                                leadingIcon = { Icon(Icons.Outlined.Schedule, contentDescription = null, tint = PremiumViolet) },
                                onClick = {
                                    showSendOptionsMenu = false
                                    if (inputText.isNotBlank()) {
                                        onSendText(inputText, replyingTo, false, 60)
                                        replyingTo = null
                                        inputText = ""
                                        onDraftChanged("")
                                        onTypingChanged(false)
                                    }
                                }
                            )
                        }
                    }
                }
            }

            // Tabbed Emoji / Stickers / Gifts Drawer (1:1 Telegram)
            AnimatedVisibility(visible = showStickerGiftPanel) {
                Surface(
                    color = palette.surface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(272.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("Эмодзи", "Стикеры", "Подарки").forEachIndexed { idx, label ->
                                    val active = stickerTabIndex == idx
                                    Surface(
                                        shape = RoundedCornerShape(14.dp),
                                        color = if (active) palette.accentSoft else palette.surfaceVariant,
                                        modifier = Modifier.clickable { stickerTabIndex = idx }
                                    ) {
                                        Text(
                                            text = label,
                                            fontSize = 12.5.sp,
                                            fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                                            color = if (active) TgBlue else palette.textSecondary,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                        )
                                    }
                                }
                            }
                            TextButton(onClick = {
                                showStickerGiftPanel = false
                                showGiftShop = true
                            }) {
                                Text("Магазин", color = TgBlue, fontSize = 13.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        when (stickerTabIndex) {
                            0 -> {
                                val emojis = remember {
                                    listOf(
                                        "❤️", "🔥", "👍", "😂", "😍", "🙏", "🎉", "✨",
                                        "😎", "🤔", "👏", "💯", "🚀", "💎", "🥳", "🤝",
                                        "😇", "🥹", "👌", "🎁", "⭐", "🫡", "🌟", "💬"
                                    )
                                }
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    emojis.chunked(8).forEach { rowEmojis ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            rowEmojis.forEach { em ->
                                                Box(
                                                    modifier = Modifier
                                                        .size(38.dp)
                                                        .clip(RoundedCornerShape(10.dp))
                                                        .clickable {
                                                            inputText += em
                                                            onDraftChanged(inputText)
                                                        },
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(em, fontSize = 22.sp)
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            1 -> {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    GiftKind.entries.take(8).forEachIndexed { idx, kind ->
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(14.dp))
                                                .background(palette.surfaceVariant)
                                                .clickable {
                                                    showStickerGiftPanel = false
                                                    onSendText("✨ ${kind.title}", replyingTo, false, 0)
                                                    replyingTo = null
                                                }
                                                .padding(10.dp)
                                        ) {
                                            AnimatedTelegramGift(
                                                giftKind = kind,
                                                animate = true,
                                                phaseOffsetMs = idx * 140,
                                                modifier = Modifier.size(78.dp)
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = kind.title,
                                                fontSize = 11.sp,
                                                color = palette.textSecondary,
                                                maxLines = 1
                                            )
                                        }
                                    }
                                }
                            }

                            else -> {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    GiftKind.entries.take(6).forEachIndexed { idx, gift ->
                                        TelegramGiftBackdropBox(
                                            backdrop = gift.defaultBackdrop,
                                            symbol = gift.defaultSymbol,
                                            modifier = Modifier
                                                .width(108.dp)
                                                .clip(RoundedCornerShape(16.dp))
                                                .clickable {
                                                    showStickerGiftPanel = false
                                                    onSendGift(gift, false, "Быстрый подарок")
                                                }
                                        ) {
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(8.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally
                                            ) {
                                                AnimatedTelegramGift(
                                                    giftKind = gift,
                                                    animate = true,
                                                    phaseOffsetMs = idx * 180,
                                                    modifier = Modifier.size(68.dp)
                                                )
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    SvgStarIcon(modifier = Modifier.size(12.dp), color = StarGold)
                                                    Spacer(modifier = Modifier.width(3.dp))
                                                    Text("${gift.baseStars}", fontSize = 11.5.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Blurred Scrim + Message Context Menu + SVG Reactions Bar (1:1 Telegram)
        AnimatedVisibility(
            visible = selectedContextMessage != null,
            enter = fadeIn() + scaleIn(initialScale = 0.94f),
            exit = fadeOut() + scaleOut(targetScale = 0.94f)
        ) {
            val target = selectedContextMessage
            if (target != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.45f))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { selectedContextMessage = null },
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // SVG Reactions Capsule
                        Surface(
                            shape = RoundedCornerShape(28.dp),
                            color = palette.surface,
                            shadowElevation = 8.dp
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                ReactionType.entries.forEach { reaction ->
                                    val active = target.reactionKey == reaction.key
                                    Box(
                                        modifier = Modifier
                                            .size(38.dp)
                                            .clip(CircleShape)
                                            .background(if (active) palette.accentSoft else Color.Transparent)
                                            .clickable {
                                                onToggleReaction(target.id, reaction.key)
                                                selectedContextMessage = null
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        SvgReactionIcon(
                                            type = reaction,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Highlighted selected message preview
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (target.isOutgoing) palette.bubbleOutgoing else palette.bubbleIncoming,
                            shadowElevation = 6.dp,
                            modifier = Modifier.widthIn(max = 280.dp)
                        ) {
                            Text(
                                text = target.text.ifBlank { target.kind.name },
                                color = palette.textPrimary,
                                fontSize = 14.5.sp,
                                maxLines = 3,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Context Menu Actions Card
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = palette.surface,
                            shadowElevation = 8.dp,
                            modifier = Modifier.widthIn(min = 220.dp, max = 260.dp)
                        ) {
                            Column(modifier = Modifier.padding(vertical = 4.dp)) {
                                ContextMenuRow(
                                    icon = Icons.AutoMirrored.Rounded.Reply,
                                    label = "Ответить",
                                    onClick = {
                                        replyingTo = target
                                        editingMessage = null
                                        selectedContextMessage = null
                                    }
                                )
                                ContextMenuRow(
                                    icon = Icons.Outlined.ContentCopy,
                                    label = "Копировать",
                                    onClick = {
                                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        cm.setPrimaryClip(ClipData.newPlainText("ForkGram", target.text))
                                        onShowToast("Текст скопирован")
                                        selectedContextMessage = null
                                    }
                                )
                                ContextMenuRow(
                                    icon = Icons.AutoMirrored.Rounded.Forward,
                                    label = "Переслать",
                                    onClick = {
                                        forwardingMessage = target
                                        selectedContextMessage = null
                                    }
                                )
                                ContextMenuRow(
                                    icon = Icons.Outlined.PushPin,
                                    label = if (target.isPinned) "Открепить" else "Закрепить",
                                    onClick = {
                                        onTogglePinMessage(target.id)
                                        selectedContextMessage = null
                                    }
                                )
                                if (target.isOutgoing && target.kind == MessageKind.TEXT) {
                                    ContextMenuRow(
                                        icon = Icons.Outlined.Edit,
                                        label = "Редактировать",
                                        onClick = {
                                            editingMessage = target
                                            replyingTo = null
                                            inputText = target.text
                                            selectedContextMessage = null
                                        }
                                    )
                                }
                                HorizontalDivider(color = palette.divider)
                                ContextMenuRow(
                                    icon = Icons.Outlined.DeleteOutline,
                                    label = "Удалить",
                                    tint = DangerRed,
                                    onClick = {
                                        onDeleteMessage(target.id)
                                        selectedContextMessage = null
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Fullscreen Photo Viewer
    fullscreenPhotoUri?.let { uri ->
        Dialog(
            onDismissRequest = { fullscreenPhotoUri = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
                    .clickable { fullscreenPhotoUri = null }
            ) {
                AsyncImage(
                    model = if (uri.startsWith("/")) File(uri) else uri,
                    contentDescription = "Фото",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
                IconButton(
                    onClick = { fullscreenPhotoUri = null },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .statusBarsPadding()
                        .padding(14.dp)
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.55f))
                ) {
                    Icon(Icons.Rounded.Close, contentDescription = "Закрыть", tint = Color.White)
                }
            }
        }
    }

    // Attachments Bottom Sheet
    if (showAttachmentSheet) {
        ModalBottomSheet(
            onDismissRequest = { showAttachmentSheet = false },
            containerColor = palette.surface,
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Прикрепить",
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold,
                    color = palette.textPrimary
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    AttachOptionItem(
                        icon = Icons.Outlined.Image,
                        color = Color(0xFF2AABEE),
                        label = "Галерея"
                    ) {
                        showAttachmentSheet = false
                        photoPicker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    }
                    AttachOptionItem(
                        icon = Icons.Outlined.Description,
                        color = Color(0xFF5C6BC0),
                        label = "Файл"
                    ) {
                        showAttachmentSheet = false
                        filePicker.launch(arrayOf("*/*"))
                    }
                    AttachOptionItem(
                        icon = Icons.Rounded.CardGiftcard,
                        color = PremiumViolet,
                        label = "Подарок"
                    ) {
                        showAttachmentSheet = false
                        showGiftShop = true
                    }
                    AttachOptionItem(
                        icon = Icons.Outlined.Poll,
                        color = Color(0xFFF5A623),
                        label = "Опрос"
                    ) {
                        showAttachmentSheet = false
                        showCreatePollDialog = true
                    }
                    AttachOptionItem(
                        icon = Icons.Outlined.LocationOn,
                        color = Color(0xFF46B966),
                        label = "Геопозиция"
                    ) {
                        showAttachmentSheet = false
                        onSendLocation("Москва, Пресненская наб., 12")
                    }
                }
            }
        }
    }

    // Create Poll Dialog
    if (showCreatePollDialog) {
        var pollQuestion by remember { mutableStateOf("") }
        var opt1 by remember { mutableStateOf("") }
        var opt2 by remember { mutableStateOf("") }
        var opt3 by remember { mutableStateOf("") }
        var opt4 by remember { mutableStateOf("") }
        val validOptions = listOf(opt1, opt2, opt3, opt4).map { it.trim() }.filter { it.isNotEmpty() }
        AlertDialog(
            onDismissRequest = { showCreatePollDialog = false },
            containerColor = palette.surface,
            shape = RoundedCornerShape(24.dp),
            title = { Text("Создать опрос", fontWeight = FontWeight.Bold, color = palette.textPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    TelegramOutlinedField(value = pollQuestion, onValueChange = { pollQuestion = it }, label = "Вопрос опроса")
                    TelegramOutlinedField(value = opt1, onValueChange = { opt1 = it }, label = "Вариант 1")
                    TelegramOutlinedField(value = opt2, onValueChange = { opt2 = it }, label = "Вариант 2")
                    TelegramOutlinedField(value = opt3, onValueChange = { opt3 = it }, label = "Вариант 3 (необяз.)")
                    TelegramOutlinedField(value = opt4, onValueChange = { opt4 = it }, label = "Вариант 4 (необяз.)")
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSendPoll(pollQuestion.trim(), validOptions)
                        showCreatePollDialog = false
                    },
                    enabled = pollQuestion.trim().isNotEmpty() && validOptions.size >= 2,
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TgBlue)
                ) {
                    Text("Создать", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreatePollDialog = false }) { Text("Отмена", color = palette.textSecondary) }
            }
        )
    }

    // Forward Picker Sheet
    forwardingMessage?.let { msgToForward ->
        ModalBottomSheet(
            onDismissRequest = { forwardingMessage = null },
            containerColor = palette.surface,
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp)
                    .padding(bottom = 26.dp)
            ) {
                Text(
                    text = "Переслать в...",
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold,
                    color = palette.textPrimary
                )
                Spacer(modifier = Modifier.height(10.dp))
                allChats.filter { !it.isArchived }.forEach { targetChat ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable {
                                onForwardMessage(msgToForward, targetChat.id)
                                forwardingMessage = null
                            }
                            .padding(vertical = 8.dp, horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AvatarView(
                            title = targetChat.title,
                            avatarUri = targetChat.avatarUri,
                            colorHex = targetChat.avatarColorHex,
                            size = 42.dp,
                            chatType = targetChat.chatType
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(targetChat.title, fontWeight = FontWeight.SemiBold, color = palette.textPrimary)
                            Text(targetChat.subtitle, fontSize = 12.sp, color = palette.textSecondary)
                        }
                    }
                }
            }
        }
    }

    // Gift Shop Sheet
    if (showGiftShop) {
        GiftShopBottomSheet(
            starsBalance = starsBalance,
            recipientName = chat?.title ?: "Чат",
            onDismiss = { showGiftShop = false },
            onSendGift = { kind, asNft, comment ->
                onSendGift(kind, asNft, comment)
                showGiftShop = false
            }
        )
    }

    // NFT из ссылки/пузыря: реальные атрибуты и владелец с сервера, шит по высоте контента (не на весь экран)
    nftSheetGift?.let { nft ->
        GiftDetailBottomSheet(
            gift = nft,
            collections = emptyList(),
            starsBalance = starsBalance,
            isOwnGift = false,
            ownerName = nft.ownerName,
            onDismiss = { nftSheetGift = null },
            onTogglePin = {},
            onToggleWearStatus = {},
            onAssignCollection = {},
            onUpgradeToNft = {},
            onConvertToStars = {},
            onShowToast = onShowToast
        )
    }

    // Clickable Gift Bubble -> Real Telegram NFT Gift Detail Sheet
    selectedGiftDetailMessage?.let { giftMsg ->
        val kind = giftMsg.giftKind ?: GiftKind.PLUSH_PEPE
        val edition = giftMsg.giftNumber ?: kind.validDemoEditions.firstOrNull() ?: 1
        val modelPair = kind.models.firstOrNull() ?: ("Original" to "1.5%")
        val syntheticGift = OwnedGift(
            id = giftMsg.id,
            giftKind = kind,
            editionNumber = edition,
            collectionName = "",
            modelName = modelPair.first,
            modelRarity = modelPair.second,
            backdrop = kind.defaultBackdrop,
            symbol = kind.defaultSymbol,
            senderName = giftMsg.senderName,
            messageText = giftMsg.text,
            starsValue = giftMsg.giftStarsValue.coerceAtLeast(kind.baseStars),
            isNft = giftMsg.isNftGift,
            isPinned = false,
            isWornAsStatus = false,
            receivedAt = giftMsg.timestampMillis
        )
        GiftDetailBottomSheet(
            gift = syntheticGift,
            collections = emptyList(),
            starsBalance = starsBalance,
            isOwnGift = false,
            onDismiss = { selectedGiftDetailMessage = null },
            onTogglePin = {},
            onToggleWearStatus = {},
            onAssignCollection = {},
            onUpgradeToNft = {},
            onConvertToStars = {},
            onShowToast = onShowToast
        )
    }

    // Send Gram Dialog
    if (showGramSendDialog) {
        var amountText by remember { mutableStateOf("2.5") }
        var note by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showGramSendDialog = false },
            containerColor = palette.surface,
            shape = RoundedCornerShape(24.dp),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SvgGramGemIcon(modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Перевод Gram", fontWeight = FontWeight.Bold, color = palette.textPrimary)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Доступно: ${ForkGramRepository.formatGram(gramBalance)} GRAM",
                        fontSize = 13.sp,
                        color = GramCyan,
                        fontWeight = FontWeight.SemiBold
                    )
                    TelegramOutlinedField(
                        value = amountText,
                        onValueChange = { amountText = it },
                        label = "Сумма GRAM"
                    )
                    TelegramOutlinedField(
                        value = note,
                        onValueChange = { note = it },
                        label = "Комментарий"
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = amountText.replace(",", ".").toDoubleOrNull() ?: 0.0
                        if (amt > 0) onSendGram(amt, note)
                        showGramSendDialog = false
                    },
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = GramCyan)
                ) {
                    Text("Отправить", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showGramSendDialog = false }) { Text("Отмена", color = palette.textSecondary) }
            }
        )
    }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MessageBubbleItem(
    message: ChatMessage,
    currentUserEmail: String,
    isFirstInGroup: Boolean,
    hasTail: Boolean,
    isHighlighted: Boolean,
    textSizeSp: Int,
    playbackState: VoicePlaybackState,
    onLongPress: () -> Unit,
    onSwipeReply: () -> Unit,
    onTapPhoto: (String) -> Unit,
    onTapVoicePlay: () -> Unit,
    onSeekVoice: (Float) -> Unit,
    onCycleVoiceSpeed: () -> Unit,
    onTapReplyQuote: (String) -> Unit,
    onTapReaction: (String) -> Unit,
    onTapGift: (ChatMessage) -> Unit,
    onVotePoll: (Int) -> Unit
) {
    val palette = LocalForkPalette.current
    val density = LocalDensity.current
    val replyTriggerPx = with(density) { 54.dp.toPx() }
    var swipeOffsetX by remember { mutableFloatStateOf(0f) }
    val animatedSwipeX by animateFloatAsState(targetValue = swipeOffsetX, label = "msgSwipeReply")

    val bubbleColor = if (isHighlighted) {
        TgBlue.copy(alpha = 0.28f)
    } else if (message.isOutgoing) {
        palette.bubbleOutgoing
    } else {
        palette.bubbleIncoming
    }
    val metaColor = if (message.isOutgoing) palette.bubbleOutgoingMeta else palette.textSecondary
    val shape = TelegramChatBubbleShape(
        isOutgoing = message.isOutgoing,
        hasTail = hasTail,
        cornerRadiusDp = 16.dp,
        isFirstInGroup = isFirstInGroup
    )
    val startPad = if (!message.isOutgoing && hasTail) 16.dp else if (!message.isOutgoing && !hasTail) 19.dp else 12.dp
    val endPad = if (message.isOutgoing && hasTail) 16.dp else if (message.isOutgoing && !hasTail) 19.dp else 12.dp

    Box(modifier = Modifier.fillMaxWidth()) {
        if (animatedSwipeX < -6f) {
            val replyAlpha = (-animatedSwipeX / replyTriggerPx).coerceIn(0f, 1f)
            Box(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 10.dp)
                    .size(32.dp)
                    .alpha(replyAlpha)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.25f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.Reply,
                    contentDescription = "Ответить",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .offset { IntOffset(animatedSwipeX.roundToInt(), 0) }
                .pointerInput(message.id) {
                    detectHorizontalDragGestures(
                        onDragEnd = {
                            if (swipeOffsetX <= -replyTriggerPx) {
                                onSwipeReply()
                            }
                            swipeOffsetX = 0f
                        },
                        onDragCancel = { swipeOffsetX = 0f },
                        onHorizontalDrag = { _, dragAmount ->
                            val next = swipeOffsetX + dragAmount
                            if (next <= 0f) {
                                swipeOffsetX = next.coerceAtLeast(-replyTriggerPx * 1.3f)
                            }
                        }
                    )
                }
                .padding(
                    start = if (!message.isOutgoing && !hasTail) 7.dp else 0.dp,
                    end = if (message.isOutgoing && !hasTail) 7.dp else 0.dp
                ),
            horizontalAlignment = if (message.isOutgoing) Alignment.End else Alignment.Start
        ) {
            Surface(
                shape = shape,
                color = bubbleColor,
                shadowElevation = 1.dp,
                modifier = Modifier
                    .widthIn(min = 96.dp, max = 308.dp)
                    .combinedClickable(
                        onClick = {
                            when (message.kind) {
                                MessageKind.GIFT -> onTapGift(message)
                                MessageKind.PHOTO -> message.mediaUri?.let { onTapPhoto(it) }
                                else -> Unit
                            }
                        },
                        onLongClick = onLongPress
                    )
                    .testTag("message_bubble_${message.id}")
            ) {
                Column(modifier = Modifier.padding(start = startPad, end = endPad, top = 7.dp, bottom = 7.dp)) {
                    if (message.forwardedFrom != null) {
                        Text(
                            text = "Переслано от ${message.forwardedFrom}",
                            color = TgBlue,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                    }

                    if (message.replyPreviewText != null && message.replyToId != null) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(TgBlue.copy(alpha = 0.12f))
                                .clickable { onTapReplyQuote(message.replyToId) }
                                .padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(2.5.dp)
                                    .height(28.dp)
                                    .background(TgBlue)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = message.replyPreviewSender ?: "Ответ",
                                    color = TgBlue,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = message.replyPreviewText,
                                    color = palette.textSecondary,
                                    fontSize = 12.5.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(5.dp))
                    }

                    when (message.kind) {
                        MessageKind.PHOTO -> {
                            if (!message.mediaUri.isNullOrBlank()) {
                                val photoModel = if (message.mediaUri.startsWith("/")) {
                                    File(message.mediaUri)
                                } else {
                                    message.mediaUri
                                }
                                AsyncImage(
                                    model = photoModel,
                                    contentDescription = "Изображение",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(190.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                )
                            }
                            if (message.text.isNotBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                NftLinkText(
                                    text = message.text,
                                    color = palette.textPrimary,
                                    fontSizeSp = textSizeSp.toFloat()
                                )
                            }
                        }

                        MessageKind.FILE -> {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(vertical = 2.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(CircleShape)
                                        .background(TgBlue),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.Description,
                                        contentDescription = "Файл",
                                        tint = Color.White
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = message.fileName ?: message.text,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 14.sp,
                                        color = palette.textPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = message.fileSizeText ?: "Документ",
                                        fontSize = 12.sp,
                                        color = palette.textSecondary
                                    )
                                }
                            }
                        }

                        MessageKind.VOICE -> {
                            val isPlayingThis = playbackState.playingMessageId == message.id && playbackState.isPlaying
                            val progress = if (playbackState.playingMessageId == message.id) playbackState.progress else 0f
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(vertical = 2.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(CircleShape)
                                        .background(TgBlue)
                                        .clickable { onTapVoicePlay() },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isPlayingThis) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                        contentDescription = if (isPlayingThis) "Пауза" else "Воспроизвести",
                                        tint = Color.White,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    WaveformBars(
                                        amplitudes = message.voiceWaveform.ifEmpty {
                                            List(24) { 0.3f + ((it * 13) % 6) * 0.1f }
                                        },
                                        progress = progress,
                                        activeColor = TgBlue,
                                        inactiveColor = palette.textSecondary.copy(alpha = 0.35f),
                                        onSeekFraction = if (isPlayingThis) onSeekVoice else null,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(22.dp)
                                    )
                                    Spacer(modifier = Modifier.height(3.dp))
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            text = ForkGramRepository.formatDuration(message.voiceDurationSec),
                                            fontSize = 11.5.sp,
                                            color = palette.textSecondary
                                        )
                                        if (isPlayingThis) {
                                            val speedLabel = when {
                                                playbackState.playbackSpeed >= 1.9f -> "2x"
                                                playbackState.playbackSpeed >= 1.4f -> "1.5x"
                                                else -> "1x"
                                            }
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = TgBlue.copy(alpha = 0.16f),
                                                modifier = Modifier.clickable { onCycleVoiceSpeed() }
                                            ) {
                                                Text(
                                                    text = speedLabel,
                                                    color = TgBlue,
                                                    fontSize = 10.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        MessageKind.GIFT -> {
                            val kind = message.giftKind ?: GiftKind.PLUSH_PEPE
                            val edition = message.giftNumber ?: kind.validDemoEditions.firstOrNull() ?: 1
                            TelegramGiftBackdropBox(
                                backdrop = kind.defaultBackdrop,
                                symbol = kind.defaultSymbol,
                                showShimmer = message.isNftGift,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(18.dp))
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    AnimatedTelegramGift(
                                        giftKind = kind,
                                        animate = true,
                                        editionNumber = edition,
                                        useRemoteEdition = message.isNftGift,
                                        modifier = Modifier.size(132.dp)
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = if (message.isNftGift) "${kind.title} #$edition" else "Подарок: ${kind.title}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.5.sp,
                                        color = Color.White
                                    )
                                    if (message.text.isNotBlank()) {
                                        Text(
                                            text = message.text,
                                            fontSize = 12.5.sp,
                                            color = Color.White.copy(alpha = 0.88f),
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                    if (message.isNftGift) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "forkgram.xsph.ru/nft/${kind.linkSlug}-$edition",
                                            fontSize = 11.5.sp,
                                            color = Color.White.copy(alpha = 0.92f),
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(Color.Black.copy(alpha = 0.28f))
                                            .padding(horizontal = 9.dp, vertical = 3.dp)
                                    ) {
                                        SvgStarIcon(modifier = Modifier.size(13.dp), color = StarGold)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (message.isNftGift) "NFT • ${message.giftStarsValue} Звёзд" else "${message.giftStarsValue} Звёзд",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Color.White
                                        )
                                    }
                                }
                            }
                        }

                        MessageKind.GRAM_TRANSFER -> {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(GramCyan.copy(alpha = 0.14f))
                                    .padding(horizontal = 10.dp, vertical = 8.dp)
                            ) {
                                SvgGramGemIcon(modifier = Modifier.size(28.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "+${ForkGramRepository.formatGram(message.gramAmount)} GRAM",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = GramCyan
                                    )
                                    Text(
                                        text = message.text,
                                        fontSize = 12.5.sp,
                                        color = palette.textPrimary
                                    )
                                }
                            }
                        }

                        MessageKind.LOCATION -> {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF46B966)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Outlined.LocationOn, contentDescription = null, tint = Color.White)
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("Геопозиция", fontWeight = FontWeight.SemiBold, color = palette.textPrimary, fontSize = 14.sp)
                                    Text(message.text, color = palette.textSecondary, fontSize = 12.5.sp)
                                }
                            }
                        }

                        MessageKind.POLL -> {
                            val poll = PollData.fromJson(message.text)
                            if (poll != null) {
                                val total = poll.totalVotes
                                val hasVoted = poll.options.any { opt ->
                                    opt.voters.any { it.equals(currentUserEmail, ignoreCase = true) }
                                }
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(
                                        text = poll.question,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = (textSizeSp + 1).sp,
                                        color = palette.textPrimary
                                    )
                                    Text(
                                        text = "Анонимный опрос • голосов: $total",
                                        fontSize = 11.5.sp,
                                        color = metaColor
                                    )
                                    poll.options.forEachIndexed { idx, opt ->
                                        val isChosen = opt.voters.any { it.equals(currentUserEmail, ignoreCase = true) }
                                        val pct = if (total > 0) ((opt.voters.size * 100f) / total).roundToInt() else 0
                                        Surface(
                                            shape = RoundedCornerShape(12.dp),
                                            color = if (isChosen) TgBlue.copy(alpha = 0.14f) else palette.surface.copy(alpha = 0.65f),
                                            border = BorderStroke(
                                                width = if (isChosen) 1.2.dp else 0.7.dp,
                                                color = if (isChosen) TgBlue else palette.divider
                                            ),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { onVotePoll(idx) }
                                        ) {
                                            Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Row(
                                                        modifier = Modifier.weight(1f),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        if (isChosen) {
                                                            Icon(
                                                                Icons.Rounded.CheckCircle,
                                                                contentDescription = null,
                                                                tint = TgBlue,
                                                                modifier = Modifier.size(16.dp)
                                                            )
                                                            Spacer(modifier = Modifier.width(6.dp))
                                                        }
                                                        Text(
                                                            text = opt.text,
                                                            color = palette.textPrimary,
                                                            fontSize = 13.5.sp,
                                                            fontWeight = if (isChosen) FontWeight.SemiBold else FontWeight.Normal
                                                        )
                                                    }
                                                    if (hasVoted || total > 0) {
                                                        Text(
                                                            text = "$pct%",
                                                            color = if (isChosen) TgBlue else palette.textSecondary,
                                                            fontWeight = FontWeight.Bold,
                                                            fontSize = 12.5.sp
                                                        )
                                                    }
                                                }
                                                if (hasVoted || total > 0) {
                                                    Spacer(modifier = Modifier.height(5.dp))
                                                    Box(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .height(5.dp)
                                                            .clip(RoundedCornerShape(3.dp))
                                                            .background(palette.divider.copy(alpha = 0.45f))
                                                    ) {
                                                        Box(
                                                            modifier = Modifier
                                                                .fillMaxWidth(if (total > 0) (opt.voters.size.toFloat() / total.toFloat()).coerceIn(0.03f, 1f) else 0f)
                                                                .height(5.dp)
                                                                .clip(RoundedCornerShape(3.dp))
                                                                .background(if (isChosen) TgBlue else palette.textSecondary.copy(alpha = 0.6f))
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            } else {
                                NftLinkText(
                                    text = message.text,
                                    color = palette.textPrimary,
                                    fontSizeSp = textSizeSp.toFloat()
                                )
                            }
                        }

                        else -> {
                            Text(
                                text = message.text,
                                color = palette.textPrimary,
                                fontSize = textSizeSp.sp,
                                lineHeight = (textSizeSp + 5).sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(3.dp))

                    Row(
                        modifier = Modifier.align(Alignment.End),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (message.reactionKey != null) {
                            val reaction = ReactionType.entries.firstOrNull { it.key == message.reactionKey }
                            if (reaction != null) {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = TgBlue.copy(alpha = 0.16f),
                                    modifier = Modifier.clickable { onTapReaction(reaction.key) }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        SvgReactionIcon(type = reaction, modifier = Modifier.size(13.dp))
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text("1", fontSize = 11.sp, color = TgBlue, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                        if (message.isEdited) {
                            Text("изм.", fontSize = 11.sp, color = metaColor)
                        }
                        Text(
                            text = message.timestampText,
                            fontSize = 11.sp,
                            color = metaColor
                        )
                        if (message.isOutgoing) {
                            Icon(
                                imageVector = if (message.isRead) Icons.Rounded.DoneAll else Icons.Rounded.Done,
                                contentDescription = if (message.isRead) "Прочитано" else "Отправлено",
                                tint = if (message.isRead) TgBlue else metaColor,
                                modifier = Modifier.size(15.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WaveformBars(
    amplitudes: List<Float>,
    progress: Float,
    activeColor: Color,
    inactiveColor: Color,
    onSeekFraction: ((Float) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val interactiveModifier = if (onSeekFraction != null) {
        modifier.pointerInput(onSeekFraction) {
            detectTapGestures { offset ->
                if (size.width > 0) {
                    onSeekFraction((offset.x / size.width.toFloat()).coerceIn(0f, 1f))
                }
            }
        }
    } else {
        modifier
    }

    Canvas(modifier = interactiveModifier) {
        val count = amplitudes.size.coerceAtLeast(1)
        val barWidth = (size.width / (count * 1.6f)).coerceAtLeast(2.dp.toPx())
        val gap = (size.width - barWidth * count) / (count - 1).coerceAtLeast(1)
        val activeIndex = (progress * count).toInt()
        amplitudes.forEachIndexed { idx, amp ->
            val h = (size.height * amp.coerceIn(0.18f, 1.0f))
            val x = idx * (barWidth + gap)
            val y = (size.height - h) / 2f
            drawRoundRect(
                color = if (idx <= activeIndex && progress > 0f) activeColor else inactiveColor,
                topLeft = Offset(x, y),
                size = Size(barWidth, h),
                cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
            )
        }
    }
}

@Composable
private fun ContextMenuRow(
    icon: ImageVector,
    label: String,
    tint: Color? = null,
    onClick: () -> Unit
) {
    val palette = LocalForkPalette.current
    val resolved = tint ?: palette.textPrimary
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = resolved, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(12.dp))
        Text(text = label, color = resolved, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun AttachOptionItem(
    icon: ImageVector,
    color: Color,
    label: String,
    onClick: () -> Unit
) {
    val palette = LocalForkPalette.current
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(color),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(26.dp))
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = label, fontSize = 12.5.sp, color = palette.textPrimary, fontWeight = FontWeight.Medium)
    }
}


val LocalNftLinkHandler = androidx.compose.runtime.compositionLocalOf<(GiftKind, Int) -> Unit> { { _, _ -> } }

private val NftLinkRegex = Regex("""(?:https?://)?forkgram\.xsph\.ru/nft/([A-Za-z]+)-(\d+)""", RegexOption.IGNORE_CASE)

/** Текст сообщения: ссылки на NFT-подарки кликабельны и открывают шит подарка, как t.me/nft/... в Telegram. */
@Composable
fun NftLinkText(text: String, color: Color, fontSizeSp: Float) {
    val handler = LocalNftLinkHandler.current
    val matches = remember(text) { NftLinkRegex.findAll(text).toList() }
    if (matches.isEmpty()) {
        Text(text = text, color = color, fontSize = fontSizeSp.sp)
        return
    }
    val annotated = remember(text) {
        androidx.compose.ui.text.buildAnnotatedString {
            var cursor = 0
            for (m in matches) {
                append(text.substring(cursor, m.range.first))
                val start = length
                append(m.value)
                addStyle(
                    androidx.compose.ui.text.SpanStyle(
                        color = TgBlue,
                        textDecoration = androidx.compose.ui.text.style.TextDecoration.None
                    ),
                    start, length
                )
                addStringAnnotation("nft", "${m.groupValues[1]}|${m.groupValues[2]}", start, length)
                cursor = m.range.last + 1
            }
            append(text.substring(cursor))
        }
    }
    androidx.compose.foundation.text.ClickableText(
        text = annotated,
        style = TextStyle(color = color, fontSize = fontSizeSp.sp),
        onClick = { offset ->
            annotated.getStringAnnotations("nft", offset, offset).firstOrNull()?.let { a ->
                val (slug, num) = a.item.split("|")
                val kind = GiftKind.entries.firstOrNull { it.linkSlug.equals(slug, true) || it.id.equals(slug, true) }
                if (kind != null) handler(kind, num.toIntOrNull() ?: 1)
            }
        }
    )
}
