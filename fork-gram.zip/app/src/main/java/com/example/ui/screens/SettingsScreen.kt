package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ExitToApp
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.AddAPhoto
import androidx.compose.material.icons.rounded.AlternateEmail
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.ChatBubble
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PieChart
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AppPreferencesState
import com.example.data.model.UserAccount
import com.example.data.repository.ForkGramRepository
import com.example.ui.components.AvatarView
import com.example.ui.components.TelegramOutlinedField
import com.example.ui.components.TelegramQrDialog
import com.example.ui.svg.SvgGramGemIcon
import com.example.ui.svg.SvgStarIcon
import com.example.ui.theme.DangerRed
import com.example.ui.theme.GramCyan
import com.example.ui.theme.IconAmber
import com.example.ui.theme.IconBlue
import com.example.ui.theme.IconCyan
import com.example.ui.theme.IconGreen
import com.example.ui.theme.IconIndigo
import com.example.ui.theme.IconOrange
import com.example.ui.theme.IconPurple
import com.example.ui.theme.IconRed
import com.example.ui.theme.IconTeal
import com.example.ui.theme.LocalForkPalette
import com.example.ui.theme.PremiumViolet
import com.example.ui.theme.StarGold
import com.example.ui.theme.TgBlue

enum class SettingsDestination {
    ACCOUNT,
    CHAT_APPEARANCE,
    PRIVACY,
    NOTIFICATIONS,
    DATA_STORAGE,
    FOLDERS,
    DEVICES,
    POWER_SAVING,
    LANGUAGE,
    PREMIUM,
    STARS_WALLET,
    GRAM_WALLET,
    NFT_USERNAMES
}

@Composable
fun SettingsScreen(
    account: UserAccount?,
    prefs: AppPreferencesState,
    onNavigateSubScreen: (SettingsDestination) -> Unit,
    onUpdateAvatar: (String) -> Unit,
    onShowToast: (String) -> Unit = {},
    onLogout: () -> Unit
) {
    val palette = LocalForkPalette.current
    var showMenu by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var showSearchDialog by remember { mutableStateOf(false) }
    var showQrDialog by remember { mutableStateOf(false) }

    val avatarPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) onUpdateAvatar(uri.toString())
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            .statusBarsPadding(),
        contentPadding = PaddingValues(bottom = 110.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Left QR + Top Right Search + 3-dot Menu (with "Выход", 1:1 Telegram Settings)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { showQrDialog = true },
                    modifier = Modifier.testTag("settings_qr_button")
                ) {
                    Icon(Icons.Rounded.QrCode2, contentDescription = "QR-код", tint = TgBlue)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { showSearchDialog = true }) {
                        Icon(Icons.Rounded.Search, contentDescription = "Поиск", tint = palette.textPrimary)
                    }
                    Box {
                        IconButton(
                            onClick = { showMenu = true },
                            modifier = Modifier.testTag("settings_overflow_button")
                        ) {
                            Icon(Icons.Rounded.MoreVert, contentDescription = "Меню", tint = palette.textPrimary)
                        }
                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false },
                            shape = RoundedCornerShape(16.dp),
                            containerColor = palette.surface
                        ) {
                            DropdownMenuItem(
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Rounded.ExitToApp,
                                        contentDescription = null,
                                        tint = palette.textPrimary
                                    )
                                },
                                text = { Text("Выход", color = DangerRed, fontWeight = FontWeight.Medium) },
                                onClick = {
                                    showMenu = false
                                    onLogout()
                                },
                                modifier = Modifier.testTag("settings_logout_item")
                            )
                        }
                    }
                }
            }
        }

        // Centered Avatar + Camera Badge + Name + Email (Screenshot 6)
        item {
            Box(
                modifier = Modifier
                    .size(92.dp)
                    .clickable {
                        avatarPicker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    }
            ) {
                AvatarView(
                    title = account?.fullName ?: "FG",
                    avatarUri = account?.avatarUri,
                    colorHex = 0xFF2AABEE,
                    size = 90.dp
                )
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .align(Alignment.BottomEnd)
                        .clip(CircleShape)
                        .background(TgBlue),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.AddAPhoto,
                        contentDescription = "Сменить фото",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = account?.fullName ?: "Пользователь",
                fontSize = 22.sp,
                fontWeight = FontWeight.SemiBold,
                color = palette.textPrimary
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "${account?.email ?: ""} • ${account?.displayHandle ?: ""}",
                fontSize = 14.sp,
                color = palette.textSecondary
            )
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Fork Gram Active Account Card (Screenshot 6)
        item {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = palette.surface,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clickable { onNavigateSubScreen(SettingsDestination.NFT_USERNAMES) }
            ) {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                    Text(
                        text = "Fork Gram",
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TgBlue
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AvatarView(
                            title = account?.fullName ?: "FG",
                            avatarUri = account?.avatarUri,
                            colorHex = 0xFF2AABEE,
                            size = 36.dp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = account?.fullName ?: "Аккаунт",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = palette.textPrimary
                            )
                            Text(
                                text = if (account?.activeNftUsername != null) {
                                    "NFT-имя: ${account.activeNftUsername}"
                                } else {
                                    "Нажмите, чтобы выбрать NFT-юзернейм"
                                },
                                fontSize = 12.5.sp,
                                color = if (account?.activeNftUsername != null) GramCyan else palette.textSecondary
                            )
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                            contentDescription = null,
                            tint = palette.textSecondary
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Main Grouped Settings Card (1:1 to Screenshot 6!)
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = palette.surface,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Column {
                    SettingsRowItem(
                        icon = Icons.Rounded.Person,
                        iconBg = IconBlue,
                        title = "Аккаунт",
                        subtitle = "Почта, имя пользователя, «О себе»",
                        onClick = { onNavigateSubScreen(SettingsDestination.ACCOUNT) }
                    )
                    SettingsDivider()
                    SettingsRowItem(
                        icon = Icons.Rounded.ChatBubble,
                        iconBg = IconAmber,
                        title = "Настройки чатов",
                        subtitle = "Обои, ночной режим, анимации",
                        onClick = { onNavigateSubScreen(SettingsDestination.CHAT_APPEARANCE) }
                    )
                    SettingsDivider()
                    SettingsRowItem(
                        icon = Icons.Rounded.Lock,
                        iconBg = IconGreen,
                        title = "Конфиденциальность",
                        subtitle = "Время захода, устройства, приватность",
                        onClick = { onNavigateSubScreen(SettingsDestination.PRIVACY) }
                    )
                    SettingsDivider()
                    SettingsRowItem(
                        icon = Icons.Rounded.Notifications,
                        iconBg = IconRed,
                        title = "Уведомления",
                        subtitle = "Звуки, звонки, счётчик сообщений",
                        onClick = { onNavigateSubScreen(SettingsDestination.NOTIFICATIONS) }
                    )
                    SettingsDivider()
                    SettingsRowItem(
                        icon = Icons.Rounded.PieChart,
                        iconBg = IconIndigo,
                        title = "Данные и память",
                        subtitle = "Настройки загрузки медиафайлов",
                        onClick = { onNavigateSubScreen(SettingsDestination.DATA_STORAGE) }
                    )
                    SettingsDivider()
                    SettingsRowItem(
                        icon = Icons.Rounded.Folder,
                        iconBg = IconCyan,
                        title = "Папки с чатами",
                        subtitle = "Сортировка чатов по папкам",
                        testTag = "settings_folders_row",
                        onClick = { onNavigateSubScreen(SettingsDestination.FOLDERS) }
                    )
                    SettingsDivider()
                    SettingsRowItem(
                        icon = Icons.Rounded.Devices,
                        iconBg = IconTeal,
                        title = "Устройства",
                        subtitle = "Управление активными сеансами",
                        onClick = { onNavigateSubScreen(SettingsDestination.DEVICES) }
                    )
                    SettingsDivider()
                    SettingsRowItem(
                        icon = Icons.Rounded.BatteryChargingFull,
                        iconBg = IconOrange,
                        title = "Энергосбережение",
                        subtitle = if (prefs.powerSavingEnabled) "Включено" else "Экономия энергии при низком заряде",
                        onClick = { onNavigateSubScreen(SettingsDestination.POWER_SAVING) }
                    )
                    SettingsDivider()
                    SettingsRowItem(
                        icon = Icons.Rounded.Language,
                        iconBg = IconPurple,
                        title = "Язык",
                        subtitle = prefs.languageName,
                        onClick = { onNavigateSubScreen(SettingsDestination.LANGUAGE) }
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Economy & Premium Card: Fork Gram Premium, Звёзды, Кошелёк Gram, NFT-юзернеймы (Screenshot 6 bottom)
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = palette.surface,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Column {
                    SettingsSvgRowItem(
                        badgeColor = PremiumViolet,
                        title = "Fork Gram Premium",
                        trailingValue = if (account?.isPremium == true) "Активен" else null,
                        trailingColor = PremiumViolet,
                        onClick = { onNavigateSubScreen(SettingsDestination.PREMIUM) },
                        iconContent = {
                            SvgStarIcon(modifier = Modifier.size(18.dp), color = Color.White)
                        }
                    )
                    SettingsDivider()
                    SettingsSvgRowItem(
                        badgeColor = StarGold,
                        title = "Звёзды Fork Gram",
                        trailingValue = (account?.starsBalance ?: 0L).toString(),
                        trailingColor = TgBlue,
                        testTag = "settings_stars_row",
                        onClick = { onNavigateSubScreen(SettingsDestination.STARS_WALLET) },
                        iconContent = {
                            SvgStarIcon(modifier = Modifier.size(18.dp), color = Color.White)
                        }
                    )
                    SettingsDivider()
                    SettingsSvgRowItem(
                        badgeColor = GramCyan,
                        title = "Кошелёк Gram",
                        trailingValue = "${ForkGramRepository.formatGram(account?.gramBalance ?: 0.0)} GRAM",
                        trailingColor = GramCyan,
                        testTag = "settings_gram_row",
                        onClick = { onNavigateSubScreen(SettingsDestination.GRAM_WALLET) },
                        iconContent = {
                            SvgGramGemIcon(modifier = Modifier.size(18.dp), color = Color.White)
                        }
                    )
                    SettingsDivider()
                    SettingsRowItem(
                        icon = Icons.Rounded.AlternateEmail,
                        iconBg = Color(0xFF28A8EA),
                        title = "NFT-юзернеймы",
                        subtitle = account?.activeNftUsername ?: "Маркетплейс и минт коллекционных имен",
                        testTag = "settings_nft_usernames_row",
                        onClick = { onNavigateSubScreen(SettingsDestination.NFT_USERNAMES) }
                    )
                }
            }
        }
    }

    if (showSearchDialog) {
        AlertDialog(
            onDismissRequest = { showSearchDialog = false },
            containerColor = palette.surface,
            shape = RoundedCornerShape(24.dp),
            title = { Text("Поиск по настройкам", fontWeight = FontWeight.Bold, color = palette.textPrimary) },
            text = {
                Column {
                    TelegramOutlinedField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = "Например: Звёзды, Папки, NFT"
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    val items = listOf(
                        "Аккаунт" to SettingsDestination.ACCOUNT,
                        "Настройки чатов и обои" to SettingsDestination.CHAT_APPEARANCE,
                        "Папки с чатами" to SettingsDestination.FOLDERS,
                        "Звёзды Fork Gram" to SettingsDestination.STARS_WALLET,
                        "Кошелёк Gram" to SettingsDestination.GRAM_WALLET,
                        "NFT-юзернеймы" to SettingsDestination.NFT_USERNAMES
                    ).filter { searchQuery.isBlank() || it.first.contains(searchQuery, ignoreCase = true) }
                    items.forEach { (label, dest) ->
                        Text(
                            text = label,
                            color = TgBlue,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    showSearchDialog = false
                                    onNavigateSubScreen(dest)
                                }
                                .padding(vertical = 8.dp)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSearchDialog = false }) { Text("Закрыть", color = TgBlue) }
            }
        )
    }

    if (showQrDialog && account != null) {
        TelegramQrDialog(
            title = account.fullName,
            handle = account.displayHandle,
            subtitle = "Отсканируйте код, чтобы открыть ваш профиль Fork Gram",
            onDismiss = { showQrDialog = false },
            onShowToast = onShowToast
        )
    }
}

@Composable
private fun SettingsRowItem(
    icon: ImageVector,
    iconBg: Color,
    title: String,
    subtitle: String,
    testTag: String = "",
    onClick: () -> Unit
) {
    val palette = LocalForkPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .then(if (testTag.isNotEmpty()) Modifier.testTag(testTag) else Modifier)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(30.dp)
                .clip(CircleShape)
                .background(iconBg),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(17.dp))
        }
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 15.5.sp,
                fontWeight = FontWeight.Medium,
                color = palette.textPrimary
            )
            Text(
                text = subtitle,
                fontSize = 12.5.sp,
                color = palette.textSecondary
            )
        }
    }
}

@Composable
private fun SettingsSvgRowItem(
    badgeColor: Color,
    title: String,
    trailingValue: String?,
    trailingColor: Color,
    testTag: String = "",
    onClick: () -> Unit,
    iconContent: @Composable () -> Unit
) {
    val palette = LocalForkPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .then(if (testTag.isNotEmpty()) Modifier.testTag(testTag) else Modifier)
            .padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(30.dp)
                .clip(CircleShape)
                .background(badgeColor),
            contentAlignment = Alignment.Center
        ) {
            iconContent()
        }
        Spacer(modifier = Modifier.width(14.dp))
        Text(
            text = title,
            fontSize = 15.5.sp,
            fontWeight = FontWeight.Medium,
            color = palette.textPrimary,
            modifier = Modifier.weight(1f)
        )
        if (trailingValue != null) {
            Text(
                text = trailingValue,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = trailingColor
            )
        }
    }
}

@Composable
private fun SettingsDivider() {
    val palette = LocalForkPalette.current
    HorizontalDivider(
        color = palette.divider.copy(alpha = 0.75f),
        thickness = 0.5.dp,
        modifier = Modifier.padding(start = 60.dp)
    )
}
