package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.VoiceAudioManager
import com.example.audio.VoicePlaybackState
import com.example.audio.VoiceRecordingState
import com.example.data.local.AppPreferencesState
import com.example.data.local.ForkGramDatabase
import com.example.data.local.UserPreferences
import com.example.data.model.CallSessionState
import com.example.data.model.ChatFolder
import com.example.data.model.ChatMessage
import com.example.data.model.ChatThread
import com.example.data.model.ChatType
import com.example.data.model.ContactItem
import com.example.data.model.DeviceSession
import com.example.data.model.FragmentNftGiftListing
import com.example.data.model.GiftCollectionTab
import com.example.data.model.GiftKind
import com.example.data.model.MainTab
import com.example.data.model.NftUsernameItem
import com.example.data.model.OwnedGift
import com.example.data.model.PeerProfileData
import com.example.data.model.ProfilePost
import com.example.data.model.UserAccount
import com.example.data.model.WalletTransaction
import com.example.data.model.WallpaperTheme
import com.example.data.remote.RemoteDirectoryUser
import com.example.data.repository.ForkGramRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class ForkGramViewModel(application: Application) : AndroidViewModel(application) {
    private val db = ForkGramDatabase.getInstance(application)
    private val preferences = UserPreferences(application)
    private val repo = ForkGramRepository(application, db, preferences)
    val audioManager = VoiceAudioManager(application)

    val prefs: StateFlow<AppPreferencesState> = repo.prefsFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        AppPreferencesState()
    )

    val account: StateFlow<UserAccount?> = prefs.flatMapLatest { pref ->
        val email = pref.activeEmail
        if (email.isNullOrBlank()) flowOf(null) else repo.observeAccount(email)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val folders: StateFlow<List<ChatFolder>> = prefs.flatMapLatest { pref ->
        val email = pref.activeEmail
        if (email.isNullOrBlank()) flowOf(emptyList()) else repo.observeFolders(email)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val chats: StateFlow<List<ChatThread>> = prefs.flatMapLatest { pref ->
        val email = pref.activeEmail
        if (email.isNullOrBlank()) flowOf(emptyList()) else repo.observeChats(email)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val contacts: StateFlow<List<ContactItem>> = prefs.flatMapLatest { pref ->
        val email = pref.activeEmail
        if (email.isNullOrBlank()) flowOf(emptyList()) else repo.observeContacts(email)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val ownedGifts: StateFlow<List<OwnedGift>> = prefs.flatMapLatest { pref ->
        val email = pref.activeEmail
        if (email.isNullOrBlank()) flowOf(emptyList()) else repo.observeGifts(email)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val giftCollections: StateFlow<List<GiftCollectionTab>> = prefs.flatMapLatest { pref ->
        val email = pref.activeEmail
        if (email.isNullOrBlank()) flowOf(emptyList()) else repo.observeGiftCollections(email)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val nftUsernames: StateFlow<List<NftUsernameItem>> = prefs.flatMapLatest { pref ->
        val email = pref.activeEmail
        if (email.isNullOrBlank()) flowOf(emptyList()) else repo.observeNftUsernames(email)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transactions: StateFlow<List<WalletTransaction>> = prefs.flatMapLatest { pref ->
        val email = pref.activeEmail
        if (email.isNullOrBlank()) flowOf(emptyList()) else repo.observeTransactions(email)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val profilePosts: StateFlow<List<ProfilePost>> = prefs.flatMapLatest { pref ->
        val email = pref.activeEmail
        if (email.isNullOrBlank()) flowOf(emptyList()) else repo.observeProfilePosts(email)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val deviceSessions: StateFlow<List<DeviceSession>> = repo.sessionsFlow

    val fragmentGiftListings: StateFlow<List<FragmentNftGiftListing>> = repo.fragmentGiftListingsFlow

    val voiceRecordingState: StateFlow<VoiceRecordingState> = audioManager.recordingState
    val voicePlaybackState: StateFlow<VoicePlaybackState> = audioManager.playbackState

    private val _selectedTab = MutableStateFlow(MainTab.CHATS)
    val selectedTab: StateFlow<MainTab> = _selectedTab.asStateFlow()

    private val _selectedFolderId = MutableStateFlow<String?>(null)
    val selectedFolderId: StateFlow<String?> = _selectedFolderId.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private val _remoteDirectory = MutableStateFlow<List<RemoteDirectoryUser>>(emptyList())
    val remoteDirectory: StateFlow<List<RemoteDirectoryUser>> = _remoteDirectory.asStateFlow()

    private val _cacheSizeBytes = MutableStateFlow(0L)
    val cacheSizeBytes: StateFlow<Long> = _cacheSizeBytes.asStateFlow()

    private val _activeCall = MutableStateFlow<CallSessionState?>(null)
    val activeCall: StateFlow<CallSessionState?> = _activeCall.asStateFlow()

    private var typingToEmail: String? = null
    private var typingHeartbeatJob: Job? = null
    private var callTimerJob: Job? = null

    init {
        viewModelScope.launch {
            refreshCacheSize()
            var lastSync = 0L
            var fragmentBootSynced = false
            while (isActive) {
                val pref = prefs.value
                val activeEmail = pref.activeEmail
                if (!activeEmail.isNullOrBlank()) {
                    if (!fragmentBootSynced) {
                        repo.refreshFragmentMarket(activeEmail)
                        fragmentBootSynced = true
                    }
                    repo.sendHeartbeat(
                        ownerEmail = activeEmail,
                        isOnline = pref.showOnlineStatus,
                        typingToEmail = typingToEmail
                    )
                    lastSync = repo.syncFromServer(activeEmail, lastSync)
                } else {
                    fragmentBootSynced = false
                }
                delay(4500L)
            }
        }
    }

    fun refreshCacheSize() {
        viewModelScope.launch {
            _cacheSizeBytes.value = repo.computeCacheBytes()
        }
    }

    fun clearCache() {
        viewModelScope.launch {
            _cacheSizeBytes.value = repo.clearAppCache()
            showToast("Кэш очищен")
        }
    }

    fun setTyping(chat: ChatThread?, isTyping: Boolean) {
        val activeEmail = prefs.value.activeEmail ?: return
        val target = chat?.email?.takeIf { it.contains("@") }
        val nextTyping = if (isTyping && target != null) target else null
        if (typingToEmail == nextTyping) return
        typingToEmail = nextTyping
        typingHeartbeatJob?.cancel()
        typingHeartbeatJob = viewModelScope.launch {
            repo.sendHeartbeat(
                ownerEmail = activeEmail,
                isOnline = prefs.value.showOnlineStatus,
                typingToEmail = nextTyping
            )
            if (nextTyping != null) {
                delay(4500L)
                if (typingToEmail == nextTyping) {
                    typingToEmail = null
                    repo.sendHeartbeat(activeEmail, prefs.value.showOnlineStatus, null)
                }
            }
        }
    }

    fun startCall(chat: ChatThread, isVideo: Boolean) {
        callTimerJob?.cancel()
        _activeCall.value = CallSessionState(
            chatId = chat.id,
            peerName = chat.title,
            avatarUri = chat.avatarUri,
            avatarColorHex = chat.avatarColorHex,
            isVideo = isVideo,
            isSpeaker = isVideo,
            startedAtMillis = System.currentTimeMillis(),
            statusLabel = "Соединение..."
        )
        callTimerJob = viewModelScope.launch {
            delay(1300L)
            val current = _activeCall.value ?: return@launch
            if (current.chatId == chat.id) {
                _activeCall.value = current.copy(statusLabel = "Звонок...")
            }
            delay(1800L)
            var sec = 0
            while (isActive && _activeCall.value != null) {
                val m = sec / 60
                val s = sec % 60
                _activeCall.value = _activeCall.value?.copy(
                    statusLabel = "%02d:%02d".format(m, s)
                )
                delay(1000L)
                sec++
            }
        }
    }

    fun toggleCallMute() {
        _activeCall.value = _activeCall.value?.let { it.copy(isMuted = !it.isMuted) }
    }

    fun toggleCallSpeaker() {
        _activeCall.value = _activeCall.value?.let { it.copy(isSpeaker = !it.isSpeaker) }
    }

    fun endCall() {
        callTimerJob?.cancel()
        callTimerJob = null
        _activeCall.value = null
    }

    fun searchRemoteDirectory(query: String) {
        val activeEmail = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            _remoteDirectory.value = repo.searchRemoteUsers(activeEmail, query)
        }
    }

    fun openRemoteUserChat(user: RemoteDirectoryUser, onReady: (String) -> Unit) {
        val activeEmail = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            val chatId = repo.openOrCreateChatForRemoteUser(activeEmail, user)
            onReady(chatId)
        }
    }

    fun selectTab(tab: MainTab) {
        _selectedTab.value = tab
    }

    fun selectFolder(folderId: String?) {
        _selectedFolderId.value = folderId
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun observeChat(chatId: String) = repo.observeChat(chatId)
    fun observeMessages(chatId: String) = repo.observeMessages(chatId)

    suspend fun findExistingAccount(email: String): UserAccount? = repo.checkExistingAccount(email)

    fun completeAuth(
        email: String,
        firstName: String,
        lastName: String,
        avatarUri: String?,
        onDone: () -> Unit
    ) {
        viewModelScope.launch {
            repo.completeAuthOrRegister(email, firstName, lastName, avatarUri)
            _selectedTab.value = MainTab.CHATS
            onDone()
        }
    }

    fun logout() {
        viewModelScope.launch {
            audioManager.stopPlayback()
            endCall()
            typingToEmail = null
            repo.logout()
            _selectedFolderId.value = null
            _selectedTab.value = MainTab.CHATS
        }
    }

    fun toggleDarkMode() {
        viewModelScope.launch { preferences.setDarkTheme(!prefs.value.isDarkTheme) }
    }

    fun setWallpaperTheme(theme: WallpaperTheme) {
        viewModelScope.launch { preferences.setWallpaperTheme(theme) }
    }

    fun setChatTextSize(sizeSp: Int) {
        viewModelScope.launch { preferences.setChatTextSize(sizeSp) }
    }

    fun setAnimationsEnabled(enabled: Boolean) {
        viewModelScope.launch { preferences.setAnimationsEnabled(enabled) }
    }

    fun setPowerSaving(enabled: Boolean) {
        viewModelScope.launch { preferences.setPowerSavingEnabled(enabled) }
    }

    fun setNotifications(enabled: Boolean) {
        viewModelScope.launch { preferences.setNotificationsEnabled(enabled) }
    }

    fun setShowOnline(enabled: Boolean) {
        viewModelScope.launch {
            preferences.setShowOnlineStatus(enabled)
            prefs.value.activeEmail?.let { repo.sendHeartbeat(it, enabled, typingToEmail) }
        }
    }

    fun setLanguage(lang: String) {
        viewModelScope.launch { preferences.setLanguage(lang) }
    }

    fun setAutoDownloadWifi(enabled: Boolean) {
        viewModelScope.launch { preferences.setAutoDownloadWifi(enabled) }
    }

    fun setAutoDownloadMobile(enabled: Boolean) {
        viewModelScope.launch { preferences.setAutoDownloadMobile(enabled) }
    }

    fun setPasscodePin(pin: String?) {
        viewModelScope.launch {
            preferences.setPasscodePin(pin)
            showToast(if (pin.isNullOrBlank()) "Код-пароль отключён" else "Код-пароль установлен")
        }
    }

    fun updateProfile(
        firstName: String,
        lastName: String,
        username: String,
        bio: String,
        birthday: String? = null,
        avatarUri: String? = null
    ) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            repo.updateProfile(email, firstName, lastName, username, bio, birthday, avatarUri)
            showToast("Профиль обновлён")
        }
    }

    fun markChatRead(chatId: String) {
        viewModelScope.launch { repo.markChatRead(chatId) }
    }

    fun saveDraft(chatId: String, draft: String) {
        viewModelScope.launch { repo.saveChatDraft(chatId, draft) }
    }

    fun addPeerToContacts(chatId: String) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            if (repo.addChatPeerToContacts(email, chatId)) {
                showToast("Контакт добавлен")
            }
        }
    }

    fun fetchPeerProfile(peerEmail: String, onLoaded: (PeerProfileData?) -> Unit) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            onLoaded(repo.fetchPeerProfile(email, peerEmail))
        }
    }

    fun publishPost(uri: Uri, caption: String = "", isArchived: Boolean = false) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            val post = repo.publishProfilePost(email, uri, caption, isArchived)
            showToast(if (post != null) "Публикация добавлена" else "Не удалось загрузить фото")
        }
    }

    fun toggleArchivePost(postId: String) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            repo.toggleArchiveProfilePost(email, postId)
        }
    }

    fun deletePost(postId: String) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            repo.deleteProfilePost(email, postId)
            showToast("Публикация удалена")
        }
    }

    fun terminateSession(sessionId: String) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            repo.terminateSession(email, sessionId)
            showToast("Сеанс завершён")
        }
    }

    fun sendText(
        chatId: String,
        text: String,
        replyTo: ChatMessage? = null,
        isSilent: Boolean = false,
        scheduleDelayMinutes: Int = 0
    ) {
        val email = prefs.value.activeEmail ?: return
        typingToEmail = null
        viewModelScope.launch {
            repo.sendTextMessage(email, chatId, text, replyTo, isSilent, scheduleDelayMinutes)
            repo.sendHeartbeat(email, prefs.value.showOnlineStatus, null)
            if (scheduleDelayMinutes > 0) {
                showToast("Запланировано через $scheduleDelayMinutes мин.")
            } else if (isSilent) {
                showToast("Отправлено без звука")
            }
        }
    }

    fun sendPoll(chatId: String, question: String, options: List<String>) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            repo.sendPollMessage(email, chatId, question, options)
        }
    }

    fun votePoll(messageId: String, optionIndex: Int) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            repo.votePoll(email, messageId, optionIndex)
        }
    }

    fun sendPhoto(chatId: String, uri: Uri, caption: String = "", replyTo: ChatMessage? = null) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            repo.sendPhotoMessage(email, chatId, uri, caption, replyTo)
            refreshCacheSize()
        }
    }

    fun sendFile(chatId: String, uri: Uri) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            repo.sendFileMessage(email, chatId, uri)
            refreshCacheSize()
        }
    }

    fun startVoiceRecording(hasMicPermission: Boolean) {
        audioManager.startRecording(hasMicPermission)
    }

    fun finishVoiceRecording(chatId: String, save: Boolean) {
        val result = audioManager.stopRecording(save) ?: return
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            repo.sendVoiceMessage(email, chatId, result.filePath, result.durationSec, result.waveform)
            refreshCacheSize()
        }
    }

    fun toggleVoicePlay(msg: ChatMessage) {
        audioManager.togglePlayback(msg.id, msg.mediaUri, msg.voiceDurationSec)
    }

    fun cycleVoiceSpeed() {
        val next = audioManager.cyclePlaybackSpeed()
        viewModelScope.launch { preferences.setVoicePlaybackSpeed(next) }
    }

    fun seekVoice(messageId: String, fraction: Float) {
        audioManager.seekTo(messageId, fraction)
    }

    fun sendLocation(chatId: String, label: String) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch { repo.sendLocationMessage(email, chatId, label) }
    }

    fun forwardMessage(original: ChatMessage, targetChatId: String) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            repo.forwardMessage(email, original, targetChatId)
            showToast("Сообщение переслано")
        }
    }

    fun editMessage(messageId: String, newText: String) {
        viewModelScope.launch { repo.editMessage(messageId, newText) }
    }

    fun deleteMessage(messageId: String) {
        viewModelScope.launch { repo.deleteMessage(messageId) }
    }

    fun togglePinMessage(chatId: String, messageId: String) {
        viewModelScope.launch { repo.togglePinMessage(chatId, messageId) }
    }

    fun toggleReaction(messageId: String, reactionKey: String) {
        viewModelScope.launch { repo.toggleReaction(messageId, reactionKey) }
    }

    fun toggleArchiveChat(chatId: String) {
        viewModelScope.launch { repo.toggleArchiveChat(chatId) }
    }

    fun togglePinChat(chatId: String) {
        viewModelScope.launch { repo.togglePinChat(chatId) }
    }

    fun toggleMuteChat(chatId: String) {
        viewModelScope.launch { repo.toggleMuteChat(chatId) }
    }

    fun toggleBlockChat(chatId: String) {
        viewModelScope.launch { repo.toggleBlockChat(chatId) }
    }

    fun deleteChat(chatId: String) {
        viewModelScope.launch {
            repo.deleteChat(chatId)
            showToast("Чат удалён")
        }
    }

    fun setAutoDelete(chatId: String, seconds: Int) {
        viewModelScope.launch {
            repo.setAutoDelete(chatId, seconds)
            showToast(if (seconds == 0) "Автоудаление отключено" else "Автоудаление: ${seconds}с")
        }
    }

    fun createContact(firstName: String, lastName: String, emailOrHandle: String, onCreated: (String) -> Unit) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            val chatId = repo.createContactAndChat(email, firstName, lastName, emailOrHandle)
            showToast("Контакт создан")
            onCreated(chatId)
        }
    }

    fun openContactChat(contact: ContactItem, onReady: (String) -> Unit) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            val chatId = repo.openOrCreateChatForContact(email, contact)
            onReady(chatId)
        }
    }

    fun createGroupOrChannel(title: String, isChannel: Boolean, isSecret: Boolean = false, onCreated: (String) -> Unit) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            val id = repo.createGroupOrChannel(email, title, isChannel, isSecret)
            onCreated(id)
        }
    }

    fun openSavedMessages(onReady: (String) -> Unit) {
        val email = prefs.value.activeEmail ?: return
        val savedChat = chats.value.firstOrNull { it.chatType == ChatType.SAVED }
        if (savedChat != null) onReady(savedChat.id) else onReady("${email}_saved")
    }

    fun saveFolder(
        folderId: String?,
        name: String,
        includeTypes: Set<ChatType>,
        includedChatIds: Set<String>,
        onlyUnread: Boolean
    ) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            repo.saveFolder(email, folderId, name, includeTypes, includedChatIds, onlyUnread)
            showToast("Папка сохранена")
        }
    }

    fun deleteFolder(folderId: String) {
        viewModelScope.launch {
            repo.deleteFolder(folderId)
            if (_selectedFolderId.value == folderId) _selectedFolderId.value = null
            showToast("Папка удалена")
        }
    }

    fun createGiftCollection(name: String) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            repo.createGiftCollection(email, name)
            showToast("Коллекция «$name» создана")
        }
    }

    fun assignGiftToCollection(giftId: String, collectionName: String) {
        viewModelScope.launch {
            repo.assignGiftToCollection(giftId, collectionName)
            showToast("Подарок добавлен в «$collectionName»")
        }
    }

    fun transferGift(giftId: String, targetChatId: String, onDone: () -> Unit = {}) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            val ok = repo.transferGiftToChat(email, giftId, targetChatId)
            showToast(if (ok) "Подарок передан получателю!" else "Не удалось передать подарок")
            if (ok) onDone()
        }
    }

    fun topUpStars(amount: Long) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            repo.topUpStars(email, amount)
            showToast("Зачислено +$amount Звёзд")
        }
    }

    fun topUpGram(amount: Double) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            repo.topUpGram(email, amount)
            showToast("Зачислено +${ForkGramRepository.formatGram(amount)} GRAM")
        }
    }

    fun swapGramToStars(gramAmount: Double) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            val ok = repo.swapGramToStars(email, gramAmount)
            showToast(if (ok) "Обмен выполнен" else "Недостаточно GRAM")
        }
    }

    fun sendGramInChat(chatId: String, amount: Double, note: String) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            val ok = repo.sendGramInChat(email, chatId, amount, note)
            showToast(if (ok) "Отправлено ${ForkGramRepository.formatGram(amount)} GRAM" else "Недостаточно GRAM")
        }
    }

    fun sendGift(giftKind: GiftKind, asNft: Boolean, targetChatId: String?, comment: String) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            val ok = repo.purchaseAndSendGift(email, giftKind, asNft, targetChatId, comment)
            showToast(if (ok) "Подарок отправлен!" else "Недостаточно Звёзд")
        }
    }

    suspend fun lookupNft(kind: GiftKind, number: Int): OwnedGift? = repo.lookupNft(kind, number)

    fun upgradeGiftToNft(giftId: String, onUpgraded: (OwnedGift) -> Unit = {}) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            val upgraded = repo.upgradeGiftToNft(email, giftId)
            if (upgraded != null) {
                showToast("Улучшено до NFT: ${upgraded.modelName}!")
                onUpgraded(upgraded)
            } else {
                showToast("Недостаточно Звёзд для улучшения")
            }
        }
    }

    fun convertGiftToStars(giftId: String) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            val refund = repo.convertGiftToStars(email, giftId)
            if (refund != null) showToast("Обменяно на +$refund Звёзд")
        }
    }

    fun togglePinGift(giftId: String) {
        viewModelScope.launch { repo.togglePinGift(giftId) }
    }

    fun toggleWearGiftStatus(giftId: String) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            repo.toggleWearGiftStatus(email, giftId)
            showToast("Статус профиля обновлён")
        }
    }

    fun refreshFragmentMarket() {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch { repo.refreshFragmentMarket(email) }
    }

    fun buyNftUsername(itemId: String) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            val (_, msg) = repo.buyFragmentUsername(email, itemId)
            showToast(msg)
        }
    }

    fun bidNftUsername(itemId: String, amountGram: Double) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            val (_, msg) = repo.bidFragmentUsername(email, itemId, amountGram)
            showToast(msg)
        }
    }

    fun mintCustomNftUsername(handle: String) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            val (_, msg) = repo.mintCustomNftUsername(email, handle)
            showToast(msg)
        }
    }

    fun sellNftUsername(itemId: String, mode: String, priceGram: Double) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            val (_, msg) = repo.sellFragmentUsername(email, itemId, mode, priceGram)
            showToast(msg)
        }
    }

    fun cancelNftSale(itemId: String) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            val (_, msg) = repo.cancelFragmentSale(email, itemId)
            showToast(msg)
        }
    }

    fun listGiftOnFragment(giftId: String, priceGram: Double, onDone: () -> Unit = {}) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            val (ok, msg) = repo.listGiftOnFragment(email, giftId, priceGram)
            showToast(msg)
            if (ok) onDone()
        }
    }

    fun buyFragmentGift(listingId: String) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            val (_, msg) = repo.buyFragmentGift(email, listingId)
            showToast(msg)
        }
    }

    fun toggleEquipNftUsername(itemId: String) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch { repo.toggleEquipNftUsername(email, itemId) }
    }

    fun activatePremium(useGram: Boolean) {
        val email = prefs.value.activeEmail ?: return
        viewModelScope.launch {
            val ok = repo.activatePremium(email, useGram)
            showToast(if (ok) "Fork Gram Premium активирован!" else "Недостаточно средств")
        }
    }
}
