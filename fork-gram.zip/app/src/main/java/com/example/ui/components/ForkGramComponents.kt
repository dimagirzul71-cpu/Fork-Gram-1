package com.example.ui.components

import com.example.data.model.GiftRarity

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.Bookmark
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CallEnd
import androidx.compose.material.icons.rounded.CardGiftcard
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CollectionsBookmark
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.model.CallSessionState
import com.example.data.model.ChatThread
import com.example.data.model.ChatType
import com.example.data.model.GiftBackdrop
import com.example.data.model.GiftCollectionTab
import com.example.data.model.GiftKind
import com.example.data.model.GiftSymbol
import com.example.data.model.MainTab
import com.example.data.model.OwnedGift
import com.example.data.model.UserAccount
import com.example.ui.svg.AnimatedTelegramGift
import com.example.ui.svg.SvgGramGemIcon
import com.example.ui.svg.SvgNavChatsIcon
import com.example.ui.svg.SvgPaperPlaneIcon
import com.example.ui.svg.SvgStarIcon
import com.example.ui.svg.TelegramGiftBackdropBox
import com.example.ui.theme.GramCyan
import com.example.ui.theme.LocalForkPalette
import com.example.ui.theme.PremiumViolet
import com.example.ui.theme.StarGold
import com.example.ui.theme.TgBlue
import kotlinx.coroutines.delay
import java.io.File

@Composable
fun TelegramOutlinedField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String = "",
    leadingIcon: (@Composable () -> Unit)? = null,
    isError: Boolean = false,
    supportingText: String? = null,
    singleLine: Boolean = true,
    maxLines: Int = if (singleLine) 1 else 3,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    containerColor: Color? = null,
    modifier: Modifier = Modifier
) {
    val palette = LocalForkPalette.current
    val resolvedContainer = containerColor ?: palette.surface
    val unfocusedBorder = if (palette.isDark) Color(0xFF334252) else Color(0xFFD5D9DF)
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, fontSize = 13.5.sp) },
        placeholder = if (placeholder.isNotEmpty()) ({ Text(placeholder, color = palette.textSecondary) }) else null,
        leadingIcon = leadingIcon,
        isError = isError,
        supportingText = supportingText?.let { msg -> { Text(msg) } },
        singleLine = singleLine,
        maxLines = maxLines,
        keyboardOptions = keyboardOptions,
        keyboardActions = keyboardActions,
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = resolvedContainer,
            unfocusedContainerColor = resolvedContainer,
            disabledContainerColor = resolvedContainer,
            errorContainerColor = resolvedContainer,
            focusedBorderColor = TgBlue,
            unfocusedBorderColor = unfocusedBorder,
            focusedLabelColor = TgBlue,
            unfocusedLabelColor = palette.textSecondary,
            cursorColor = TgBlue,
            focusedTextColor = palette.textPrimary,
            unfocusedTextColor = palette.textPrimary
        ),
        modifier = modifier.fillMaxWidth()
    )
}

class TelegramChatBubbleShape(
    private val isOutgoing: Boolean,
    private val hasTail: Boolean,
    private val cornerRadiusDp: Dp = 16.dp,
    private val isFirstInGroup: Boolean = true
) : Shape {
    override fun createOutline(
        size: Size,
        layoutDirection: LayoutDirection,
        density: Density
    ): Outline {
        val r = with(density) { cornerRadiusDp.toPx() }.coerceAtMost(size.minDimension / 2f)
        val smallInner = with(density) { 5.dp.toPx() }.coerceAtMost(r)
        val tailW = if (hasTail) with(density) { 7.dp.toPx() } else 0f
        val tailH = if (hasTail) with(density) { 10.dp.toPx() } else 0f
        val bodyLeft = if (!isOutgoing && hasTail) tailW else 0f
        val bodyRight = if (isOutgoing && hasTail) size.width - tailW else size.width
        val w = bodyRight - bodyLeft
        val h = size.height
        val cr = r.coerceAtMost(w / 2f).coerceAtMost(h / 2f)
        val tlR = if (!isOutgoing && !isFirstInGroup) smallInner else cr
        val trR = if (isOutgoing && !isFirstInGroup) smallInner else cr
        val brR = if (isOutgoing && !hasTail) smallInner else cr
        val blR = if (!isOutgoing && !hasTail) smallInner else cr

        val path = Path().apply {
            // Top-left to top-right
            moveTo(bodyLeft + tlR, 0f)
            lineTo(bodyRight - trR, 0f)
            arcTo(Rect(bodyRight - 2 * trR, 0f, bodyRight, 2 * trR), -90f, 90f, false)

            if (isOutgoing && hasTail) {
                lineTo(bodyRight, h - tailH)
                cubicTo(
                    bodyRight, h - tailH * 0.25f,
                    bodyRight + tailW * 0.45f, h - 1f,
                    size.width, h
                )
                cubicTo(
                    bodyRight + tailW * 0.25f, h,
                    bodyRight - cr * 0.25f, h,
                    bodyRight - cr * 0.6f, h
                )
            } else {
                lineTo(bodyRight, h - brR)
                arcTo(Rect(bodyRight - 2 * brR, h - 2 * brR, bodyRight, h), 0f, 90f, false)
            }

            if (!isOutgoing && hasTail) {
                lineTo(bodyLeft + cr * 0.6f, h)
                cubicTo(
                    bodyLeft + cr * 0.25f, h,
                    bodyLeft - tailW * 0.25f, h,
                    0f, h
                )
                cubicTo(
                    bodyLeft - tailW * 0.45f, h - 1f,
                    bodyLeft, h - tailH * 0.25f,
                    bodyLeft, h - tailH
                )
            } else {
                lineTo(bodyLeft + blR, h)
                arcTo(Rect(bodyLeft, h - 2 * blR, bodyLeft + 2 * blR, h), 90f, 90f, false)
            }

            lineTo(bodyLeft, tlR)
            arcTo(Rect(bodyLeft, 0f, bodyLeft + 2 * tlR, 2 * tlR), 180f, 90f, false)
            close()
        }
        return Outline.Generic(path)
    }
}

@Composable
fun TelegramRoundedField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String = "",
    leadingIcon: (@Composable () -> Unit)? = null,
    isError: Boolean = false,
    supportingText: String? = null,
    singleLine: Boolean = true,
    maxLines: Int = if (singleLine) 1 else 3,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    modifier: Modifier = Modifier
) {
    val palette = LocalForkPalette.current
    TextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        placeholder = if (placeholder.isNotEmpty()) ({ Text(placeholder) }) else null,
        leadingIcon = leadingIcon,
        isError = isError,
        supportingText = supportingText?.let { msg -> { Text(msg) } },
        singleLine = singleLine,
        maxLines = maxLines,
        keyboardOptions = keyboardOptions,
        keyboardActions = keyboardActions,
        shape = RoundedCornerShape(16.dp),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = palette.surfaceVariant,
            unfocusedContainerColor = palette.surfaceVariant,
            disabledContainerColor = palette.surfaceVariant,
            errorContainerColor = palette.surfaceVariant,
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
            disabledIndicatorColor = Color.Transparent,
            errorIndicatorColor = Color.Transparent,
            focusedLabelColor = TgBlue,
            unfocusedLabelColor = palette.textSecondary,
            cursorColor = TgBlue,
            focusedTextColor = palette.textPrimary,
            unfocusedTextColor = palette.textPrimary
        ),
        modifier = modifier.fillMaxWidth()
    )
}

@Composable
fun AvatarView(
    title: String,
    avatarUri: String?,
    colorHex: Long,
    size: Dp = 52.dp,
    chatType: ChatType? = null,
    modifier: Modifier = Modifier
) {
    val bgColor = Color(colorHex)
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(
                Brush.linearGradient(
                    listOf(bgColor, bgColor.copy(alpha = 0.80f))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        when {
            chatType == ChatType.SERVICE -> {
                SvgPaperPlaneIcon(
                    modifier = Modifier.size(size * 0.56f),
                    color = Color.White
                )
            }
            chatType == ChatType.SAVED -> {
                Icon(
                    imageVector = Icons.Outlined.Bookmark,
                    contentDescription = "Избранное",
                    tint = Color.White,
                    modifier = Modifier.size(size * 0.52f)
                )
            }
            chatType == ChatType.SECRET -> {
                Icon(
                    imageVector = Icons.Rounded.Lock,
                    contentDescription = "Секретный чат",
                    tint = Color.White,
                    modifier = Modifier.size(size * 0.48f)
                )
            }
            !avatarUri.isNullOrBlank() -> {
                val model = if (avatarUri.startsWith("/")) File(avatarUri) else avatarUri
                AsyncImage(
                    model = model,
                    contentDescription = title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            else -> {
                val initials = title.trim()
                    .split(Regex("\\s+"))
                    .filter { it.isNotBlank() }
                    .take(2)
                    .joinToString("") { it.first().uppercaseChar().toString() }
                    .ifBlank { "FG" }
                Text(
                    text = initials,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = (size.value * 0.36f).sp
                )
            }
        }
    }
}

@Composable
fun ArchiveAvatar(size: Dp = 52.dp) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(Color(0xFF9AA5B1)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Outlined.Inventory2,
            contentDescription = "Архив чатов",
            tint = Color.White,
            modifier = Modifier.size(size * 0.50f)
        )
    }
}

@Composable
fun FloatingBottomNavBar(
    selectedTab: MainTab,
    account: UserAccount?,
    unreadChatsCount: Int,
    onSelectTab: (MainTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalForkPalette.current
    val glassBorder = if (palette.isDark) Color.White.copy(alpha = 0.14f) else Color(0xFFE6E9EE)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 32.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier
                .widthIn(max = 356.dp)
                .fillMaxWidth()
                .shadow(
                    elevation = 14.dp,
                    shape = RoundedCornerShape(32.dp),
                    ambientColor = Color.Black.copy(alpha = 0.14f),
                    spotColor = Color.Black.copy(alpha = 0.16f)
                )
                .border(0.8.dp, glassBorder, RoundedCornerShape(32.dp)),
            shape = RoundedCornerShape(32.dp),
            color = palette.navPill,
            tonalElevation = 1.dp
        ) {
            Box(
                modifier = Modifier.background(
                    Brush.verticalGradient(
                        listOf(
                            Color.White.copy(alpha = if (palette.isDark) 0.06f else 0.35f),
                            Color.Transparent
                        )
                    )
                )
            ) {
            Row(
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                NavPillItem(
                    label = "Чаты",
                    selected = selectedTab == MainTab.CHATS,
                    badgeCount = unreadChatsCount,
                    testTag = "nav_chats",
                    onClick = { onSelectTab(MainTab.CHATS) },
                    modifier = Modifier.weight(1f)
                ) { color, selected ->
                    SvgNavChatsIcon(
                        isSelected = selected,
                        color = color,
                        modifier = Modifier.size(22.dp)
                    )
                }

                NavPillItem(
                    label = "Контакты",
                    selected = selectedTab == MainTab.CONTACTS,
                    badgeCount = 0,
                    testTag = "nav_contacts",
                    onClick = { onSelectTab(MainTab.CONTACTS) },
                    modifier = Modifier.weight(1f)
                ) { color, selected ->
                    Icon(
                        imageVector = if (selected) Icons.Rounded.AccountCircle else Icons.Outlined.AccountCircle,
                        contentDescription = "Контакты",
                        tint = color,
                        modifier = Modifier.size(22.dp)
                    )
                }

                NavPillItem(
                    label = "Настройки",
                    selected = selectedTab == MainTab.SETTINGS,
                    badgeCount = 0,
                    testTag = "nav_settings",
                    onClick = { onSelectTab(MainTab.SETTINGS) },
                    modifier = Modifier.weight(1f)
                ) { color, selected ->
                    Icon(
                        imageVector = if (selected) Icons.Rounded.Settings else Icons.Outlined.Settings,
                        contentDescription = "Настройки",
                        tint = color,
                        modifier = Modifier.size(22.dp)
                    )
                }

                NavPillItem(
                    label = "Профиль",
                    selected = selectedTab == MainTab.PROFILE,
                    badgeCount = 0,
                    testTag = "nav_profile",
                    onClick = { onSelectTab(MainTab.PROFILE) },
                    modifier = Modifier.weight(1f)
                ) { _, selected ->
                    Box(
                        modifier = Modifier
                            .size(23.dp)
                            .then(
                                if (selected) Modifier.border(1.5.dp, TgBlue, CircleShape)
                                else Modifier
                            )
                            .padding(1.dp)
                    ) {
                        AvatarView(
                            title = account?.fullName ?: "FG",
                            avatarUri = account?.avatarUri,
                            colorHex = 0xFF239AE8,
                            size = 22.dp
                        )
                    }
                }
            }
            }
        }
    }
}

@Composable
private fun NavPillItem(
    label: String,
    selected: Boolean,
    badgeCount: Int,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: @Composable (Color, Boolean) -> Unit
) {
    val palette = LocalForkPalette.current
    val pillColor by animateColorAsState(
        targetValue = if (selected) palette.navActivePill else Color.Transparent,
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "navPillBg"
    )
    val contentColor by animateColorAsState(
        targetValue = if (selected) TgBlue else palette.textPrimary,
        label = "navContent"
    )

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(26.dp))
            .background(pillColor)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .testTag(testTag)
            .padding(vertical = 5.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(contentAlignment = Alignment.Center) {
            icon(contentColor, selected)
            if (badgeCount > 0) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .offset(x = 9.dp, y = (-3).dp)
                        .clip(CircleShape)
                        .background(TgBlue)
                        .padding(horizontal = 4.dp, vertical = 0.5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (badgeCount > 99) "99+" else badgeCount.toString(),
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
            color = contentColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GiftShopBottomSheet(
    starsBalance: Long,
    recipientName: String,
    onDismiss: () -> Unit,
    onSendGift: (GiftKind, Boolean, String) -> Unit
) {
    val palette = LocalForkPalette.current
    var selectedGift by remember { mutableStateOf(GiftKind.PLUSH_PEPE) }
    var asNft by remember { mutableStateOf(true) }
    var comment by remember { mutableStateOf("") }
    val totalPrice = if (asNft) selectedGift.baseStars + selectedGift.upgradeStars else selectedGift.baseStars

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = palette.surface,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp)
                .padding(bottom = 26.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Подарки Fork Gram",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary
                    )
                    Text(
                        text = "Получатель: $recipientName",
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textSecondary
                    )
                }
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(18.dp))
                        .background(StarGold.copy(alpha = 0.16f))
                        .padding(horizontal = 11.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SvgStarIcon(modifier = Modifier.size(16.dp), color = StarGold)
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = starsBalance.toString(),
                        fontWeight = FontWeight.Bold,
                        color = StarGold,
                        fontSize = 14.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(315.dp),
                horizontalArrangement = Arrangement.spacedBy(9.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                items(GiftKind.entries) { gift ->
                    val isSelected = gift == selectedGift
                    TelegramGiftBackdropBox(
                        backdrop = gift.defaultBackdrop,
                        symbol = gift.defaultSymbol,
                        showShimmer = isSelected,
                        modifier = Modifier
                            .clip(RoundedCornerShape(18.dp))
                            .then(
                                if (isSelected) Modifier.border(2.5.dp, Color.White, RoundedCornerShape(18.dp))
                                else Modifier
                            )
                            .clickable { selectedGift = gift }
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 9.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            AnimatedTelegramGift(
                                giftKind = gift,
                                animate = isSelected,
                                editionNumber = gift.validDemoEditions.firstOrNull(),
                                modifier = Modifier.size(74.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = gift.title,
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .padding(top = 2.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color.Black.copy(alpha = 0.25f))
                                    .padding(horizontal = 6.dp, vertical = 1.dp)
                            ) {
                                SvgStarIcon(modifier = Modifier.size(10.dp), color = StarGold)
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "${gift.baseStars}",
                                    color = Color.White,
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(palette.surfaceVariant)
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(
                        imageVector = Icons.Rounded.AutoAwesome,
                        contentDescription = null,
                        tint = PremiumViolet,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Улучшить в коллекционный (+${selectedGift.upgradeStars})",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.5.sp,
                            color = palette.textPrimary
                        )
                        Text(
                            text = "Случайная модель, фон, узор и номер",
                            fontSize = 11.5.sp,
                            color = palette.textSecondary
                        )
                    }
                }
                Switch(
                    checked = asNft,
                    onCheckedChange = { asNft = it },
                    colors = SwitchDefaults.colors(checkedTrackColor = TgBlue)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            TelegramOutlinedField(
                value = comment,
                onValueChange = { comment = it },
                label = "Подпись к подарку (необязательно)"
            )

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = { onSendGift(selectedGift, asNft, comment) },
                enabled = starsBalance >= totalPrice,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("confirm_send_gift_button"),
                shape = RoundedCornerShape(22.dp),
                colors = ButtonDefaults.buttonColors(containerColor = TgBlue)
            ) {
                Icon(Icons.Rounded.CardGiftcard, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (starsBalance >= totalPrice) {
                        "Отправить за $totalPrice Звёзд"
                    } else {
                        "Недостаточно Звёзд ($totalPrice)"
                    },
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GiftDetailBottomSheet(
    gift: OwnedGift,
    collections: List<GiftCollectionTab>,
    starsBalance: Long,
    isOwnGift: Boolean = true,
    availableChats: List<ChatThread> = emptyList(),
    onDismiss: () -> Unit,
    onTogglePin: () -> Unit,
    onToggleWearStatus: () -> Unit,
    onAssignCollection: (String) -> Unit,
    onUpgradeToNft: ((OwnedGift) -> Unit) -> Unit,
    onConvertToStars: () -> Unit,
    onTransferGift: ((String) -> Unit)? = null,
    onListOnFragment: ((Double) -> Unit)? = null,
    onShowToast: (String) -> Unit = {},
    ownerName: String = ""
) {
    val palette = LocalForkPalette.current
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current
    var displayGift by remember(gift.id) { mutableStateOf(gift) }
    var isRollingUpgrade by remember(gift.id) { mutableStateOf(false) }
    var rollTick by remember { mutableIntStateOf(0) }
    var showCollectionPicker by remember { mutableStateOf(false) }
    var showTransferPicker by remember { mutableStateOf(false) }
    var showFragmentPriceDialog by remember { mutableStateOf(false) }

    LaunchedEffect(gift) {
        if (!isRollingUpgrade) displayGift = gift
    }

    LaunchedEffect(isRollingUpgrade) {
        if (isRollingUpgrade) {
            repeat(12) {
                rollTick = it
                delay(90L)
            }
            onUpgradeToNft { upgraded ->
                displayGift = upgraded
                isRollingUpgrade = false
            }
        }
    }

    val activeBackdrop = if (isRollingUpgrade) {
        GiftBackdrop.entries[rollTick % GiftBackdrop.entries.size]
    } else {
        displayGift.backdrop
    }
    val activeSymbol = if (isRollingUpgrade) {
        GiftSymbol.entries[(rollTick * 3) % GiftSymbol.entries.size]
    } else {
        displayGift.symbol
    }
    val activeModel = if (isRollingUpgrade) {
        GiftRarity.modelsNormalized(displayGift.giftKind.models)[rollTick % displayGift.giftKind.models.size]
    } else {
        displayGift.modelName to displayGift.modelRarity
    }

    val shareNftLink: () -> Unit = {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(
                Intent.EXTRA_TEXT,
                "${displayGift.giftKind.title} #${displayGift.editionNumber} — ${displayGift.nftUrl}\n${displayGift.forkGramNftUrl}"
            )
        }
        runCatching {
            context.startActivity(Intent.createChooser(intent, "Поделиться NFT-подарком"))
        }
    }

    val copyNftLink: () -> Unit = {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("ForkGramNFT", displayGift.nftUrl))
        onShowToast("Ссылка ${displayGift.nftUrl} скопирована")
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = palette.surface,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(bottom = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1:1 Telegram Collectible Hero Backdrop Banner with Close (X) + Share + Action Tiles
            TelegramGiftBackdropBox(
                backdrop = activeBackdrop,
                symbol = activeSymbol,
                showShimmer = displayGift.isNft || isRollingUpgrade,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(if (isOwnGift) 332.dp else 272.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.24f))
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Закрыть",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(
                            onClick = shareNftLink,
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.24f))
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Share,
                                contentDescription = "Поделиться NFT-ссылкой",
                                tint = Color.White,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                        if (isOwnGift) {
                            IconButton(
                                onClick = { showCollectionPicker = !showCollectionPicker },
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.24f))
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.CollectionsBookmark,
                                    contentDescription = "Коллекции",
                                    tint = Color.White,
                                    modifier = Modifier.size(17.dp)
                                )
                            }
                        }
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = 26.dp, bottom = 14.dp, start = 16.dp, end = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        val heroScale by animateFloatAsState(
                            targetValue = if (isRollingUpgrade) 1.08f else 1f,
                            animationSpec = spring(dampingRatio = 0.55f),
                            label = "heroScale"
                        )
                        AnimatedTelegramGift(
                            giftKind = displayGift.giftKind,
                            animate = true,
                            editionNumber = displayGift.editionNumber,
                            useRemoteEdition = displayGift.isNft,
                            modifier = Modifier
                                .size(154.dp)
                                .scale(heroScale)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = displayGift.giftKind.title,
                            fontSize = 21.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color.Black.copy(alpha = 0.26f)
                        ) {
                            Text(
                                text = when {
                                    isRollingUpgrade -> "Генерация уникального NFT..."
                                    displayGift.isNft -> "Коллекционный подарок #${displayGift.editionNumber}"
                                    else -> "Подарок #${displayGift.editionNumber} • Обычный"
                                },
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                            )
                        }
                    }

                    if (isOwnGift) {
                        // 3 Square Translucent Quick-Action Tiles inside Hero (1:1 Telegram Collectible Sheet)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            GiftHeroTileButton(
                                icon = Icons.Rounded.AutoAwesome,
                                label = if (displayGift.isWornAsStatus) "Снять статус" else "Надеть",
                                active = displayGift.isWornAsStatus,
                                onClick = {
                                    onToggleWearStatus()
                                    displayGift = displayGift.copy(isWornAsStatus = !displayGift.isWornAsStatus)
                                },
                                modifier = Modifier.weight(1f)
                            )
                            GiftHeroTileButton(
                                icon = Icons.Rounded.PushPin,
                                label = if (displayGift.isPinned) "Открепить" else "Закрепить",
                                active = displayGift.isPinned,
                                onClick = {
                                    onTogglePin()
                                    displayGift = displayGift.copy(isPinned = !displayGift.isPinned)
                                },
                                modifier = Modifier.weight(1f)
                            )
                            GiftHeroTileButton(
                                icon = Icons.Rounded.CollectionsBookmark,
                                label = "Коллекция",
                                active = showCollectionPicker,
                                onClick = { showCollectionPicker = !showCollectionPicker },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 1:1 Telegram Collectible Traits Table with Unique Shareable NFT Link
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = palette.surfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    GiftTraitRow(
                        label = "Владелец",
                        value = displayGift.ownerName.ifBlank { ownerName }.ifBlank { "—" }
                    )
                    TraitDivider()
                    GiftTraitRow(
                        label = "Модель",
                        value = activeModel.first,
                        rarityPill = activeModel.second
                    )
                    TraitDivider()
                    GiftTraitRow(
                        label = "Фон",
                        value = activeBackdrop.title,
                        rarityPill = activeBackdrop.rarityPercent,
                        colorDot = Color(activeBackdrop.centerHex)
                    )
                    TraitDivider()
                    GiftTraitRow(
                        label = "Узор",
                        value = activeSymbol.title,
                        rarityPill = activeSymbol.rarityPercent
                    )
                    TraitDivider()
                    GiftTraitRow(
                        label = "Количество",
                        value = "${displayGift.editionNumber} / ${displayGift.giftKind.totalIssued} выпущено"
                    )
                    TraitDivider()
                    // Unique NFT Link Row (t.me/nft/<Slug>-<Edition>)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { copyNftLink() }
                            .padding(horizontal = 16.dp, vertical = 11.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "NFT-ссылка",
                            color = palette.textSecondary,
                            fontSize = 13.5.sp
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = displayGift.nftUrl.removePrefix("https://").removePrefix("http://"),
                                color = TgBlue,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.widthIn(max = 175.dp)
                            )
                            IconButton(
                                onClick = copyNftLink,
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.ContentCopy,
                                    contentDescription = "Копировать ссылку",
                                    tint = TgBlue,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                            IconButton(
                                onClick = { runCatching { uriHandler.openUri(displayGift.forkGramNftUrl) } },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.OpenInNew,
                                    contentDescription = "Открыть NFT-страницу",
                                    tint = TgBlue,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                    if (isOwnGift) {
                        TraitDivider()
                        GiftTraitRow(
                            label = "Коллекция",
                            value = displayGift.collectionName,
                            trailingAction = "Выбрать",
                            onClick = { showCollectionPicker = !showCollectionPicker }
                        )
                    }
                    TraitDivider()
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Ценность", color = palette.textSecondary, fontSize = 13.5.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            SvgStarIcon(modifier = Modifier.size(14.dp), color = StarGold)
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = "${displayGift.starsValue} Звёзд",
                                color = palette.textPrimary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.5.sp
                            )
                        }
                    }
                }
            }

            if (isOwnGift && showCollectionPicker) {
                Spacer(modifier = Modifier.height(10.dp))
                val colNames = listOf("Все подарки", "NFT Коллекция", "Обычные подарки") + collections.map { it.name }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    colNames.distinct().forEach { name ->
                        val active = displayGift.collectionName == name
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (active) TgBlue else palette.surfaceVariant,
                            modifier = Modifier.clickable {
                                onAssignCollection(name)
                                displayGift = displayGift.copy(collectionName = name)
                                showCollectionPicker = false
                            }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.CollectionsBookmark,
                                    contentDescription = null,
                                    tint = if (active) Color.White else TgBlue,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = name,
                                    color = if (active) Color.White else palette.textPrimary,
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }

            if (displayGift.messageText.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = palette.surfaceVariant,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    Text(
                        text = displayGift.messageText,
                        color = palette.textPrimary,
                        fontSize = 13.5.sp,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (isOwnGift) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = if (displayGift.isPinned) TgBlue.copy(alpha = 0.14f) else palette.surfaceVariant,
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                onTogglePin()
                                displayGift = displayGift.copy(isPinned = !displayGift.isPinned)
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 12.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Rounded.PushPin,
                                contentDescription = null,
                                tint = if (displayGift.isPinned) TgBlue else palette.textPrimary,
                                modifier = Modifier.size(17.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (displayGift.isPinned) "Открепить" else "Закрепить",
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (displayGift.isPinned) TgBlue else palette.textPrimary
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = if (displayGift.isWornAsStatus) Color(activeBackdrop.centerHex) else palette.surfaceVariant,
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                onToggleWearStatus()
                                displayGift = displayGift.copy(isWornAsStatus = !displayGift.isWornAsStatus)
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 12.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (displayGift.isWornAsStatus) "Снять статус" else "Надеть статус",
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (displayGift.isWornAsStatus) Color.White else palette.textPrimary
                            )
                        }
                    }
                }

                if (!displayGift.isNft) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = { if (!isRollingUpgrade) isRollingUpgrade = true },
                        enabled = starsBalance >= displayGift.giftKind.upgradeStars && !isRollingUpgrade,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .height(48.dp)
                            .testTag("upgrade_gift_nft_button"),
                        shape = RoundedCornerShape(22.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PremiumViolet)
                    ) {
                        Icon(Icons.Rounded.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isRollingUpgrade) "Улучшение..." else "Улучшить в NFT за ${displayGift.giftKind.upgradeStars} Звёзд",
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                val dmRecipients = remember(availableChats) {
                    availableChats.filter { it.chatType == ChatType.DIRECT && !it.email.isNullOrBlank() && it.email.contains("@") }
                }
                if (onTransferGift != null && dmRecipients.isNotEmpty()) {
                    OutlinedButton(
                        onClick = { showTransferPicker = !showTransferPicker },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .height(46.dp),
                        shape = RoundedCornerShape(22.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Rounded.Send, contentDescription = null, modifier = Modifier.size(17.dp), tint = TgBlue)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Передать другу", color = TgBlue, fontWeight = FontWeight.SemiBold)
                    }
                    if (showTransferPicker) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(palette.surfaceVariant)
                                .padding(vertical = 4.dp)
                        ) {
                            dmRecipients.forEach { target ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            showTransferPicker = false
                                            onTransferGift(target.id)
                                        }
                                        .padding(horizontal = 14.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    AvatarView(
                                        title = target.title,
                                        avatarUri = target.avatarUri,
                                        colorHex = target.avatarColorHex,
                                        size = 34.dp
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(target.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = palette.textPrimary)
                                        Text(target.username ?: target.email.orEmpty(), fontSize = 12.sp, color = palette.textSecondary)
                                    }
                                    Text("Отправить", color = TgBlue, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                if (displayGift.isNft && onListOnFragment != null) {
                    OutlinedButton(
                        onClick = { showFragmentPriceDialog = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .height(46.dp),
                        shape = RoundedCornerShape(22.dp)
                    ) {
                        SvgGramGemIcon(modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Продать на Fragment (GRAM)", color = GramCyan, fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                Button(
                    onClick = onConvertToStars,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .height(48.dp),
                    shape = RoundedCornerShape(22.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TgBlue)
                ) {
                    Text(
                        text = "Обменять на ${(displayGift.starsValue * 0.85).toInt().coerceAtLeast(25)} Звёзд",
                        fontWeight = FontWeight.SemiBold
                    )
                }
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = shareNftLink,
                        shape = RoundedCornerShape(22.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = TgBlue),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(Icons.Rounded.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Поделиться", fontWeight = FontWeight.SemiBold)
                    }
                    Button(
                        onClick = { runCatching { uriHandler.openUri(displayGift.forkGramNftUrl) } },
                        shape = RoundedCornerShape(22.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(activeBackdrop.centerHex)),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(Icons.Rounded.OpenInNew, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Открыть NFT", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }

    if (showFragmentPriceDialog && onListOnFragment != null) {
        var priceText by remember { mutableStateOf("25") }
        AlertDialog(
            onDismissRequest = { showFragmentPriceDialog = false },
            containerColor = palette.surface,
            shape = RoundedCornerShape(24.dp),
            title = { Text("Продать NFT на Fragment", fontWeight = FontWeight.Bold, color = palette.textPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Укажите цену в GRAM для «${displayGift.giftKind.title} #${displayGift.editionNumber}»",
                        fontSize = 13.5.sp,
                        color = palette.textSecondary
                    )
                    TelegramOutlinedField(
                        value = priceText,
                        onValueChange = { priceText = it },
                        label = "Цена (GRAM)",
                        placeholder = "25.0"
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val gram = priceText.replace(",", ".").toDoubleOrNull() ?: 0.0
                        if (gram >= 1.0) {
                            showFragmentPriceDialog = false
                            onListOnFragment(gram)
                        }
                    },
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = GramCyan)
                ) {
                    Text("Выставить", color = Color.White, fontWeight = FontWeight.SemiBold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showFragmentPriceDialog = false }) {
                    Text("Отмена", color = palette.textSecondary)
                }
            }
        )
    }
}

@Composable
private fun GiftTraitRow(
    label: String,
    value: String,
    rarityPill: String? = null,
    colorDot: Color? = null,
    trailingAction: String? = null,
    onClick: (() -> Unit)? = null
) {
    val palette = LocalForkPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 16.dp, vertical = 11.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = palette.textSecondary, fontSize = 13.5.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (colorDot != null) {
                Box(
                    modifier = Modifier
                        .size(11.dp)
                        .clip(CircleShape)
                        .background(colorDot)
                )
                Spacer(modifier = Modifier.width(6.dp))
            }
            Text(
                text = value,
                color = if (trailingAction != null) TgBlue else palette.textPrimary,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.5.sp
            )
            if (rarityPill != null) {
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(TgBlue.copy(alpha = 0.14f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = rarityPill,
                        color = TgBlue,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            if (trailingAction != null) {
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = trailingAction,
                    color = TgBlue.copy(alpha = 0.8f),
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun GiftHeroTileButton(
    icon: ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (active) Color.White.copy(alpha = 0.30f) else Color.Black.copy(alpha = 0.22f),
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = label,
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun TraitDivider() {
    val palette = LocalForkPalette.current
    HorizontalDivider(color = palette.divider, modifier = Modifier.padding(start = 16.dp))
}

@Composable
fun TelegramQrDialog(
    title: String,
    handle: String,
    subtitle: String = "Отсканируйте код, чтобы написать пользователю",
    onDismiss: () -> Unit,
    onShowToast: (String) -> Unit
) {
    val context = LocalContext.current
    val cleanHandle = handle.trim().let { if (it.startsWith("@")) it else "@$it" }
    val link = "http://forkgram.xsph.ru/u/${cleanHandle.removePrefix("@")}"
    var themeIdx by remember { mutableIntStateOf(0) }
    val qrThemes = remember {
        listOf(
            Color(0xFF2AABEE) to Color(0xFF1A73E8),
            Color(0xFF27AE60) to Color(0xFF157A44),
            Color(0xFFF2994A) to Color(0xFFD9534F),
            Color(0xFF8A63D2) to Color(0xFF5634A6)
        )
    }
    val (c1, c2) = qrThemes[themeIdx % qrThemes.size]

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(c1, c2)))
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(20.dp)
        ) {
            IconButton(
                onClick = onDismiss,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.22f))
            ) {
                Icon(Icons.Rounded.Close, contentDescription = "Закрыть", tint = Color.White)
            }

            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .fillMaxWidth()
                    .widthIn(max = 340.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    shape = RoundedCornerShape(28.dp),
                    color = Color.White,
                    shadowElevation = 14.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        DeterministicQrMatrix(
                            payload = link,
                            moduleColor = c2,
                            modifier = Modifier.size(216.dp)
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = cleanHandle.uppercase(),
                            color = c2,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.8.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = title,
                            color = Color(0xFF1F2933),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))
                Text(
                    text = subtitle,
                    color = Color.White.copy(alpha = 0.90f),
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(14.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    qrThemes.forEachIndexed { idx, pair ->
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(pair.first, pair.second)))
                                .border(
                                    width = if (idx == themeIdx) 2.5.dp else 1.dp,
                                    color = if (idx == themeIdx) Color.White else Color.White.copy(alpha = 0.5f),
                                    shape = CircleShape
                                )
                                .clickable { themeIdx = idx }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(22.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color.White.copy(alpha = 0.22f),
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("TelegramLink", link))
                                onShowToast("Ссылка $link скопирована")
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 12.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.ContentCopy, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Копировать", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color.White,
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                val share = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, "$title — $link")
                                }
                                runCatching {
                                    context.startActivity(Intent.createChooser(share, "Поделиться QR-ссылкой"))
                                }
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 12.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.Share, contentDescription = null, tint = c2, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Поделиться", color = c2, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DeterministicQrMatrix(
    payload: String,
    moduleColor: Color,
    modifier: Modifier = Modifier
) {
    val gridSize = 25
    val matrix = remember(payload) {
        val m = Array(gridSize) { BooleanArray(gridSize) }
        fun setFinder(ox: Int, oy: Int) {
            for (r in 0 until 7) {
                for (c in 0 until 7) {
                    val border = r == 0 || r == 6 || c == 0 || c == 6
                    val inner = r in 2..4 && c in 2..4
                    m[oy + r][ox + c] = border || inner
                }
            }
        }
        setFinder(0, 0)
        setFinder(gridSize - 7, 0)
        setFinder(0, gridSize - 7)
        var seed = payload.hashCode().toLong() * 6364136223846793005L + 1442695040888963407L
        for (r in 0 until gridSize) {
            for (c in 0 until gridSize) {
                val inFinder = (r < 8 && c < 8) || (r < 8 && c >= gridSize - 8) || (r >= gridSize - 8 && c < 8)
                val inCenterBadge = r in 10..14 && c in 10..14
                if (!inFinder && !inCenterBadge) {
                    seed = (seed * 1103515245L + 12345L)
                    m[r][c] = ((seed ushr 16) and 1L) == 1L
                }
            }
        }
        m
    }

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cell = size.minDimension / gridSize
            val dotRadius = cell * 0.42f
            for (r in 0 until gridSize) {
                for (c in 0 until gridSize) {
                    if (matrix[r][c]) {
                        drawRoundRect(
                            color = moduleColor,
                            topLeft = Offset(c * cell + cell * 0.08f, r * cell + cell * 0.08f),
                            size = Size(cell * 0.84f, cell * 0.84f),
                            cornerRadius = CornerRadius(dotRadius, dotRadius)
                        )
                    }
                }
            }
        }
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(moduleColor),
            contentAlignment = Alignment.Center
        ) {
            SvgPaperPlaneIcon(modifier = Modifier.size(22.dp), color = Color.White)
        }
    }
}

@Composable
fun TelegramCallOverlay(
    call: CallSessionState,
    onToggleMute: () -> Unit,
    onToggleSpeaker: () -> Unit,
    onEndCall: () -> Unit
) {
    val baseColor = Color(call.avatarColorHex)
    val pulseTransition = rememberInfiniteTransition(label = "callPulse")
    val pulseScale by pulseTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.24f,
        animationSpec = infiniteRepeatable(tween(1100), RepeatMode.Reverse),
        label = "pulseScale"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        baseColor.copy(alpha = 0.92f),
                        Color(0xFF15202B),
                        Color(0xFF0E1621)
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(24.dp)
    ) {
        Row(
            modifier = Modifier.align(Alignment.TopCenter),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (call.isVideo) Icons.Rounded.Videocam else Icons.Rounded.Lock,
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.8f),
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (call.isVideo) "Видеозвонок Fork Gram" else "Защищено сквозным шифрованием",
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
        }

        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(contentAlignment = Alignment.Center) {
                Box(
                    modifier = Modifier
                        .size(144.dp)
                        .scale(pulseScale)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.12f))
                )
                AvatarView(
                    title = call.peerName,
                    avatarUri = call.avatarUri,
                    colorHex = call.avatarColorHex,
                    size = 116.dp
                )
            }
            Spacer(modifier = Modifier.height(22.dp))
            Text(
                text = call.peerName,
                color = Color.White,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = call.statusLabel,
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium
            )
        }

        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(bottom = 18.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            CallControlButton(
                icon = Icons.Rounded.VolumeUp,
                label = "Динамик",
                active = call.isSpeaker,
                bgColor = if (call.isSpeaker) Color.White else Color.White.copy(alpha = 0.18f),
                tint = if (call.isSpeaker) Color(0xFF15202B) else Color.White,
                onClick = onToggleSpeaker
            )
            CallControlButton(
                icon = if (call.isMuted) Icons.Rounded.MicOff else Icons.Rounded.Mic,
                label = if (call.isMuted) "Без звука" else "Микрофон",
                active = call.isMuted,
                bgColor = if (call.isMuted) Color.White else Color.White.copy(alpha = 0.18f),
                tint = if (call.isMuted) Color(0xFF15202B) else Color.White,
                onClick = onToggleMute
            )
            CallControlButton(
                icon = Icons.Rounded.CallEnd,
                label = "Завершить",
                active = true,
                bgColor = Color(0xFFEB5757),
                tint = Color.White,
                onClick = onEndCall
            )
        }
    }
}

@Composable
private fun CallControlButton(
    icon: ImageVector,
    label: String,
    active: Boolean,
    bgColor: Color,
    tint: Color,
    onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(
            onClick = onClick,
            modifier = Modifier
                .size(62.dp)
                .clip(CircleShape)
                .background(bgColor)
        ) {
            Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(28.dp))
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(label, color = Color.White.copy(alpha = 0.88f), fontSize = 12.5.sp)
    }
}

