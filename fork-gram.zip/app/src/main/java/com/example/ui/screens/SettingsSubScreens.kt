package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CardGiftcard
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.Gavel
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Sell
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AppPreferencesState
import com.example.data.model.ChatFolder
import com.example.data.model.ChatThread
import com.example.data.model.ChatType
import com.example.data.model.DeviceSession
import com.example.data.model.FragmentNftGiftListing
import com.example.data.model.GiftKind
import com.example.data.model.NftUsernameItem
import com.example.data.model.UserAccount
import com.example.data.model.WalletTransaction
import com.example.data.model.WallpaperTheme
import com.example.data.repository.ForkGramRepository
import com.example.ui.components.GiftShopBottomSheet
import com.example.ui.components.TelegramChatBubbleShape
import com.example.ui.components.TelegramOutlinedField
import com.example.ui.svg.AnimatedTelegramGift
import com.example.ui.svg.SvgDoodleWallpaper
import com.example.ui.svg.SvgGramGemIcon
import com.example.ui.svg.SvgStarIcon
import com.example.ui.svg.TelegramGiftBackdropBox
import com.example.ui.theme.DangerRed
import com.example.ui.theme.GramCyan
import com.example.ui.theme.LocalForkPalette
import com.example.ui.theme.OnlineGreen
import com.example.ui.theme.PremiumViolet
import com.example.ui.theme.StarGold
import com.example.ui.theme.TgBlue
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsSubScreenRouter(
    destination: SettingsDestination,
    account: UserAccount?,
    prefs: AppPreferencesState,
    folders: List<ChatFolder>,
    chats: List<ChatThread> = emptyList(),
    nftUsernames: List<NftUsernameItem>,
    transactions: List<WalletTransaction>,
    onBack: () -> Unit,
    onNavigate: (SettingsDestination) -> Unit,
    onUpdateProfile: (String, String, String, String, String?, String?) -> Unit,
    onToggleNightMode: () -> Unit,
    onSetWallpaper: (WallpaperTheme) -> Unit,
    onSetTextSize: (Int) -> Unit,
    onSetAnimations: (Boolean) -> Unit,
    onSetPowerSaving: (Boolean) -> Unit,
    onSetNotifications: (Boolean) -> Unit,
    onSetShowOnline: (Boolean) -> Unit,
    onSetLanguage: (String) -> Unit,
    onSaveFolder: (String?, String, Set<ChatType>, Set<String>, Boolean) -> Unit,
    onDeleteFolder: (String) -> Unit,
    onTopUpStars: (Long) -> Unit,
    onTopUpGram: (Double) -> Unit,
    onSwapGramToStars: (Double) -> Unit,
    onBuyNftUsername: (String) -> Unit,
    onMintCustomNftUsername: (String) -> Unit,
    onToggleEquipNftUsername: (String) -> Unit,
    onSendGiftToSelf: (GiftKind, Boolean, String) -> Unit,
    onActivatePremium: (Boolean) -> Unit,
    deviceSessions: List<DeviceSession> = emptyList(),
    cacheSizeBytes: Long = 0L,
    fragmentGiftListings: List<FragmentNftGiftListing> = emptyList(),
    onSetAutoDownloadWifi: (Boolean) -> Unit = {},
    onSetAutoDownloadMobile: (Boolean) -> Unit = {},
    onClearCache: () -> Unit = {},
    onTerminateSession: (String) -> Unit = {},
    onBidNftUsername: (String, Double) -> Unit = { _, _ -> },
    onSellNftUsername: (String, String, Double) -> Unit = { _, _, _ -> },
    onCancelNftSale: (String) -> Unit = {},
    onBuyFragmentGift: (String) -> Unit = {},
    onSetPasscodePin: (String?) -> Unit = {}
) {
    BackHandler { onBack() }
    val palette = LocalForkPalette.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // Shared Top App Bar
        val title = when (destination) {
            SettingsDestination.ACCOUNT -> "Аккаунт"
            SettingsDestination.CHAT_APPEARANCE -> "Настройки чатов"
            SettingsDestination.PRIVACY -> "Конфиденциальность"
            SettingsDestination.NOTIFICATIONS -> "Уведомления"
            SettingsDestination.DATA_STORAGE -> "Данные и память"
            SettingsDestination.FOLDERS -> "Папки с чатами"
            SettingsDestination.DEVICES -> "Устройства"
            SettingsDestination.POWER_SAVING -> "Энергосбережение"
            SettingsDestination.LANGUAGE -> "Язык"
            SettingsDestination.PREMIUM -> "Fork Gram Premium"
            SettingsDestination.STARS_WALLET -> "Звёзды Fork Gram"
            SettingsDestination.GRAM_WALLET -> "Кошелёк Gram"
            SettingsDestination.NFT_USERNAMES -> "Fragment • NFT"
        }

        Surface(color = palette.surface, shadowElevation = 1.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Назад", tint = palette.textPrimary)
                }
                Text(
                    text = title,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = palette.textPrimary
                )
            }
        }

        when (destination) {
            SettingsDestination.STARS_WALLET -> StarsWalletContent(
                starsBalance = account?.starsBalance ?: 0L,
                transactions = transactions.filter { it.currency == "STARS" },
                onTopUpStars = onTopUpStars,
                onSendGift = onSendGiftToSelf
            )

            SettingsDestination.GRAM_WALLET -> GramWalletContent(
                gramBalance = account?.gramBalance ?: 0.0,
                transactions = transactions.filter { it.currency == "GRAM" },
                onTopUpGram = onTopUpGram,
                onSwapToStars = onSwapGramToStars,
                onOpenNftMarket = { onNavigate(SettingsDestination.NFT_USERNAMES) }
            )

            SettingsDestination.NFT_USERNAMES -> NftUsernamesContent(
                account = account,
                items = nftUsernames,
                giftListings = fragmentGiftListings,
                onBuyItem = onBuyNftUsername,
                onBidItem = onBidNftUsername,
                onMintCustom = onMintCustomNftUsername,
                onSellItem = onSellNftUsername,
                onCancelSale = onCancelNftSale,
                onToggleEquip = onToggleEquipNftUsername,
                onBuyGiftListing = onBuyFragmentGift
            )

            SettingsDestination.FOLDERS -> ChatFoldersContent(
                folders = folders,
                chats = chats,
                onSaveFolder = onSaveFolder,
                onDeleteFolder = onDeleteFolder
            )

            SettingsDestination.CHAT_APPEARANCE -> ChatAppearanceContent(
                prefs = prefs,
                onToggleNightMode = onToggleNightMode,
                onSetWallpaper = onSetWallpaper,
                onSetTextSize = onSetTextSize,
                onSetAnimations = onSetAnimations
            )

            SettingsDestination.ACCOUNT -> AccountEditContent(
                account = account,
                onSave = onUpdateProfile,
                onOpenNftMarket = { onNavigate(SettingsDestination.NFT_USERNAMES) }
            )

            SettingsDestination.PREMIUM -> PremiumContent(
                account = account,
                onActivate = onActivatePremium
            )

            SettingsDestination.PRIVACY -> PrivacySettingsContent(
                prefs = prefs,
                onSetShowOnline = onSetShowOnline,
                onSetPasscodePin = onSetPasscodePin
            )

            SettingsDestination.NOTIFICATIONS -> ToggleSettingsList(
                rows = listOf(
                    Triple("Уведомления в чатах", "Звук, всплывающие баннеры и счётчик", prefs.notificationsEnabled to onSetNotifications)
                )
            )

            SettingsDestination.POWER_SAVING -> ToggleSettingsList(
                rows = listOf(
                    Triple("Режим энергосбережения", "Отключение фоновых анимаций", prefs.powerSavingEnabled to onSetPowerSaving)
                )
            )

            SettingsDestination.DATA_STORAGE -> DataStorageContent(
                cacheSizeBytes = cacheSizeBytes,
                autoDownloadWifi = prefs.autoDownloadWifi,
                autoDownloadMobile = prefs.autoDownloadMobile,
                onSetAutoDownloadWifi = onSetAutoDownloadWifi,
                onSetAutoDownloadMobile = onSetAutoDownloadMobile,
                onClearCache = onClearCache
            )

            SettingsDestination.DEVICES -> DevicesSessionsContent(
                account = account,
                sessions = deviceSessions,
                onTerminateSession = onTerminateSession
            )

            SettingsDestination.LANGUAGE -> LanguagePickerContent(
                current = prefs.languageName,
                onSelect = onSetLanguage
            )
        }
    }
}

@Composable
private fun StarsWalletContent(
    starsBalance: Long,
    transactions: List<WalletTransaction>,
    onTopUpStars: (Long) -> Unit,
    onSendGift: (GiftKind, Boolean, String) -> Unit
) {
    val palette = LocalForkPalette.current
    var showGiftShop by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = Color.Transparent,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .background(Brush.linearGradient(listOf(Color(0xFFFFB838), Color(0xFFFF8C00))))
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    SvgStarIcon(modifier = Modifier.size(54.dp), color = Color.White)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Ваш баланс Звёзд", color = Color.White.copy(alpha = 0.9f), fontSize = 14.sp)
                    Text(
                        text = "$starsBalance",
                        color = Color.White,
                        fontSize = 36.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { showGiftShop = true },
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White)
                    ) {
                        Icon(Icons.Rounded.CardGiftcard, contentDescription = null, tint = Color(0xFFFF8C00))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Магазин подарков", color = Color(0xFFFF8C00), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Text(
                text = "Пополнить баланс",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = TgBlue,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(250L, 500L, 1000L, 2500L).forEach { pack ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = palette.surface,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onTopUpStars(pack) }
                            .testTag("topup_stars_$pack")
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            SvgStarIcon(modifier = Modifier.size(22.dp), color = StarGold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("+$pack", fontWeight = FontWeight.Bold, color = palette.textPrimary, fontSize = 13.5.sp)
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "История операций",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = TgBlue,
                modifier = Modifier.padding(top = 6.dp)
            )
        }

        items(transactions, key = { it.id }) { tx ->
            TransactionRowCard(tx)
        }
    }

    if (showGiftShop) {
        GiftShopBottomSheet(
            starsBalance = starsBalance,
            recipientName = "Себе в коллекцию",
            onDismiss = { showGiftShop = false },
            onSendGift = { kind, asNft, comment ->
                onSendGift(kind, asNft, comment)
                showGiftShop = false
            }
        )
    }
}

@Composable
private fun GramWalletContent(
    gramBalance: Double,
    transactions: List<WalletTransaction>,
    onTopUpGram: (Double) -> Unit,
    onSwapToStars: (Double) -> Unit,
    onOpenNftMarket: () -> Unit
) {
    val palette = LocalForkPalette.current
    var showSwapDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = Color.Transparent,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .background(Brush.linearGradient(listOf(Color(0xFF00A8F3), Color(0xFF0077C8))))
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    SvgGramGemIcon(modifier = Modifier.size(54.dp), color = Color.White)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Кошелёк Gram", color = Color.White.copy(alpha = 0.9f), fontSize = 14.sp)
                    Text(
                        text = "${ForkGramRepository.formatGram(gramBalance)} GRAM",
                        color = Color.White,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { showSwapDialog = true },
                            shape = RoundedCornerShape(18.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White)
                        ) {
                            Icon(Icons.Rounded.SwapHoriz, contentDescription = null, tint = GramCyan)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("В Звёзды", color = GramCyan, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = onOpenNftMarket,
                            shape = RoundedCornerShape(18.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.2f))
                        ) {
                            Text("NFT-имена", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "Пополнить Gram",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = TgBlue
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(10.0, 25.0, 50.0, 100.0).forEach { amt ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = palette.surface,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onTopUpGram(amt) }
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            SvgGramGemIcon(modifier = Modifier.size(20.dp), color = GramCyan)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("+${amt.toInt()}", fontWeight = FontWeight.Bold, color = palette.textPrimary)
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "Транзакции Gram",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = TgBlue,
                modifier = Modifier.padding(top = 6.dp)
            )
        }

        items(transactions, key = { it.id }) { tx ->
            TransactionRowCard(tx)
        }
    }

    if (showSwapDialog) {
        var amountStr by remember { mutableStateOf("5.0") }
        AlertDialog(
            onDismissRequest = { showSwapDialog = false },
            containerColor = palette.surface,
            shape = RoundedCornerShape(24.dp),
            title = { Text("Обмен GRAM на Звёзды", fontWeight = FontWeight.Bold, color = palette.textPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Курс: 1 GRAM = 100 Звёзд", color = palette.textSecondary, fontSize = 13.5.sp)
                    TelegramOutlinedField(
                        value = amountStr,
                        onValueChange = { amountStr = it },
                        label = "Сколько GRAM обменять"
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = amountStr.replace(",", ".").toDoubleOrNull() ?: 0.0
                        if (amt > 0.0) onSwapToStars(amt)
                        showSwapDialog = false
                    },
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = GramCyan)
                ) {
                    Text("Обменять", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSwapDialog = false }) { Text("Отмена", color = palette.textSecondary) }
            }
        )
    }
}

@Composable
private fun NftUsernamesContent(
    account: UserAccount?,
    items: List<NftUsernameItem>,
    giftListings: List<FragmentNftGiftListing>,
    onBuyItem: (String) -> Unit,
    onBidItem: (String, Double) -> Unit,
    onMintCustom: (String) -> Unit,
    onSellItem: (String, String, Double) -> Unit,
    onCancelSale: (String) -> Unit,
    onToggleEquip: (String) -> Unit,
    onBuyGiftListing: (String) -> Unit
) {
    val palette = LocalForkPalette.current
    val uriHandler = LocalUriHandler.current
    var customHandle by remember { mutableStateOf("") }
    var selectedTab by remember { mutableIntStateOf(0) } // 0=Все, 1=Аукционы, 2=Мои NFT, 3=NFT-подарки
    var bidTarget by remember { mutableStateOf<NftUsernameItem?>(null) }
    var sellTarget by remember { mutableStateOf<NftUsernameItem?>(null) }
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1000L)
            nowMs = System.currentTimeMillis()
        }
    }

    val owned = items.filter { it.isOwned }
    val auctions = items.filter { it.status == "AUCTION" || it.status == "LISTED_AUCTION" }
    val market = items.filter { !it.isOwned || it.status == "LISTED_SALE" || it.status == "LISTED_AUCTION" }

    val displayedUsernames = when (selectedTab) {
        1 -> auctions
        2 -> owned
        else -> market
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Own Fragment Dark Hero Card
        item {
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = Color.Transparent,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .background(Brush.linearGradient(listOf(Color(0xFF141D28), Color(0xFF1C2C3F))))
                        .padding(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(GramCyan.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                SvgGramGemIcon(modifier = Modifier.size(22.dp), color = GramCyan)
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "FORK FRAGMENT",
                                    color = Color.White,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.sp,
                                    letterSpacing = 0.6.sp
                                )
                                Text(
                                    text = "forkgram.xsph.ru/fragment",
                                    color = GramCyan,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Color.White.copy(alpha = 0.12f),
                            modifier = Modifier.clickable {
                                runCatching { uriHandler.openUri("http://forkgram.xsph.ru/fragment") }
                            }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Открыть", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(Icons.Rounded.OpenInNew, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Активное имя", fontSize = 11.5.sp, color = Color.White.copy(alpha = 0.65f))
                            Text(
                                text = account?.displayHandle ?: "@forkgram",
                                fontSize = 19.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (account?.activeNftUsername != null) GramCyan else Color.White
                            )
                        }
                        Surface(shape = RoundedCornerShape(14.dp), color = GramCyan.copy(alpha = 0.22f)) {
                            Text(
                                text = "${ForkGramRepository.formatGram(account?.gramBalance ?: 0.0)} GRAM",
                                color = Color(0xFF7CE8FF),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.5.sp,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        // Custom Handle Mint Card
        item {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = palette.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Выпустить NFT-юзернейм на Fragment", fontWeight = FontWeight.SemiBold, color = palette.textPrimary, fontSize = 14.5.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TelegramOutlinedField(
                            value = customHandle,
                            onValueChange = { customHandle = it },
                            label = "Уникальный @handle",
                            placeholder = "@legend",
                            modifier = Modifier
                                .weight(1f)
                                .testTag("nft_custom_handle_input")
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                onMintCustom(customHandle)
                                customHandle = ""
                            },
                            enabled = customHandle.trim().removePrefix("@").length >= 3,
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = GramCyan),
                            modifier = Modifier.height(54.dp)
                        ) {
                            Text("Минт", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text(
                        text = "Глобальная регистрация • 3–4 символа: 18 GRAM • 5+ символов: 6 GRAM",
                        fontSize = 11.5.sp,
                        color = palette.textSecondary,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }
        }

        // Filter Chips Row
        item {
            val tabs = listOf(
                "Все (${market.size})",
                "Аукционы (${auctions.size})",
                "Мои NFT (${owned.size})",
                "Подарки (${giftListings.size})"
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                tabs.forEachIndexed { idx, label ->
                    val selected = selectedTab == idx
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = if (selected) TgBlue else palette.surface,
                        border = if (selected) null else BorderStroke(0.8.dp, palette.divider),
                        modifier = Modifier
                            .clickable { selectedTab = idx }
                            .testTag("fragment_tab_$idx")
                    ) {
                        Text(
                            text = label,
                            color = if (selected) Color.White else palette.textPrimary,
                            fontSize = 13.sp,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }

        if (selectedTab == 3) {
            if (giftListings.isEmpty()) {
                item {
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = palette.surface,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            SvgGramGemIcon(modifier = Modifier.size(34.dp), color = GramCyan)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("На Fragment пока нет NFT-подарков на продаже", color = palette.textPrimary, fontWeight = FontWeight.SemiBold)
                            Text(
                                text = "Вы можете выставить любой свой NFT-подарок прямо из окна подарка в профиле.",
                                fontSize = 12.5.sp,
                                color = palette.textSecondary
                            )
                        }
                    }
                }
            } else {
                items(giftListings, key = { it.id }) { listing ->
                    val gift = listing.gift
                    val isMine = listing.sellerEmail.equals(account?.email, ignoreCase = true)
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = palette.surface,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TelegramGiftBackdropBox(
                                backdrop = gift.backdrop,
                                symbol = gift.symbol,
                                showShimmer = true,
                                modifier = Modifier
                                    .size(92.dp)
                                    .clip(RoundedCornerShape(16.dp))
                            ) {
                                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    AnimatedTelegramGift(
                                        giftKind = gift.giftKind,
                                        animate = true,
                                        editionNumber = gift.editionNumber,
                                        useRemoteEdition = true,
                                        modifier = Modifier.size(76.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(
                                    text = "${gift.giftKind.title} #${gift.editionNumber}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = palette.textPrimary
                                )
                                Text(
                                    text = "${gift.modelName} (${gift.modelRarity}) • ${gift.backdrop.title}",
                                    fontSize = 12.sp,
                                    color = palette.textSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "Продавец: ${listing.sellerName}",
                                    fontSize = 12.sp,
                                    color = palette.textSecondary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        onClick = {
                                            runCatching { uriHandler.openUri(gift.forkGramNftUrl) }
                                        },
                                        shape = RoundedCornerShape(12.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text("NFT ↗", fontSize = 12.sp)
                                    }
                                    if (!isMine) {
                                        Button(
                                            onClick = { onBuyGiftListing(listing.id) },
                                            enabled = (account?.gramBalance ?: 0.0) >= listing.priceGram,
                                            shape = RoundedCornerShape(12.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = GramCyan),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                        ) {
                                            Text(
                                                "${ForkGramRepository.formatGram(listing.priceGram)} GRAM",
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.5.sp
                                            )
                                        }
                                    } else {
                                        Surface(
                                            shape = RoundedCornerShape(10.dp),
                                            color = TgBlue.copy(alpha = 0.14f)
                                        ) {
                                            Text(
                                                "Ваш лот",
                                                color = TgBlue,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            items(displayedUsernames, key = { it.id }) { nft ->
                val isAuction = nft.status == "AUCTION" || nft.status == "LISTED_AUCTION"
                val isListed = nft.status == "LISTED_SALE" || nft.status == "LISTED_AUCTION"
                val statusLabel = when (nft.status) {
                    "AUCTION" -> "АУКЦИОН"
                    "LISTED_AUCTION" -> "ВАШ АУКЦИОН"
                    "LISTED_SALE" -> "НА ПРОДАЖЕ"
                    "OWNED" -> "ВАШ NFT"
                    else -> "ФИКС. ЦЕНА"
                }
                val statusColor = when (nft.status) {
                    "AUCTION", "LISTED_AUCTION" -> StarGold
                    "OWNED" -> OnlineGreen
                    "LISTED_SALE" -> PremiumViolet
                    else -> GramCyan
                }
                val remainingSec = nft.endsAt?.let { ((it - nowMs) / 1000L).coerceAtLeast(0L) }
                val countdownText = remainingSec?.let { sec ->
                    val h = sec / 3600
                    val m = (sec % 3600) / 60
                    val s = sec % 60
                    if (h > 0) "${h}ч ${m}м ${s}с" else "${m}м ${s}с"
                }

                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = palette.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(statusColor.copy(alpha = 0.14f)),
                                contentAlignment = Alignment.Center
                            ) {
                                SvgGramGemIcon(modifier = Modifier.size(22.dp), color = statusColor)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(
                                        text = nft.handle,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 17.sp,
                                        color = palette.textPrimary
                                    )
                                    Surface(shape = RoundedCornerShape(8.dp), color = statusColor.copy(alpha = 0.16f)) {
                                        Text(
                                            text = statusLabel,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = statusColor,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                val sub = buildString {
                                    append(nft.rarityTier)
                                    append(" • ")
                                    append(nft.ownerName)
                                    if (countdownText != null && isAuction) {
                                        append(" • ⏳ $countdownText")
                                    }
                                }
                                Text(sub, fontSize = 12.sp, color = palette.textSecondary)
                                if (isAuction) {
                                    val bidLine = if (nft.topBidGram > 0.0) {
                                        "Топ ставка: ${ForkGramRepository.formatGram(nft.topBidGram)} GRAM (${nft.bidsCount}) • ${nft.topBidderName ?: "—"}"
                                    } else {
                                        "Мин. ставка: ${ForkGramRepository.formatGram(nft.minBidGram)} GRAM"
                                    }
                                    Text(
                                        text = if (nft.isHighestBidder) "$bidLine • Ваша ставка лидирует" else bidLine,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (nft.isHighestBidder) OnlineGreen else TgBlue
                                    )
                                }
                            }
                            IconButton(
                                onClick = { runCatching { uriHandler.openUri(nft.fragmentUrl) } },
                                modifier = Modifier.size(34.dp)
                            ) {
                                Icon(Icons.Rounded.OpenInNew, contentDescription = "Открыть на Fragment", tint = palette.textSecondary, modifier = Modifier.size(18.dp))
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (nft.isOwned) {
                                if (nft.isEquipped) {
                                    OutlinedButton(
                                        onClick = { onToggleEquip(nft.id) },
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Снять")
                                    }
                                } else {
                                    Button(
                                        onClick = { onToggleEquip(nft.id) },
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = TgBlue),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Надеть", color = Color.White)
                                    }
                                }
                                if (isListed) {
                                    OutlinedButton(
                                        onClick = { onCancelSale(nft.id) },
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Снять с продажи", maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                } else {
                                    OutlinedButton(
                                        onClick = { sellTarget = nft },
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Rounded.Sell, contentDescription = null, modifier = Modifier.size(15.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Продать")
                                    }
                                }
                            } else {
                                if (isAuction) {
                                    OutlinedButton(
                                        onClick = { bidTarget = nft },
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Rounded.Gavel, contentDescription = null, modifier = Modifier.size(15.dp))
                                        Spacer(modifier = Modifier.width(5.dp))
                                        Text("Ставка ${ForkGramRepository.formatGram(nft.minBidGram)}+")
                                    }
                                }
                                Button(
                                    onClick = { onBuyItem(nft.id) },
                                    enabled = (account?.gramBalance ?: 0.0) >= nft.priceGram,
                                    colors = ButtonDefaults.buttonColors(containerColor = GramCyan),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(
                                        text = if (isAuction) "Блиц ${ForkGramRepository.formatGram(nft.priceGram)}" else "Купить ${ForkGramRepository.formatGram(nft.priceGram)}",
                                        color = Color.White,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Bid Dialog
    bidTarget?.let { nft ->
        var bidStr by remember(nft) { mutableStateOf(ForkGramRepository.formatGram(nft.minBidGram)) }
        AlertDialog(
            onDismissRequest = { bidTarget = null },
            containerColor = palette.surface,
            shape = RoundedCornerShape(24.dp),
            title = { Text("Ставка на ${nft.handle}", fontWeight = FontWeight.Bold, color = palette.textPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Минимальная ставка: ${ForkGramRepository.formatGram(nft.minBidGram)} GRAM",
                        fontSize = 13.sp,
                        color = TgBlue
                    )
                    TelegramOutlinedField(
                        value = bidStr,
                        onValueChange = { bidStr = it },
                        label = "Ваша ставка (GRAM)"
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = bidStr.replace(",", ".").toDoubleOrNull() ?: 0.0
                        if (amt >= nft.minBidGram) {
                            onBidItem(nft.id, amt)
                            bidTarget = null
                        }
                    },
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = GramCyan)
                ) {
                    Text("Сделать ставку", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { bidTarget = null }) { Text("Отмена", color = palette.textSecondary) }
            }
        )
    }

    // Sell / Auction Dialog
    sellTarget?.let { nft ->
        var priceStr by remember(nft) { mutableStateOf(ForkGramRepository.formatGram(nft.priceGram.coerceAtLeast(10.0))) }
        var mode by remember(nft) { mutableStateOf("sale") }
        AlertDialog(
            onDismissRequest = { sellTarget = null },
            containerColor = palette.surface,
            shape = RoundedCornerShape(24.dp),
            title = { Text("Выставить ${nft.handle}", fontWeight = FontWeight.Bold, color = palette.textPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (mode == "sale") TgBlue else palette.surfaceVariant,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { mode = "sale" }
                        ) {
                            Text(
                                "Фикс. цена",
                                color = if (mode == "sale") Color.White else palette.textPrimary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp,
                                modifier = Modifier.padding(vertical = 10.dp, horizontal = 12.dp)
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (mode == "auction") TgBlue else palette.surfaceVariant,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { mode = "auction" }
                        ) {
                            Text(
                                "Аукцион",
                                color = if (mode == "auction") Color.White else palette.textPrimary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp,
                                modifier = Modifier.padding(vertical = 10.dp, horizontal = 12.dp)
                            )
                        }
                    }
                    TelegramOutlinedField(
                        value = priceStr,
                        onValueChange = { priceStr = it },
                        label = if (mode == "auction") "Стартовая цена (GRAM)" else "Цена продажи (GRAM)"
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = priceStr.replace(",", ".").toDoubleOrNull() ?: 0.0
                        if (amt > 0.0) {
                            onSellItem(nft.id, mode, amt)
                            sellTarget = null
                        }
                    },
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = GramCyan)
                ) {
                    Text("Опубликовать", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { sellTarget = null }) { Text("Отмена", color = palette.textSecondary) }
            }
        )
    }
}

@Composable
private fun PrivacySettingsContent(
    prefs: AppPreferencesState,
    onSetShowOnline: (Boolean) -> Unit,
    onSetPasscodePin: (String?) -> Unit
) {
    val palette = LocalForkPalette.current
    var showPinDialog by remember { mutableStateOf(false) }
    var pinInput by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Surface(shape = RoundedCornerShape(18.dp), color = palette.surface, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Приватность", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TgBlue)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Показывать время захода", fontWeight = FontWeight.Medium, color = palette.textPrimary)
                        Text("Видимость статуса «в сети»", fontSize = 12.5.sp, color = palette.textSecondary)
                    }
                    Switch(
                        checked = prefs.showOnlineStatus,
                        onCheckedChange = onSetShowOnline,
                        colors = SwitchDefaults.colors(checkedTrackColor = TgBlue)
                    )
                }
            }
        }

        Surface(shape = RoundedCornerShape(18.dp), color = palette.surface, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Безопасность", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TgBlue)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(TgBlue.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.Lock, contentDescription = null, tint = TgBlue, modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Код-пароль", fontWeight = FontWeight.Medium, color = palette.textPrimary)
                        Text(
                            text = if (prefs.passcodePin.isNullOrBlank()) "Выключен" else "Включён (4 цифры)",
                            fontSize = 12.5.sp,
                            color = if (prefs.passcodePin.isNullOrBlank()) palette.textSecondary else OnlineGreen
                        )
                    }
                    Switch(
                        checked = !prefs.passcodePin.isNullOrBlank(),
                        onCheckedChange = { enabled ->
                            if (enabled) {
                                pinInput = ""
                                pinError = null
                                showPinDialog = true
                            } else {
                                onSetPasscodePin(null)
                            }
                        },
                        colors = SwitchDefaults.colors(checkedTrackColor = TgBlue),
                        modifier = Modifier.testTag("passcode_switch")
                    )
                }
                if (!prefs.passcodePin.isNullOrBlank()) {
                    OutlinedButton(
                        onClick = {
                            pinInput = ""
                            pinError = null
                            showPinDialog = true
                        },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Сменить код-пароль")
                    }
                }
            }
        }
    }

    if (showPinDialog) {
        AlertDialog(
            onDismissRequest = { showPinDialog = false },
            containerColor = palette.surface,
            shape = RoundedCornerShape(24.dp),
            title = { Text("Установить код-пароль", fontWeight = FontWeight.Bold, color = palette.textPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Введите 4-значный PIN-код для блокировки приложения при запуске.",
                        fontSize = 13.sp,
                        color = palette.textSecondary
                    )
                    TelegramOutlinedField(
                        value = pinInput,
                        onValueChange = { raw ->
                            pinInput = raw.filter { it.isDigit() }.take(4)
                            pinError = null
                        },
                        label = "4 цифры",
                        placeholder = "1234"
                    )
                    if (pinError != null) {
                        Text(pinError!!, color = DangerRed, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (pinInput.length == 4) {
                            onSetPasscodePin(pinInput)
                            showPinDialog = false
                        } else {
                            pinError = "Введите ровно 4 цифры"
                        }
                    },
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TgBlue)
                ) {
                    Text("Сохранить", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPinDialog = false }) { Text("Отмена", color = palette.textSecondary) }
            }
        )
    }
}

@Composable
private fun ChatFoldersContent(
    folders: List<ChatFolder>,
    chats: List<ChatThread>,
    onSaveFolder: (String?, String, Set<ChatType>, Set<String>, Boolean) -> Unit,
    onDeleteFolder: (String) -> Unit
) {
    val palette = LocalForkPalette.current
    var showEditor by remember { mutableStateOf(false) }
    var editingFolder by remember { mutableStateOf<ChatFolder?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Button(
                onClick = {
                    editingFolder = null
                    showEditor = true
                },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = TgBlue),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("create_folder_button")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Создать новую папку", color = Color.White, fontWeight = FontWeight.SemiBold)
            }
        }

        val hasPersonal = folders.any { it.name.equals("Личные", ignoreCase = true) }
        val hasUnread = folders.any { it.name.equals("Непрочитанные", ignoreCase = true) }
        if (!hasPersonal || !hasUnread) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Рекомендуемые папки",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TgBlue,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (!hasPersonal) {
                            OutlinedButton(
                                onClick = {
                                    onSaveFolder(null, "Личные", setOf(ChatType.DIRECT, ChatType.SECRET), emptySet(), false)
                                },
                                shape = RoundedCornerShape(18.dp)
                            ) {
                                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Личные")
                            }
                        }
                        if (!hasUnread) {
                            OutlinedButton(
                                onClick = {
                                    onSaveFolder(null, "Непрочитанные", setOf(ChatType.DIRECT, ChatType.GROUP, ChatType.CHANNEL), emptySet(), true)
                                },
                                shape = RoundedCornerShape(18.dp)
                            ) {
                                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Непрочитанные")
                            }
                        }
                    }
                }
            }
        }

        items(folders, key = { it.id }) { folder ->
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = palette.surface,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        editingFolder = folder
                        showEditor = true
                    }
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(folder.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, color = palette.textPrimary)
                        val typesDesc = folder.includeTypes.joinToString(", ") {
                            when (it) {
                                ChatType.DIRECT -> "Личные"
                                ChatType.GROUP -> "Группы"
                                ChatType.CHANNEL -> "Каналы"
                                ChatType.SECRET -> "Секретные"
                                else -> "Прочие"
                            }
                        }.ifBlank { "Выбранные чаты" }
                        val extraChats = if (folder.includedChatIds.isNotEmpty()) {
                            " • +${folder.includedChatIds.size} чатов"
                        } else {
                            ""
                        }
                        Text("$typesDesc$extraChats", fontSize = 12.5.sp, color = palette.textSecondary)
                    }
                    IconButton(onClick = { onDeleteFolder(folder.id) }) {
                        Icon(Icons.Outlined.DeleteOutline, contentDescription = "Удалить", tint = DangerRed)
                    }
                }
            }
        }
    }

    if (showEditor) {
        var name by remember(editingFolder) { mutableStateOf(editingFolder?.name ?: "") }
        var includeDirect by remember(editingFolder) {
            mutableStateOf(editingFolder?.includeTypes?.contains(ChatType.DIRECT) ?: true)
        }
        var includeGroups by remember(editingFolder) {
            mutableStateOf(editingFolder?.includeTypes?.contains(ChatType.GROUP) ?: false)
        }
        var includeChannels by remember(editingFolder) {
            mutableStateOf(editingFolder?.includeTypes?.contains(ChatType.CHANNEL) ?: false)
        }
        var onlyUnread by remember(editingFolder) { mutableStateOf(editingFolder?.onlyUnread ?: false) }
        var includedChatIds by remember(editingFolder) {
            mutableStateOf(editingFolder?.includedChatIds ?: emptySet())
        }

        AlertDialog(
            onDismissRequest = { showEditor = false },
            containerColor = palette.surface,
            shape = RoundedCornerShape(24.dp),
            title = {
                Text(
                    if (editingFolder == null) "Новая папка" else "Редактировать папку",
                    fontWeight = FontWeight.Bold,
                    color = palette.textPrimary
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    TelegramOutlinedField(
                        value = name,
                        onValueChange = { name = it },
                        label = "Название папки"
                    )
                    FolderCheckRow("Личные чаты", includeDirect) { includeDirect = it }
                    FolderCheckRow("Группы", includeGroups) { includeGroups = it }
                    FolderCheckRow("Каналы", includeChannels) { includeChannels = it }
                    FolderCheckRow("Только непрочитанные", onlyUnread) { onlyUnread = it }

                    if (chats.isNotEmpty()) {
                        Text(
                            text = "Включить конкретные чаты",
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TgBlue,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 150.dp)
                        ) {
                            items(chats, key = { it.id }) { chat ->
                                val isChecked = chat.id in includedChatIds
                                FolderCheckRow(chat.title, isChecked) { checked ->
                                    includedChatIds = if (checked) {
                                        includedChatIds + chat.id
                                    } else {
                                        includedChatIds - chat.id
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val types = buildSet {
                            if (includeDirect) {
                                add(ChatType.DIRECT)
                                add(ChatType.SECRET)
                            }
                            if (includeGroups) add(ChatType.GROUP)
                            if (includeChannels) add(ChatType.CHANNEL)
                        }
                        onSaveFolder(editingFolder?.id, name, types, includedChatIds, onlyUnread)
                        showEditor = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TgBlue)
                ) {
                    Text("Сохранить", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditor = false }) { Text("Отмена", color = palette.textSecondary) }
            }
        )
    }
}

@Composable
private fun FolderCheckRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val palette = LocalForkPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onChange(!checked) },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = checked,
            onCheckedChange = onChange,
            colors = CheckboxDefaults.colors(checkedColor = TgBlue)
        )
        Text(label, color = palette.textPrimary, fontSize = 14.sp)
    }
}

@Composable
private fun ChatAppearanceContent(
    prefs: AppPreferencesState,
    onToggleNightMode: () -> Unit,
    onSetWallpaper: (WallpaperTheme) -> Unit,
    onSetTextSize: (Int) -> Unit,
    onSetAnimations: (Boolean) -> Unit
) {
    val palette = LocalForkPalette.current
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = palette.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(176.dp)
                        .clip(RoundedCornerShape(20.dp))
                ) {
                    SvgDoodleWallpaper(
                        theme = prefs.wallpaperTheme,
                        isDark = prefs.isDarkTheme,
                        modifier = Modifier.fillMaxSize()
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 14.dp, vertical = 14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterVertically)
                    ) {
                        Surface(
                            shape = TelegramChatBubbleShape(isOutgoing = false, hasTail = true, isFirstInGroup = true),
                            color = palette.bubbleIncoming,
                            shadowElevation = 1.dp,
                            modifier = Modifier.align(Alignment.Start)
                        ) {
                            Column(modifier = Modifier.padding(start = 16.dp, end = 12.dp, top = 8.dp, bottom = 7.dp)) {
                                Text(
                                    text = "Привет! Как смотрится новый размер шрифта?",
                                    color = palette.textPrimary,
                                    fontSize = prefs.chatTextSizeSp.sp,
                                    lineHeight = (prefs.chatTextSizeSp + 5).sp
                                )
                                Text(
                                    text = "12:40",
                                    color = palette.textSecondary,
                                    fontSize = 10.5.sp,
                                    modifier = Modifier.align(Alignment.End)
                                )
                            }
                        }

                        Surface(
                            shape = TelegramChatBubbleShape(isOutgoing = true, hasTail = true, isFirstInGroup = true),
                            color = palette.bubbleOutgoing,
                            shadowElevation = 1.dp,
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Column(modifier = Modifier.padding(start = 12.dp, end = 16.dp, top = 8.dp, bottom = 7.dp)) {
                                Text(
                                    text = "Идеально, 1 в 1 как в Telegram!",
                                    color = palette.textPrimary,
                                    fontSize = prefs.chatTextSizeSp.sp,
                                    lineHeight = (prefs.chatTextSizeSp + 5).sp
                                )
                                Row(
                                    modifier = Modifier.align(Alignment.End),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Text(
                                        text = "12:41",
                                        color = palette.bubbleOutgoingMeta,
                                        fontSize = 10.5.sp
                                    )
                                    Icon(
                                        imageVector = Icons.Rounded.DoneAll,
                                        contentDescription = null,
                                        tint = TgBlue,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Surface(shape = RoundedCornerShape(18.dp), color = palette.surface, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Ночной режим", fontWeight = FontWeight.Medium, color = palette.textPrimary)
                        Switch(
                            checked = prefs.isDarkTheme,
                            onCheckedChange = { onToggleNightMode() },
                            colors = SwitchDefaults.colors(checkedTrackColor = TgBlue)
                        )
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Плавные анимации", fontWeight = FontWeight.Medium, color = palette.textPrimary)
                        Switch(
                            checked = prefs.animationsEnabled,
                            onCheckedChange = onSetAnimations,
                            colors = SwitchDefaults.colors(checkedTrackColor = TgBlue)
                        )
                    }
                    Column {
                        Text("Размер текста сообщений: ${prefs.chatTextSizeSp} sp", color = palette.textPrimary, fontWeight = FontWeight.Medium)
                        Slider(
                            value = prefs.chatTextSizeSp.toFloat(),
                            onValueChange = { onSetTextSize(it.toInt()) },
                            valueRange = 12f..20f,
                            colors = SliderDefaults.colors(thumbColor = TgBlue, activeTrackColor = TgBlue)
                        )
                    }
                }
            }
        }

        item {
            Text("Обои чатов", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = TgBlue)
            Spacer(modifier = Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                WallpaperTheme.entries.forEach { theme ->
                    val selected = prefs.wallpaperTheme == theme
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = palette.surface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .then(if (selected) Modifier.border(2.dp, TgBlue, RoundedCornerShape(14.dp)) else Modifier)
                            .clickable { onSetWallpaper(theme) }
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                ) {
                                    SvgDoodleWallpaper(
                                        theme = theme,
                                        isDark = theme == WallpaperTheme.MIDNIGHT_DARK
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(theme.title, color = palette.textPrimary, fontWeight = FontWeight.Medium)
                            }
                            if (selected) Icon(Icons.Rounded.Check, contentDescription = null, tint = TgBlue)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AccountEditContent(
    account: UserAccount?,
    onSave: (String, String, String, String, String?, String?) -> Unit,
    onOpenNftMarket: () -> Unit
) {
    val palette = LocalForkPalette.current
    var first by remember(account) { mutableStateOf(account?.firstName ?: "") }
    var last by remember(account) { mutableStateOf(account?.lastName ?: "") }
    var username by remember(account) { mutableStateOf(account?.username ?: "") }
    var bio by remember(account) { mutableStateOf(account?.bio ?: "") }
    var birthday by remember(account) { mutableStateOf(account?.birthday ?: "") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Surface(shape = RoundedCornerShape(22.dp), color = palette.surface, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Почта аккаунта: ${account?.email ?: ""}", color = TgBlue, fontWeight = FontWeight.SemiBold)
                TelegramOutlinedField(value = first, onValueChange = { first = it }, label = "Имя")
                TelegramOutlinedField(value = last, onValueChange = { last = it }, label = "Фамилия")
                TelegramOutlinedField(value = username, onValueChange = { username = it }, label = "Базовый @username")
                TelegramOutlinedField(value = bio, onValueChange = { bio = it }, label = "О себе", singleLine = false, maxLines = 3)
                TelegramOutlinedField(value = birthday, onValueChange = { birthday = it }, label = "День рождения", placeholder = "14 мая")
                Button(
                    onClick = { onSave(first, last, username, bio, birthday, null) },
                    colors = ButtonDefaults.buttonColors(containerColor = TgBlue),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Text("Сохранить изменения", color = Color.White, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        OutlinedButton(
            onClick = onOpenNftMarket,
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            SvgGramGemIcon(modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Открыть NFT-юзернеймы")
        }
    }
}

@Composable
private fun PremiumContent(account: UserAccount?, onActivate: (Boolean) -> Unit) {
    val palette = LocalForkPalette.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = Color.Transparent,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .background(Brush.linearGradient(listOf(PremiumViolet, TgBlue)))
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                SvgStarIcon(modifier = Modifier.size(56.dp), color = Color.White)
                Spacer(modifier = Modifier.height(10.dp))
                Text("Fork Gram Premium", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = if (account?.isPremium == true) "Статус Premium активен для вашего аккаунта" else "Откройте эксклюзивные SVG-статусы, значок звезды и приоритетные лимиты",
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 14.sp
                )
            }
        }
        if (account?.isPremium != true) {
            Button(
                onClick = { onActivate(false) },
                colors = ButtonDefaults.buttonColors(containerColor = StarGold),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Text("Подключить за 350 Звёзд", color = Color.White, fontWeight = FontWeight.Bold)
            }
            Button(
                onClick = { onActivate(true) },
                colors = ButtonDefaults.buttonColors(containerColor = GramCyan),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Text("Подключить за 3.50 GRAM", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ToggleSettingsList(rows: List<Triple<String, String, Pair<Boolean, (Boolean) -> Unit>>>) {
    val palette = LocalForkPalette.current
    Column(modifier = Modifier.padding(16.dp)) {
        Surface(shape = RoundedCornerShape(18.dp), color = palette.surface, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                rows.forEach { (title, sub, statePair) ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(title, fontWeight = FontWeight.Medium, color = palette.textPrimary)
                            Text(sub, fontSize = 12.5.sp, color = palette.textSecondary)
                        }
                        Switch(
                            checked = statePair.first,
                            onCheckedChange = statePair.second,
                            colors = SwitchDefaults.colors(checkedTrackColor = TgBlue)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DataStorageContent(
    cacheSizeBytes: Long,
    autoDownloadWifi: Boolean,
    autoDownloadMobile: Boolean,
    onSetAutoDownloadWifi: (Boolean) -> Unit,
    onSetAutoDownloadMobile: (Boolean) -> Unit,
    onClearCache: () -> Unit
) {
    val palette = LocalForkPalette.current
    val formattedSize = remember(cacheSizeBytes) {
        when {
            cacheSizeBytes < 1024L -> "$cacheSizeBytes Б"
            cacheSizeBytes < 1024L * 1024L -> "${(cacheSizeBytes / 1024.0).let { "%.1f".format(it) }} КБ"
            else -> "${(cacheSizeBytes / (1024.0 * 1024.0)).let { "%.2f".format(it) }} МБ"
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = palette.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Использование памяти",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TgBlue
                    )
                    Text(
                        text = formattedSize,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary
                    )
                    Text(
                        text = "Локальные кэшированные фото, голосовые и медиафайлы",
                        fontSize = 13.sp,
                        color = palette.textSecondary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Button(
                        onClick = onClearCache,
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = TgBlue),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("clear_cache_button")
                    ) {
                        Icon(Icons.Rounded.CleaningServices, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Очистить кэш", color = Color.White, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = palette.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Автозагрузка медиа",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TgBlue
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Через Wi-Fi", fontWeight = FontWeight.Medium, color = palette.textPrimary)
                            Text("Фото, голосовые и стикеры загружаются автоматически", fontSize = 12.sp, color = palette.textSecondary)
                        }
                        Switch(
                            checked = autoDownloadWifi,
                            onCheckedChange = onSetAutoDownloadWifi,
                            colors = SwitchDefaults.colors(checkedTrackColor = TgBlue)
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Через мобильную сеть", fontWeight = FontWeight.Medium, color = palette.textPrimary)
                            Text("Экономная загрузка фото и голосовых в дороге", fontSize = 12.sp, color = palette.textSecondary)
                        }
                        Switch(
                            checked = autoDownloadMobile,
                            onCheckedChange = onSetAutoDownloadMobile,
                            colors = SwitchDefaults.colors(checkedTrackColor = TgBlue)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DevicesSessionsContent(
    account: UserAccount?,
    sessions: List<DeviceSession>,
    onTerminateSession: (String) -> Unit
) {
    val palette = LocalForkPalette.current
    val currentSession = sessions.firstOrNull { it.isCurrent }
    val otherSessions = sessions.filter { !it.isCurrent }
    val dateFormat = remember { SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Это устройство", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TgBlue)
        }
        item {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = palette.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(TgBlue.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.Devices, contentDescription = null, tint = TgBlue)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = currentSession?.deviceName ?: "Android Fork Gram",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.5.sp,
                            color = palette.textPrimary
                        )
                        Text(
                            text = "${currentSession?.platform ?: "Fork Gram Android 11"} • ${account?.email ?: ""}",
                            fontSize = 12.5.sp,
                            color = palette.textSecondary
                        )
                        Text(
                            text = "в сети",
                            fontSize = 12.sp,
                            color = OnlineGreen,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "Активные сеансы (${otherSessions.size})",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = TgBlue,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        if (otherSessions.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = palette.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Других активных устройств нет. Все входы синхронизируются с сервером Fork Gram.",
                        color = palette.textSecondary,
                        fontSize = 13.5.sp,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        } else {
            items(otherSessions, key = { it.id }) { session ->
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = palette.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Devices, contentDescription = null, tint = TgBlue, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = session.deviceName,
                                fontWeight = FontWeight.SemiBold,
                                color = palette.textPrimary,
                                fontSize = 15.sp
                            )
                            Text(
                                text = "${session.platform} • ${dateFormat.format(Date(session.lastActiveAt))}",
                                fontSize = 12.sp,
                                color = palette.textSecondary
                            )
                        }
                        TextButton(onClick = { onTerminateSession(session.id) }) {
                            Text("Завершить", color = DangerRed, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LanguagePickerContent(current: String, onSelect: (String) -> Unit) {
    val palette = LocalForkPalette.current
    Column(modifier = Modifier.padding(16.dp)) {
        Surface(shape = RoundedCornerShape(18.dp), color = palette.surface, modifier = Modifier.fillMaxWidth()) {
            Column {
                listOf("Русский", "English").forEach { lang ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(lang) }
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(lang, color = palette.textPrimary, fontWeight = FontWeight.Medium)
                        if (current == lang) Icon(Icons.Rounded.Check, contentDescription = null, tint = TgBlue)
                    }
                }
            }
        }
    }
}

@Composable
private fun TransactionRowCard(tx: WalletTransaction) {
    val palette = LocalForkPalette.current
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = palette.surface,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(if (tx.currency == "STARS") StarGold.copy(alpha = 0.16f) else GramCyan.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                if (tx.currency == "STARS") {
                    SvgStarIcon(modifier = Modifier.size(20.dp), color = StarGold)
                } else {
                    SvgGramGemIcon(modifier = Modifier.size(20.dp), color = GramCyan)
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(tx.title, fontWeight = FontWeight.SemiBold, fontSize = 14.5.sp, color = palette.textPrimary)
                Text("${tx.subtitle} • ${tx.timestampText}", fontSize = 12.sp, color = palette.textSecondary)
            }
            Text(
                text = tx.amountDisplay,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = if (tx.isCredit) OnlineGreen else palette.textPrimary
            )
        }
    }
}
