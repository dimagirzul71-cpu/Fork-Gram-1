package com.example.ui.svg

import android.content.Context
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.airbnb.lottie.compose.LottieAnimation
import com.airbnb.lottie.compose.LottieCompositionSpec
import com.airbnb.lottie.compose.LottieConstants
import com.airbnb.lottie.compose.animateLottieCompositionAsState
import com.airbnb.lottie.compose.rememberLottieComposition
import com.example.data.model.GiftBackdrop
import com.example.data.model.GiftKind
import com.example.data.model.GiftSymbol
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private object CollectibleLottieCache {
    private val bundledGiftOnlyCache = ConcurrentHashMap<String, String>()
    private val remoteGiftOnlyCache = ConcurrentHashMap<String, String>()

    fun getBundledGiftOnly(context: Context, fragmentSlug: String): String? {
        bundledGiftOnlyCache[fragmentSlug]?.let { return it }
        return runCatching {
            val raw = context.assets.open("gifts/$fragmentSlug.lottie.json")
                .bufferedReader()
                .use { it.readText() }
            val stripped = stripBackgroundLayers(raw)
            bundledGiftOnlyCache[fragmentSlug] = stripped
            stripped
        }.getOrNull()
    }

    suspend fun fetchRemoteGiftOnly(fragmentSlug: String, editionNumber: Int): String? {
        val key = "$fragmentSlug-$editionNumber"
        remoteGiftOnlyCache[key]?.let { return it }
        return withContext(Dispatchers.IO) {
            runCatching {
                val url = URL("https://nft.fragment.com/gift/$fragmentSlug-$editionNumber.lottie.json")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 2500
                    readTimeout = 3000
                    setRequestProperty("Accept", "application/json")
                }
                if (conn.responseCode !in 200..299) {
                    conn.disconnect()
                    return@runCatching null
                }
                val raw = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
                conn.disconnect()
                if (!raw.contains("\"layers\"")) return@runCatching null
                val stripped = stripBackgroundLayers(raw)
                remoteGiftOnlyCache[key] = stripped
                stripped
            }.getOrNull()
        }
    }

    private fun stripBackgroundLayers(rawJson: String): String {
        val root = JSONObject(rawJson)
        val layers = root.optJSONArray("layers") ?: return rawJson
        val filtered = JSONArray()
        for (i in 0 until layers.length()) {
            val layer = layers.optJSONObject(i) ?: continue
            val name = layer.optString("nm", "")
            if (name == "Gift" || (name != "Background" && name != "Pattern" && name != "Color Icon")) {
                filtered.put(layer)
            }
        }
        if (filtered.length() > 0) {
            root.put("layers", filtered)
        }
        return root.toString()
    }
}

@Composable
fun TelegramGiftBackdropBox(
    backdrop: GiftBackdrop,
    symbol: GiftSymbol,
    modifier: Modifier = Modifier,
    radialCenterBiasY: Float = 0.45f,
    showShimmer: Boolean = false,
    content: @Composable BoxScope.() -> Unit
) {
    val centerColor = Color(backdrop.centerHex)
    val edgeColor = Color(backdrop.edgeHex)
    val patternColor = Color(backdrop.patternHex).copy(alpha = 0.28f)
    val shimmerSweep = if (showShimmer) {
        val transition = rememberInfiniteTransition(label = "nftShimmer")
        transition.animateFloat(
            initialValue = -0.35f,
            targetValue = 1.35f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 3200, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "nftShimmerOffset"
        ).value
    } else {
        -1f
    }

    Box(modifier = modifier) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(centerColor, edgeColor),
                    center = Offset(size.width * 0.5f, size.height * radialCenterBiasY),
                    radius = size.maxDimension * 0.74f
                )
            )
            // Repeating Telegram Symbol Watermark Pattern
            val step = 36.dp.toPx()
            val cols = (size.width / step).toInt() + 2
            val rows = (size.height / step).toInt() + 2
            val symSize = 11.dp.toPx()
            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    val x = c * step + if (r % 2 == 1) step * 0.5f else 0f
                    val y = r * step
                    drawGiftPatternSymbol(symbol, x, y, symSize, patternColor)
                }
            }
            if (showShimmer) {
                val startX = size.width * shimmerSweep
                drawRect(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.White.copy(alpha = 0.14f),
                            Color.Transparent
                        ),
                        start = Offset(startX - size.width * 0.35f, 0f),
                        end = Offset(startX + size.width * 0.15f, size.height)
                    )
                )
            }
        }
        content()
    }
}

@Composable
fun AnimatedTelegramGift(
    giftKind: GiftKind,
    modifier: Modifier = Modifier,
    animate: Boolean = true,
    phaseOffsetMs: Int = 0,
    editionNumber: Int? = null,
    useRemoteEdition: Boolean = false
) {
    val context = LocalContext.current
    val initialJson = remember(giftKind.fragmentSlug) {
        CollectibleLottieCache.getBundledGiftOnly(context, giftKind.fragmentSlug)
    }
    var activeJson by remember(giftKind.fragmentSlug, editionNumber, useRemoteEdition) {
        mutableStateOf(initialJson)
    }

    LaunchedEffect(giftKind.fragmentSlug, editionNumber, useRemoteEdition) {
        if (useRemoteEdition && editionNumber != null && editionNumber > 0) {
            val remoteJson = CollectibleLottieCache.fetchRemoteGiftOnly(giftKind.fragmentSlug, editionNumber)
            if (remoteJson != null) {
                activeJson = remoteJson
            }
        }
    }

    val spec = remember(activeJson, giftKind.fragmentSlug) {
        if (!activeJson.isNullOrBlank()) {
            LottieCompositionSpec.JsonString(activeJson!!)
        } else {
            LottieCompositionSpec.Asset("gifts/${giftKind.fragmentSlug}.lottie.json")
        }
    }
    val compositionResult = rememberLottieComposition(spec)
    val composition = compositionResult.value
    var readyToPlay by remember(animate, phaseOffsetMs, composition) {
        mutableStateOf(!animate || phaseOffsetMs <= 0)
    }
    LaunchedEffect(animate, phaseOffsetMs, composition) {
        if (animate && phaseOffsetMs > 0 && composition != null) {
            readyToPlay = false
            kotlinx.coroutines.delay(phaseOffsetMs.toLong().coerceAtMost(1600L))
            readyToPlay = true
        } else {
            readyToPlay = animate
        }
    }
    val progress by animateLottieCompositionAsState(
        composition = composition,
        iterations = LottieConstants.IterateForever,
        isPlaying = animate && readyToPlay,
        restartOnPlay = false
    )

    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        if (composition != null) {
            val staticPhase = ((phaseOffsetMs % 1000) / 1000f).coerceIn(0.08f, 0.92f)
            LottieAnimation(
                composition = composition,
                progress = { if (animate && readyToPlay) progress else staticPhase },
                modifier = Modifier
                    .fillMaxSize()
                    .scale(1.10f)
            )
        } else {
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(
                            Color(giftKind.defaultBackdrop.centerHex).copy(alpha = 0.7f),
                            Color.Transparent
                        )
                    ),
                    radius = size.minDimension * 0.36f
                )
            }
        }
    }
}

private fun DrawScope.drawGiftPatternSymbol(
    symbol: GiftSymbol,
    cx: Float,
    cy: Float,
    s: Float,
    color: Color
) {
    val stroke = Stroke(width = 1.1.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
    when (symbol) {
        GiftSymbol.DIAMOND -> {
            val p = Path().apply {
                moveTo(cx, cy - s * 0.5f)
                lineTo(cx + s * 0.45f, cy)
                lineTo(cx, cy + s * 0.5f)
                lineTo(cx - s * 0.45f, cy)
                close()
            }
            drawPath(p, color = color, style = stroke)
        }
        GiftSymbol.CROWN -> {
            val p = Path().apply {
                moveTo(cx - s * 0.45f, cy + s * 0.3f)
                lineTo(cx - s * 0.5f, cy - s * 0.3f)
                lineTo(cx - s * 0.2f, cy)
                lineTo(cx, cy - s * 0.4f)
                lineTo(cx + s * 0.2f, cy)
                lineTo(cx + s * 0.5f, cy - s * 0.3f)
                lineTo(cx + s * 0.45f, cy + s * 0.3f)
                close()
            }
            drawPath(p, color = color, style = stroke)
        }
        GiftSymbol.STAR -> {
            drawPath(buildSparkleStar(cx, cy, s * 0.52f, s * 0.24f, 5), color = color, style = stroke)
        }
        GiftSymbol.SPARKLE -> {
            drawPath(buildSparkleStar(cx, cy, s * 0.50f, s * 0.16f, 4), color = color, style = stroke)
        }
        GiftSymbol.MOON -> {
            val p = Path().apply {
                moveTo(cx + s * 0.28f, cy - s * 0.38f)
                cubicTo(
                    cx - s * 0.32f, cy - s * 0.42f,
                    cx - s * 0.46f, cy + s * 0.32f,
                    cx + s * 0.28f, cy + s * 0.38f
                )
                cubicTo(
                    cx - s * 0.04f, cy + s * 0.24f,
                    cx - s * 0.04f, cy - s * 0.24f,
                    cx + s * 0.28f, cy - s * 0.38f
                )
                close()
            }
            drawPath(p, color = color, style = stroke)
        }
        GiftSymbol.HEART -> {
            val p = Path().apply {
                moveTo(cx, cy + s * 0.42f)
                cubicTo(cx - s * 0.55f, cy + s * 0.1f, cx - s * 0.45f, cy - s * 0.42f, cx, cy - s * 0.15f)
                cubicTo(cx + s * 0.45f, cy - s * 0.42f, cx + s * 0.55f, cy + s * 0.1f, cx, cy + s * 0.42f)
            }
            drawPath(p, color = color, style = stroke)
        }
        GiftSymbol.BOLT -> {
            val p = Path().apply {
                moveTo(cx + s * 0.1f, cy - s * 0.45f)
                lineTo(cx - s * 0.25f, cy + s * 0.05f)
                lineTo(cx + s * 0.05f, cy + s * 0.05f)
                lineTo(cx - s * 0.1f, cy + s * 0.45f)
            }
            drawPath(p, color = color, style = stroke)
        }
        GiftSymbol.LEAF -> {
            val r = s * 0.20f
            drawCircle(color = color, radius = r, center = Offset(cx, cy - r * 1.05f), style = stroke)
            drawCircle(color = color, radius = r, center = Offset(cx, cy + r * 1.05f), style = stroke)
            drawCircle(color = color, radius = r, center = Offset(cx - r * 1.05f, cy), style = stroke)
            drawCircle(color = color, radius = r, center = Offset(cx + r * 1.05f, cy), style = stroke)
        }
    }
}

private fun buildSparkleStar(cx: Float, cy: Float, outerR: Float, innerR: Float, points: Int): Path {
    val path = Path()
    val total = points * 2
    for (i in 0 until total) {
        val angle = (i * PI / points) - PI / 2.0
        val r = if (i % 2 == 0) outerR else innerR
        val x = cx + (r * cos(angle)).toFloat()
        val y = cy + (r * sin(angle)).toFloat()
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    return path
}
