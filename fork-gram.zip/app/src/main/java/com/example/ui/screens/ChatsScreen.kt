package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.CameraAlt
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.MarkChatRead
import androidx.compose.material.icons.rounded.Campaign
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Done
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ChatFolder
import com.example.data.model.ChatThread
import com.example.data.model.ChatType
import com.example.data.model.ContactItem
import com.example.ui.components.ArchiveAvatar
import com.example.ui.components.AvatarView
import com.example.ui.components.TelegramOutlinedField
import com.example.ui.svg.SvgComposeNewChatIcon
import com.example.ui.svg.SvgGiftArtwork
import com.example.ui.svg.SvgStarIcon
import com.example.ui.svg.SvgVerifiedBadge
import com.example.ui.theme.LocalForkPalette
import com.example.ui.theme.OnlineGreen
import com.example.ui.theme.TgBlue
import kotlin.math.roundToInt

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatsScreen(
    chats: List<ChatThread>,
    folders: List<ChatFolder>,
    contacts: List<ContactItem>,
    selectedFolderId: String?,
    isDarkTheme: Boolean,
    onSelectFolder: (String?) -> Unit,
    onOpenChat: (String) -> Unit,
    onToggleNightMode: () -> Unit,
    onOpenSavedMessages: () -> Unit,
    onOpenFoldersEditor: () -> Unit,
    onDeleteFolder: (String) -> Unit = {},
    onCreateGroupOrChannel: (title: String, isChannel: Boolean, isSecret: Boolean) -> Unit,
    onTogglePinChat: (String) -> Unit,
    onToggleArchiveChat: (String) -> Unit,
    onToggleMuteChat: (String) -> Unit,
    onMarkChatRead: (String) -> Unit = {},
    onDeleteChat: (String) -> Unit = {},
    onOpenContactChat: (ContactItem) -> Unit,
    onPublishStoryPost: ((Uri, String) -> Unit)? = null,
    onShowStoryTip: () -> Unit
) {
    val palette = LocalForkPalette.current
    var searchQuery by remember { mutableStateOf("") }
    var showOverflowMenu by remember { mutableStateOf(false) }
    var showArchivedView by remember { mutableStateOf(false) }
    var showCreateDialog by remember { mutableStateOf<CreateDialogMode?>(null) }
    var showComposeSheet by remember { mutableStateOf(false) }
    var chatContextTarget by remember { mutableStateOf<ChatThread?>(null) }
    var selectedChatIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var folderContextTarget by remember { mutableStateOf<ChatFolder?>(null) }
    var pendingStoryUri by remember { mutableStateOf<Uri?>(null) }

    val storyPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) pendingStoryUri = uri
    }

    val isSelectionMode = selectedChatIds.isNotEmpty()

    BackHandler(enabled = isSelectionMode || showArchivedView) {
        if (isSelectionMode) {
            selectedChatIds = emptySet()
        } else {
            showArchivedView = false
        }
    }

    val archivedChats = remember(chats) { chats.filter { it.isArchived } }
    val matchesFolder: (ChatThread, ChatFolder) -> Boolean = remember {
        { chat, folder ->
            val typeMatch = folder.includeTypes.isEmpty() || chat.chatType in folder.includeTypes
            val unreadMatch = !folder.onlyUnread || chat.unreadCount > 0
            (typeMatch && unreadMatch) || (chat.id in folder.includedChatIds)
        }
    }

    val activeChats = remember(chats, folders, selectedFolderId, searchQuery) {
        val base = chats.filter { !it.isArchived }
        val byFolder = if (selectedFolderId == null) {
            base
        } else {
            val folder = folders.firstOrNull { it.id == selectedFolderId }
            if (folder == null) base else base.filter { chat -> matchesFolder(chat, folder) }
        }
        val q = searchQuery.trim().lowercase()
        if (q.isEmpty()) byFolder else byFolder.filter {
            it.title.lowercase().contains(q) ||
                it.lastMessagePreview.lowercase().contains(q) ||
                it.draftText.lowercase().contains(q) ||
                (it.username?.lowercase()?.contains(q) == true)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.surface)
            .statusBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header row: Selection Mode Bar OR Archived Header OR Fork Gram Title
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 6.dp, top = 8.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                when {
                    isSelectionMode -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { selectedChatIds = emptySet() }) {
                                Icon(Icons.Rounded.Close, contentDescription = "Снять выбор", tint = palette.textPrimary)
                            }
                            Text(
                                text = "${selectedChatIds.size}",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = palette.textPrimary
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = {
                                    selectedChatIds.forEach { onTogglePinChat(it) }
                                    selectedChatIds = emptySet()
                                }
                            ) {
                                Icon(Icons.Rounded.PushPin, contentDescription = "Закрепить", tint = palette.textPrimary)
                            }
                            IconButton(
                                onClick = {
                                    selectedChatIds.forEach { onToggleMuteChat(it) }
                                    selectedChatIds = emptySet()
                                }
                            ) {
                                Icon(Icons.Rounded.VolumeOff, contentDescription = "Звук", tint = palette.textPrimary)
                            }
                            IconButton(
                                onClick = {
                                    selectedChatIds.forEach { onMarkChatRead(it) }
                                    selectedChatIds = emptySet()
                                }
                            ) {
                                Icon(Icons.Outlined.MarkChatRead, contentDescription = "Прочитано", tint = palette.textPrimary)
                            }
                            IconButton(
                                onClick = {
                                    selectedChatIds.forEach { onToggleArchiveChat(it) }
                                    selectedChatIds = emptySet()
                                }
                            ) {
                                Icon(Icons.Outlined.Inventory2, contentDescription = "В архив", tint = palette.textPrimary)
                            }
                            IconButton(
                                onClick = {
                                    selectedChatIds.forEach { onDeleteChat(it) }
                                    selectedChatIds = emptySet()
                                }
                            ) {
                                Icon(Icons.Outlined.Delete, contentDescription = "Удалить", tint = Color(0xFFEB5757))
                            }
                        }
                    }

                    showArchivedView -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { showArchivedView = false }) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                    contentDescription = "Назад",
                                    tint = palette.textPrimary
                                )
                            }
                            Text(
                                text = "Архив чатов",
                                fontSize = 21.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = palette.textPrimary
                            )
                        }
                    }

                    else -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(start = 2.dp)
                        ) {
                            Text(
                                text = "Fork Gram",
                                fontSize = 21.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TgBlue
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            SvgStarIcon(
                                modifier = Modifier.size(17.dp),
                                color = TgBlue
                            )
                        }

                        Box {
                            IconButton(
                                onClick = { showOverflowMenu = true },
                                modifier = Modifier.testTag("chats_overflow_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.MoreVert,
                                    contentDescription = "Меню",
                                    tint = palette.textPrimary
                                )
                            }

                            DropdownMenu(
                                expanded = showOverflowMenu,
                                onDismissRequest = { showOverflowMenu = false },
                                shape = RoundedCornerShape(16.dp),
                                containerColor = palette.surface
                            ) {
                                DropdownMenuItem(
                                    leadingIcon = {
                                        Icon(
                                            imageVector = if (isDarkTheme) Icons.Outlined.LightMode else Icons.Outlined.DarkMode,
                                            contentDescription = null,
                                            tint = palette.textPrimary
                                        )
                                    },
                                    text = {
                                        Text(
                                            text = if (isDarkTheme) "Дневной режим" else "Ночной режим",
                                            color = palette.textPrimary
                                        )
                                    },
                                    onClick = {
                                        showOverflowMenu = false
                                        onToggleNightMode()
                                    }
                                )
                                HorizontalDivider(color = palette.divider, thickness = 0.5.dp)
                                DropdownMenuItem(
                                    leadingIcon = {
                                        Icon(Icons.Outlined.Group, contentDescription = null, tint = palette.textPrimary)
                                    },
                                    text = { Text("Создать группу", color = palette.textPrimary) },
                                    onClick = {
                                        showOverflowMenu = false
                                        showCreateDialog = CreateDialogMode.GROUP
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = {
                                        Icon(Icons.Rounded.Campaign, contentDescription = null, tint = palette.textPrimary)
                                    },
                                    text = { Text("Создать канал", color = palette.textPrimary) },
                                    onClick = {
                                        showOverflowMenu = false
                                        showCreateDialog = CreateDialogMode.CHANNEL
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = {
                                        Icon(Icons.Outlined.BookmarkBorder, contentDescription = null, tint = palette.textPrimary)
                                    },
                                    text = { Text("Избранное", color = palette.textPrimary) },
                                    onClick = {
                                        showOverflowMenu = false
                                        onOpenSavedMessages()
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Pill Search Bar (1:1 Telegram)
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .height(40.dp),
                shape = RoundedCornerShape(20.dp),
                color = palette.surfaceVariant
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Search,
                        contentDescription = null,
                        tint = palette.textSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                        if (searchQuery.isEmpty()) {
                            Text(
                                text = "Поиск чатов",
                                color = palette.textSecondary,
                                fontSize = 15.sp
                            )
                        }
                        BasicTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            singleLine = true,
                            textStyle = TextStyle(
                                color = palette.textPrimary,
                                fontSize = 15.sp
                            ),
                            cursorBrush = SolidColor(TgBlue),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("chats_search_input")
                        )
                    }
                    if (searchQuery.isNotEmpty()) {
                        IconButton(
                            onClick = { searchQuery = "" },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = "Очистить",
                                tint = palette.textSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            // Chat Folders horizontal tabs
            AnimatedVisibility(visible = !showArchivedView && folders.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FolderTabChip(
                        title = "Все чаты",
                        selected = selectedFolderId == null,
                        unreadCount = chats.count { !it.isArchived && it.unreadCount > 0 },
                        onClick = { onSelectFolder(null) }
                    )
                    folders.forEach { folder ->
                        val folderUnread = chats.count { c ->
                            !c.isArchived && c.unreadCount > 0 && matchesFolder(c, folder)
                        }
                        FolderTabChip(
                            title = folder.name,
                            selected = selectedFolderId == folder.id,
                            unreadCount = folderUnread,
                            onClick = { onSelectFolder(folder.id) },
                            onLongClick = { folderContextTarget = folder }
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = palette.surfaceVariant,
                        modifier = Modifier.clickable { onOpenFoldersEditor() }
                    ) {
                        Text(
                            text = "+ Папки",
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Medium,
                            color = TgBlue,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            // Chat list
            val displayedChats = if (showArchivedView) archivedChats else activeChats
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 110.dp)
            ) {
                if (!showArchivedView && selectedFolderId == null && searchQuery.isEmpty() && archivedChats.isNotEmpty()) {
                    item(key = "archive_row") {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showArchivedView = true }
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                                .testTag("archive_chats_row"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            ArchiveAvatar(size = 52.dp)
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Архив чатов",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = palette.textPrimary
                                    )
                                    val archivedUnread = archivedChats.sumOf { it.unreadCount }
                                    if (archivedUnread > 0) {
                                        Box(
                                            modifier = Modifier
                                                .clip(CircleShape)
                                                .background(palette.textSecondary.copy(alpha = 0.55f))
                                                .padding(horizontal = 7.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = archivedUnread.toString(),
                                                color = Color.White,
                                                fontSize = 11.5.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = archivedChats.joinToString(", ") { it.title },
                                    fontSize = 14.sp,
                                    color = palette.textSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }

                items(displayedChats, key = { it.id }) { chat ->
                    val isSelected = chat.id in selectedChatIds
                    SwipeableChatRowItem(
                        chat = chat,
                        isSelected = isSelected,
                        onClick = {
                            if (isSelectionMode) {
                                selectedChatIds = if (isSelected) selectedChatIds - chat.id else selectedChatIds + chat.id
                            } else {
                                onOpenChat(chat.id)
                            }
                        },
                        onLongClick = {
                            if (isSelectionMode) {
                                selectedChatIds = if (isSelected) selectedChatIds - chat.id else selectedChatIds + chat.id
                            } else {
                                chatContextTarget = chat
                            }
                        },
                        onSwipeArchive = { onToggleArchiveChat(chat.id) }
                    )
                    HorizontalDivider(
                        color = palette.divider.copy(alpha = 0.65f),
                        thickness = 0.5.dp,
                        modifier = Modifier.padding(start = 83.dp)
                    )
                }

                if (displayedChats.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 48.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Чаты не найдены",
                                color = palette.textSecondary,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }
        }

        // Bottom-right Camera + Compose FABs (1:1 Telegram)
        if (!showArchivedView && !isSelectionMode) {
            Column(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 16.dp, bottom = 92.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SmallFloatingActionButton(
                    onClick = {
                        if (onPublishStoryPost != null) {
                            storyPicker.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        } else {
                            onShowStoryTip()
                        }
                    },
                    shape = CircleShape,
                    containerColor = palette.surface,
                    contentColor = palette.textPrimary,
                    elevation = FloatingActionButtonDefaults.elevation(4.dp),
                    modifier = Modifier.size(44.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.CameraAlt,
                        contentDescription = "Добавить историю в профиль",
                        modifier = Modifier.size(21.dp)
                    )
                }

                FloatingActionButton(
                    onClick = { showComposeSheet = true },
                    shape = CircleShape,
                    containerColor = TgBlue,
                    contentColor = Color.White,
                    elevation = FloatingActionButtonDefaults.elevation(6.dp),
                    modifier = Modifier
                        .size(56.dp)
                        .testTag("chats_compose_fab")
                ) {
                    SvgComposeNewChatIcon(
                        modifier = Modifier.size(26.dp),
                        color = Color.White,
                        plusCutoutColor = TgBlue
                    )
                }
            }
        }
    }

    // Story / Profile Post caption composer
    pendingStoryUri?.let { uri ->
        var caption by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { pendingStoryUri = null },
            containerColor = palette.surface,
            shape = RoundedCornerShape(24.dp),
            title = { Text("Опубликовать в профиль", fontWeight = FontWeight.Bold, color = palette.textPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    AsyncImage(
                        model = uri,
                        contentDescription = "Предпросмотр",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(16.dp))
                    )
                    TelegramOutlinedField(
                        value = caption,
                        onValueChange = { caption = it },
                        label = "Подпись (необязательно)"
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onPublishStoryPost?.invoke(uri, caption)
                        pendingStoryUri = null
                    },
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TgBlue)
                ) {
                    Text("Опубликовать", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingStoryUri = null }) {
                    Text("Отмена", color = palette.textSecondary)
                }
            }
        )
    }

    // Long-press folder delete dialog
    folderContextTarget?.let { folder ->
        AlertDialog(
            onDismissRequest = { folderContextTarget = null },
            containerColor = palette.surface,
            title = { Text("Папка «${folder.name}»", fontWeight = FontWeight.SemiBold, color = palette.textPrimary) },
            text = { Text("Вы можете настроить папки или удалить эту папку.", color = palette.textSecondary) },
            confirmButton = {
                TextButton(
                    onClick = {
                        onOpenFoldersEditor()
                        folderContextTarget = null
                    }
                ) {
                    Text("Настроить", color = TgBlue)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        onDeleteFolder(folder.id)
                        folderContextTarget = null
                    }
                ) {
                    Text("Удалить", color = Color(0xFFEB5757))
                }
            }
        )
    }

    // Long-press chat actions dialog + Select Mode toggle
    chatContextTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { chatContextTarget = null },
            containerColor = palette.surface,
            title = { Text(target.title, fontWeight = FontWeight.SemiBold, color = palette.textPrimary) },
            text = {
                Column {
                    TextButton(
                        onClick = {
                            selectedChatIds = setOf(target.id)
                            chatContextTarget = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Выбрать", color = TgBlue)
                    }
                    TextButton(
                        onClick = {
                            onTogglePinChat(target.id)
                            chatContextTarget = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (target.isPinned) "Открепить чат" else "Закрепить чат", color = palette.textPrimary)
                    }
                    TextButton(
                        onClick = {
                            onToggleMuteChat(target.id)
                            chatContextTarget = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (target.isMuted) "Включить уведомления" else "Отключить уведомления", color = palette.textPrimary)
                    }
                    TextButton(
                        onClick = {
                            onToggleArchiveChat(target.id)
                            chatContextTarget = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (target.isArchived) "Вернуть из архива" else "В архив", color = palette.textPrimary)
                    }
                    TextButton(
                        onClick = {
                            onDeleteChat(target.id)
                            chatContextTarget = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Удалить чат", color = Color(0xFFEB5757))
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { chatContextTarget = null }) { Text("Закрыть", color = TgBlue) }
            }
        )
    }

    // Compose / New Chat Dialog
    if (showComposeSheet) {
        AlertDialog(
            onDismissRequest = { showComposeSheet = false },
            containerColor = palette.surface,
            title = { Text("Новый чат", fontWeight = FontWeight.Bold, color = palette.textPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                showComposeSheet = false
                                showCreateDialog = CreateDialogMode.GROUP
                            }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Outlined.Group, contentDescription = null, tint = TgBlue)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("Создать группу", color = palette.textPrimary, fontWeight = FontWeight.Medium)
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                showComposeSheet = false
                                showCreateDialog = CreateDialogMode.CHANNEL
                            }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Campaign, contentDescription = null, tint = TgBlue)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("Создать канал", color = palette.textPrimary, fontWeight = FontWeight.Medium)
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                showComposeSheet = false
                                showCreateDialog = CreateDialogMode.SECRET
                            }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Lock, contentDescription = null, tint = Color(0xFF2E9E5B))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("Новый секретный чат", color = palette.textPrimary, fontWeight = FontWeight.Medium)
                    }
                    HorizontalDivider(color = palette.divider)
                    Text("Контакты", fontSize = 12.sp, color = palette.textSecondary)
                    contacts.forEach { contact ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    showComposeSheet = false
                                    onOpenContactChat(contact)
                                }
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AvatarView(
                                title = contact.fullName,
                                avatarUri = null,
                                colorHex = contact.avatarColorHex,
                                size = 36.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(contact.fullName, color = palette.textPrimary, fontWeight = FontWeight.Medium)
                                Text(contact.username, color = palette.textSecondary, fontSize = 12.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showComposeSheet = false }) { Text("Закрыть", color = TgBlue) }
            }
        )
    }

    // Create Group / Channel / Secret dialog
    showCreateDialog?.let { mode ->
        var title by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCreateDialog = null },
            containerColor = palette.surface,
            shape = RoundedCornerShape(24.dp),
            title = {
                Text(
                    text = when (mode) {
                        CreateDialogMode.GROUP -> "Новая группа"
                        CreateDialogMode.CHANNEL -> "Новый канал"
                        CreateDialogMode.SECRET -> "Секретный чат"
                    },
                    fontWeight = FontWeight.Bold,
                    color = palette.textPrimary
                )
            },
            text = {
                TelegramOutlinedField(
                    value = title,
                    onValueChange = { title = it },
                    label = if (mode == CreateDialogMode.SECRET) "Имя собеседника" else "Название"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onCreateGroupOrChannel(
                            title,
                            mode == CreateDialogMode.CHANNEL,
                            mode == CreateDialogMode.SECRET
                        )
                        showCreateDialog = null
                    },
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TgBlue)
                ) {
                    Text("Создать", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = null }) { Text("Отмена", color = palette.textSecondary) }
            }
        )
    }
}

private enum class CreateDialogMode { GROUP, CHANNEL, SECRET }

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FolderTabChip(
    title: String,
    selected: Boolean,
    unreadCount: Int,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null
) {
    val palette = LocalForkPalette.current
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = title,
                fontSize = 13.5.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                color = if (selected) TgBlue else palette.textSecondary
            )
            if (unreadCount > 0) {
                Spacer(modifier = Modifier.width(5.dp))
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(if (selected) TgBlue else palette.textSecondary.copy(alpha = 0.55f))
                        .padding(horizontal = 5.5.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = unreadCount.toString(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .width(if (selected) 26.dp else 0.dp)
                .height(3.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(if (selected) TgBlue else Color.Transparent)
        )
    }
}

@Composable
private fun SwipeableChatRowItem(
    chat: ChatThread,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onSwipeArchive: () -> Unit
) {
    val density = LocalDensity.current
    val archiveTriggerPx = with(density) { 88.dp.toPx() }
    var dragOffsetX by remember { mutableFloatStateOf(0f) }
    val animatedOffset by animateFloatAsState(targetValue = dragOffsetX, label = "chatSwipe")

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (chat.isArchived) TgBlue.copy(alpha = 0.85f) else Color(0xFF7B8B9A))
    ) {
        if (animatedOffset < -8f) {
            Row(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 22.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Outlined.Inventory2,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (chat.isArchived) "Вернуть" else "В архив",
                    color = Color.White,
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Box(
            modifier = Modifier
                .offset { IntOffset(animatedOffset.roundToInt(), 0) }
                .pointerInput(chat.id) {
                    detectHorizontalDragGestures(
                        onDragEnd = {
                            if (dragOffsetX <= -archiveTriggerPx) {
                                onSwipeArchive()
                            }
                            dragOffsetX = 0f
                        },
                        onDragCancel = { dragOffsetX = 0f },
                        onHorizontalDrag = { _, dragAmount ->
                            val next = dragOffsetX + dragAmount
                            if (next <= 0f) {
                                dragOffsetX = next.coerceAtLeast(-archiveTriggerPx * 1.35f)
                            }
                        }
                    )
                }
        ) {
            ChatRowItem(
                chat = chat,
                isSelected = isSelected,
                onClick = onClick,
                onLongClick = onLongClick
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ChatRowItem(
    chat: ChatThread,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val palette = LocalForkPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (isSelected) TgBlue.copy(alpha = 0.12f) else palette.surface)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 16.dp, vertical = 9.dp)
            .testTag("chat_item_${chat.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box {
            AvatarView(
                title = chat.title,
                avatarUri = chat.avatarUri,
                colorHex = chat.avatarColorHex,
                size = 54.dp,
                chatType = chat.chatType
            )
            if (isSelected) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(palette.surface)
                        .padding(1.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.CheckCircle,
                        contentDescription = "Выбран",
                        tint = TgBlue,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            } else if (chat.isOnline && chat.chatType == ChatType.DIRECT) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(14.dp)
                        .clip(CircleShape)
                        .background(palette.surface)
                        .padding(2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .background(OnlineGreen)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.width(13.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    if (chat.chatType == ChatType.SECRET) {
                        Icon(
                            imageVector = Icons.Rounded.Lock,
                            contentDescription = "Секретный",
                            tint = Color(0xFF2E9E5B),
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                    Text(
                        text = chat.title,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (chat.chatType == ChatType.SECRET) Color(0xFF2E9E5B) else palette.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (chat.isVerified) {
                        Spacer(modifier = Modifier.width(5.dp))
                        SvgVerifiedBadge(modifier = Modifier.size(16.dp), badgeColor = TgBlue)
                    } else if (chat.statusGiftKind != null) {
                        Spacer(modifier = Modifier.width(5.dp))
                        SvgGiftArtwork(
                            giftKind = chat.statusGiftKind,
                            modifier = Modifier.size(16.dp)
                        )
                    } else if (chat.isPremiumBadge) {
                        Spacer(modifier = Modifier.width(5.dp))
                        SvgStarIcon(modifier = Modifier.size(15.dp), color = TgBlue)
                    }
                    if (chat.isMuted) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Rounded.VolumeOff,
                            contentDescription = "Без звука",
                            tint = palette.textSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (chat.isLastMessageOutgoing && chat.draftText.isBlank()) {
                        Icon(
                            imageVector = if (chat.isLastOutgoingRead) Icons.Rounded.DoneAll else Icons.Rounded.Done,
                            contentDescription = if (chat.isLastOutgoingRead) "Прочитано" else "Отправлено",
                            tint = if (chat.isLastOutgoingRead) TgBlue else palette.textSecondary,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                    }
                    Text(
                        text = chat.lastMessageTime,
                        fontSize = 12.5.sp,
                        color = if (chat.unreadCount > 0) TgBlue else palette.textSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(3.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                when {
                    chat.draftText.isNotBlank() -> {
                        Text(
                            text = buildAnnotatedString {
                                withStyle(SpanStyle(color = Color(0xFFE53935), fontWeight = FontWeight.Medium)) {
                                    append("Черновик: ")
                                }
                                append(chat.draftText)
                            },
                            fontSize = 14.5.sp,
                            color = palette.textSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    chat.isTyping -> {
                        Text(
                            text = "печатает...",
                            fontSize = 14.5.sp,
                            color = TgBlue,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    else -> {
                        Text(
                            text = chat.lastMessagePreview,
                            fontSize = 14.5.sp,
                            color = palette.textSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (chat.isPinned && chat.unreadCount == 0) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Rounded.PushPin,
                            contentDescription = "Закреплён",
                            tint = palette.textSecondary,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                    if (chat.unreadCount > 0) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(if (chat.isMuted) palette.textSecondary.copy(alpha = 0.55f) else TgBlue)
                                .padding(horizontal = 7.dp, vertical = 2.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = chat.unreadCount.toString(),
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }
}
