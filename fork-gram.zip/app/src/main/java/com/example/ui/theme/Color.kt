package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Telegram / Fork Gram Blues
val TgBlue = Color(0xFF239AE8)
val TgBluePressed = Color(0xFF1D89D0)
val TgBlueDark = Color(0xFF187FC2)
val TgBlueSoft = Color(0xFFE4F2FE)
val TgBlueSoftDark = Color(0xFF1D3549)

// Light Theme Surfaces (1:1 Original Telegram Android v12.4+)
val LightBackground = Color(0xFFF0F2F5)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F2F4)
val LightDivider = Color(0xFFE6E8EC)
val LightTextPrimary = Color(0xFF16181A)
val LightTextSecondary = Color(0xFF7D858E)
val LightBubbleIncoming = Color(0xFFFFFFFF)
val LightBubbleOutgoing = Color(0xFFEEFFDE)
val LightBubbleOutgoingMeta = Color(0xFF4CA844)
val LightNavPill = Color(0xF5FFFFFF)
val LightNavActivePill = Color(0xFFE4F2FE)

// Dark Theme Surfaces (Telegram Night / Liquid Glass Dark)
val DarkBackground = Color(0xFF0E1621)
val DarkSurface = Color(0xFF17212B)
val DarkSurfaceVariant = Color(0xFF212D3B)
val DarkDivider = Color(0xFF101923)
val DarkTextPrimary = Color(0xFFF5F7FA)
val DarkTextSecondary = Color(0xFF8393A3)
val DarkBubbleIncoming = Color(0xFF182533)
val DarkBubbleOutgoing = Color(0xFF2B5278)
val DarkBubbleOutgoingMeta = Color(0xFF7EB6EA)
val DarkNavPill = Color(0xF21A2531)
val DarkNavActivePill = Color(0xFF263B4F)

// Accent & Currency Colors
val StarGold = Color(0xFFFFA629)
val StarGoldSoft = Color(0xFFFFF3DC)
val GramCyan = Color(0xFF0098EA)
val GramCyanSoft = Color(0xFFE0F4FF)
val PremiumViolet = Color(0xFF8A63D2)
val OnlineGreen = Color(0xFF34C759)
val DangerRed = Color(0xFFE53935)
val SecretGreen = Color(0xFF2E9E5B)

// Settings Icon Circle Colors (Screenshot 6)
val IconBlue = Color(0xFF2D9CDB)
val IconAmber = Color(0xFFF2994A)
val IconGreen = Color(0xFF46B966)
val IconRed = Color(0xFFEF5350)
val IconIndigo = Color(0xFF4C7BF4)
val IconCyan = Color(0xFF28A8EA)
val IconTeal = Color(0xFF34B3A0)
val IconOrange = Color(0xFFF58231)
val IconPurple = Color(0xFF8E5FF5)
val IconPink = Color(0xFFEB5777)

// Chat Wallpaper Gradients
val WallpaperGreenTop = Color(0xFFD5E19E)
val WallpaperGreenBottom = Color(0xFF8DB974)
val WallpaperGreenPattern = Color(0x2850753A)

val WallpaperOceanTop = Color(0xFFBCE2F7)
val WallpaperOceanBottom = Color(0xFF7BBCE6)
val WallpaperOceanPattern = Color(0x241E5C85)

val WallpaperLavenderTop = Color(0xFFD9C9F5)
val WallpaperLavenderBottom = Color(0xFFA28EE0)
val WallpaperLavenderPattern = Color(0x24463087)

val WallpaperDarkTop = Color(0xFF0F1A26)
val WallpaperDarkBottom = Color(0xFF142434)
val WallpaperDarkPattern = Color(0x226996C4)
