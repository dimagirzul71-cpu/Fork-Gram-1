package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ContactItem
import com.example.data.remote.RemoteDirectoryUser
import com.example.ui.components.AvatarView
import com.example.ui.components.TelegramOutlinedField
import com.example.ui.svg.SvgDuckDetective
import com.example.ui.svg.SvgGiftArtwork
import com.example.ui.theme.LocalForkPalette
import com.example.ui.theme.OnlineGreen
import com.example.ui.theme.TgBlue
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactsScreen(
    contacts: List<ContactItem>,
    remoteDirectory: List<RemoteDirectoryUser> = emptyList(),
    onSearchRemoteDirectory: (String) -> Unit = {},
    onOpenRemoteUserChat: (RemoteDirectoryUser) -> Unit = {},
    onOpenContactChat: (ContactItem) -> Unit,
    onCreateContact: (firstName: String, lastName: String, emailOrHandle: String) -> Unit,
    onShowToast: (String) -> Unit
) {
    val palette = LocalForkPalette.current
    var searchQuery by remember { mutableStateOf("") }
    var showNewContactSheet by remember { mutableStateOf(false) }

    LaunchedEffect(searchQuery) {
        delay(240L)
        onSearchRemoteDirectory(searchQuery)
    }

    val filtered = remember(contacts, searchQuery) {
        val q = searchQuery.trim().lowercase()
        if (q.isEmpty()) contacts else contacts.filter {
            it.fullName.lowercase().contains(q) ||
                it.username.lowercase().contains(q) ||
                it.email.lowercase().contains(q)
        }
    }
    val localEmails = remember(contacts) { contacts.map { it.email.lowercase() }.toSet() }
    val filteredRemote = remember(remoteDirectory, localEmails, searchQuery) {
        val q = searchQuery.trim().lowercase()
        remoteDirectory.filter { user ->
            user.email.lowercase() !in localEmails && (
                q.isEmpty() ||
                    user.fullName.lowercase().contains(q) ||
                    user.username.lowercase().contains(q) ||
                    user.email.lowercase().contains(q)
                )
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            .statusBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Контакты",
                    fontSize = 23.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = palette.textPrimary
                )
                IconButton(
                    onClick = { showNewContactSheet = true },
                    modifier = Modifier.testTag("contacts_add_top_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PersonAdd,
                        contentDescription = "Новый контакт",
                        tint = TgBlue
                    )
                }
            }

            // Pill Search Bar (1:1 to Screenshot 3 & 4)
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .height(40.dp),
                shape = RoundedCornerShape(20.dp),
                color = palette.surface,
                shadowElevation = 1.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Search,
                        contentDescription = null,
                        tint = palette.textSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                        if (searchQuery.isEmpty()) {
                            Text(
                                text = "Поиск по имени пользователя",
                                color = palette.textSecondary,
                                fontSize = 15.sp
                            )
                        }
                        BasicTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            singleLine = true,
                            textStyle = TextStyle(color = palette.textPrimary, fontSize = 15.sp),
                            cursorBrush = SolidColor(TgBlue),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(28.dp)) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = "Очистить",
                                tint = palette.textSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            if (filtered.isEmpty() && filteredRemote.isEmpty()) {
                // 1:1 Empty State with SVG Duck Detective (Screenshot 4)
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 32.dp)
                        .padding(bottom = 90.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    SvgDuckDetective(modifier = Modifier.size(124.dp))
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Добавить контакты",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (searchQuery.isNotEmpty()) {
                            "По вашему запросу ничего не найдено."
                        } else {
                            "У Вас пока нет контактов в Fork Gram — Вы можете их добавить."
                        },
                        fontSize = 14.sp,
                        color = palette.textSecondary,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = { showNewContactSheet = true },
                        shape = RoundedCornerShape(24.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = TgBlue),
                        contentPadding = PaddingValues(horizontal = 24.dp, vertical = 12.dp)
                    ) {
                        Icon(Icons.Rounded.PersonAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Новый контакт", fontWeight = FontWeight.SemiBold, color = Color.White)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(top = 6.dp, bottom = 110.dp)
                ) {
                    items(filtered, key = { it.id }) { contact ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onOpenContactChat(contact) }
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box {
                                AvatarView(
                                    title = contact.fullName,
                                    avatarUri = null,
                                    colorHex = contact.avatarColorHex,
                                    size = 50.dp
                                )
                                if (contact.isOnline) {
                                    Box(
                                        modifier = Modifier
                                            .size(13.dp)
                                            .align(Alignment.BottomEnd)
                                            .clip(CircleShape)
                                            .background(palette.surface)
                                            .padding(2.dp)
                                            .clip(CircleShape)
                                            .background(OnlineGreen)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = contact.fullName,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = palette.textPrimary
                                    )
                                    if (contact.statusGiftKind != null) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        SvgGiftArtwork(
                                            giftKind = contact.statusGiftKind,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = "${contact.statusText} • ${contact.username}",
                                    fontSize = 13.5.sp,
                                    color = if (contact.isOnline) TgBlue else palette.textSecondary
                                )
                            }
                        }
                        HorizontalDivider(
                            color = palette.divider.copy(alpha = 0.65f),
                            thickness = 0.5.dp,
                            modifier = Modifier.padding(start = 80.dp)
                        )
                    }

                    if (filteredRemote.isNotEmpty()) {
                        item(key = "remote_header") {
                            Text(
                                text = "Глобальный поиск Fork Gram",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TgBlue,
                                modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 6.dp)
                            )
                        }
                        items(filteredRemote, key = { "remote_${it.email}" }) { remoteUser ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onOpenRemoteUserChat(remoteUser) }
                                    .padding(horizontal = 16.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                AvatarView(
                                    title = remoteUser.fullName,
                                    avatarUri = null,
                                    colorHex = 0xFF2AABEE,
                                    size = 50.dp
                                )
                                Spacer(modifier = Modifier.width(14.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = remoteUser.fullName,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = palette.textPrimary
                                    )
                                    Text(
                                        text = "${remoteUser.displayHandle} • в сети",
                                        fontSize = 13.5.sp,
                                        color = TgBlue
                                    )
                                }
                            }
                            HorizontalDivider(
                                color = palette.divider.copy(alpha = 0.65f),
                                thickness = 0.5.dp,
                                modifier = Modifier.padding(start = 80.dp)
                            )
                        }
                    }
                }
            }
        }

        if (filtered.isNotEmpty() || filteredRemote.isNotEmpty()) {
            FloatingActionButton(
                onClick = { showNewContactSheet = true },
                shape = CircleShape,
                containerColor = TgBlue,
                contentColor = Color.White,
                elevation = FloatingActionButtonDefaults.elevation(6.dp),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 16.dp, bottom = 92.dp)
                    .size(56.dp)
                    .testTag("contacts_fab")
            ) {
                Icon(Icons.Rounded.PersonAdd, contentDescription = "Добавить контакт")
            }
        }
    }

    // 1:1 "Новый контакт" Bottom Sheet (Screenshot 3)
    if (showNewContactSheet) {
        var firstName by remember { mutableStateOf("") }
        var lastName by remember { mutableStateOf("") }
        var emailOrHandle by remember { mutableStateOf("") }
        var syncPhone by remember { mutableStateOf(false) }

        ModalBottomSheet(
            onDismissRequest = { showNewContactSheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = palette.surface,
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 28.dp)
            ) {
                Text(
                    text = "Новый контакт",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = palette.textPrimary
                )
                Spacer(modifier = Modifier.height(14.dp))

                TelegramOutlinedField(
                    value = firstName,
                    onValueChange = { firstName = it },
                    label = "Имя (обязательно)",
                    modifier = Modifier.testTag("new_contact_first_name")
                )
                Spacer(modifier = Modifier.height(10.dp))

                TelegramOutlinedField(
                    value = lastName,
                    onValueChange = { lastName = it },
                    label = "Фамилия (необязательно)"
                )
                Spacer(modifier = Modifier.height(10.dp))

                TelegramOutlinedField(
                    value = emailOrHandle,
                    onValueChange = { emailOrHandle = it },
                    label = "Email или @username",
                    placeholder = "user@mail.com",
                    modifier = Modifier.testTag("new_contact_email")
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { syncPhone = !syncPhone },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = syncPhone,
                        onCheckedChange = { syncPhone = it },
                        colors = CheckboxDefaults.colors(checkedColor = TgBlue)
                    )
                    Text(
                        text = "Синхронизировать с устройством",
                        color = palette.textPrimary,
                        fontSize = 14.sp
                    )
                }

                HorizontalDivider(color = palette.divider, thickness = 0.5.dp, modifier = Modifier.padding(vertical = 8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            showNewContactSheet = false
                            onShowToast("Сканер QR-кода открыт")
                        }
                        .padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.QrCode2, contentDescription = null, tint = TgBlue, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Добавить по QR-коду", color = TgBlue, fontWeight = FontWeight.SemiBold)
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        if (firstName.isNotBlank()) {
                            onCreateContact(firstName, lastName, emailOrHandle)
                            showNewContactSheet = false
                        }
                    },
                    enabled = firstName.isNotBlank(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TgBlue),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("create_contact_submit")
                ) {
                    Text("Создать контакт", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.5.sp)
                }
            }
        }
    }
}
