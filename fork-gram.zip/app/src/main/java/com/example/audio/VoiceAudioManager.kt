package com.example.audio

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.media.PlaybackParams
import android.os.Build
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import kotlin.math.sin

data class VoicePlaybackState(
    val playingMessageId: String? = null,
    val progress: Float = 0f,
    val isPlaying: Boolean = false,
    val playbackSpeed: Float = 1f
)

data class VoiceRecordingState(
    val isRecording: Boolean = false,
    val durationSec: Int = 0,
    val liveAmplitudes: List<Float> = emptyList()
)

class VoiceAudioManager(private val context: Context) {
    private val scope = CoroutineScope(Dispatchers.Main)

    private var recorder: MediaRecorder? = null
    private var currentOutputFile: File? = null
    private var recordJob: Job? = null
    private var hasHardwareRecorder = false

    private var player: MediaPlayer? = null
    private var playJob: Job? = null
    private var currentTotalMs: Long = 1000L
    private var currentElapsedMs: Long = 0L

    private val _recordingState = MutableStateFlow(VoiceRecordingState())
    val recordingState: StateFlow<VoiceRecordingState> = _recordingState.asStateFlow()

    private val _playbackState = MutableStateFlow(VoicePlaybackState())
    val playbackState: StateFlow<VoicePlaybackState> = _playbackState.asStateFlow()

    fun startRecording(hasMicPermission: Boolean) {
        if (_recordingState.value.isRecording) return
        stopPlayback()

        val voiceDir = File(context.filesDir, "voice").apply { mkdirs() }
        val outputFile = File(voiceDir, "voice_${UUID.randomUUID()}.m4a")
        currentOutputFile = outputFile
        hasHardwareRecorder = false

        if (hasMicPermission) {
            try {
                val r = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    MediaRecorder(context)
                } else {
                    @Suppress("DEPRECATION")
                    MediaRecorder()
                }
                r.apply {
                    setAudioSource(MediaRecorder.AudioSource.MIC)
                    setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                    setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                    setAudioEncodingBitRate(64000)
                    setAudioSamplingRate(22050)
                    setOutputFile(outputFile.absolutePath)
                    prepare()
                    start()
                }
                recorder = r
                hasHardwareRecorder = true
            } catch (_: Exception) {
                recorder?.release()
                recorder = null
                hasHardwareRecorder = false
            }
        }

        _recordingState.value = VoiceRecordingState(
            isRecording = true,
            durationSec = 0,
            liveAmplitudes = listOf(0.25f)
        )

        recordJob = scope.launch {
            var ticks = 0
            while (isActive && _recordingState.value.isRecording) {
                delay(150L)
                ticks++
                val amp = if (hasHardwareRecorder) {
                    try {
                        val raw = recorder?.maxAmplitude ?: 0
                        ((raw / 16000f).coerceIn(0.15f, 1.0f))
                    } catch (_: Exception) {
                        0.3f
                    }
                } else {
                    (0.25f + 0.55f * kotlin.math.abs(sin(ticks * 0.65))).toFloat()
                }
                val current = _recordingState.value
                val nextAmps = (current.liveAmplitudes + amp).takeLast(32)
                _recordingState.value = current.copy(
                    durationSec = (ticks * 150) / 1000,
                    liveAmplitudes = nextAmps
                )
            }
        }
    }

    data class RecordedVoiceResult(
        val filePath: String?,
        val durationSec: Int,
        val waveform: List<Float>
    )

    fun stopRecording(save: Boolean): RecordedVoiceResult? {
        recordJob?.cancel()
        recordJob = null

        val snapshot = _recordingState.value
        _recordingState.value = VoiceRecordingState()

        if (hasHardwareRecorder) {
            try {
                recorder?.stop()
            } catch (_: Exception) {
            } finally {
                recorder?.release()
                recorder = null
            }
        }

        val file = currentOutputFile
        currentOutputFile = null

        if (!save) {
            file?.delete()
            return null
        }

        val finalDuration = snapshot.durationSec.coerceAtLeast(1)
        val normalizedWaveform = normalizeWaveform(snapshot.liveAmplitudes)
        val validPath = if (hasHardwareRecorder && file != null && file.exists() && file.length() > 0L) {
            file.absolutePath
        } else {
            file?.delete()
            null
        }
        return RecordedVoiceResult(
            filePath = validPath,
            durationSec = finalDuration,
            waveform = normalizedWaveform
        )
    }

    fun cyclePlaybackSpeed(): Float {
        val currentSpeed = _playbackState.value.playbackSpeed
        val nextSpeed = when {
            currentSpeed < 1.25f -> 1.5f
            currentSpeed < 1.75f -> 2.0f
            else -> 1.0f
        }
        _playbackState.value = _playbackState.value.copy(playbackSpeed = nextSpeed)
        try {
            player?.let { mp ->
                if (mp.isPlaying) {
                    mp.playbackParams = PlaybackParams().setSpeed(nextSpeed)
                }
            }
        } catch (_: Exception) {
        }
        return nextSpeed
    }

    fun seekTo(messageId: String, fraction: Float) {
        val clamped = fraction.coerceIn(0f, 1f)
        if (_playbackState.value.playingMessageId != messageId) return
        val mp = player
        if (mp != null) {
            try {
                val targetMs = (mp.duration * clamped).toInt().coerceIn(0, mp.duration)
                mp.seekTo(targetMs)
            } catch (_: Exception) {
            }
        } else {
            currentElapsedMs = (currentTotalMs * clamped).toLong()
        }
        _playbackState.value = _playbackState.value.copy(progress = clamped)
    }

    fun togglePlayback(messageId: String, filePath: String?, durationSec: Int) {
        val current = _playbackState.value
        val activeSpeed = current.playbackSpeed
        if (current.playingMessageId == messageId && current.isPlaying) {
            stopPlayback()
            return
        }
        stopPlayback()

        scope.launch {
            val resolvedFile = resolveLocalOrCachedVoiceFile(filePath)
            if (resolvedFile != null && resolvedFile.exists()) {
                try {
                    val mp = MediaPlayer().apply {
                        setDataSource(resolvedFile.absolutePath)
                        prepare()
                        if (activeSpeed != 1f) {
                            playbackParams = PlaybackParams().setSpeed(activeSpeed)
                        }
                        start()
                    }
                    player = mp
                    _playbackState.value = VoicePlaybackState(
                        playingMessageId = messageId,
                        progress = 0f,
                        isPlaying = true,
                        playbackSpeed = activeSpeed
                    )
                    mp.setOnCompletionListener {
                        stopPlayback()
                    }
                    playJob = scope.launch {
                        while (isActive && player != null) {
                            val p = player ?: break
                            if (p.isPlaying && p.duration > 0) {
                                _playbackState.value = _playbackState.value.copy(
                                    playingMessageId = messageId,
                                    progress = (p.currentPosition.toFloat() / p.duration.toFloat()).coerceIn(0f, 1f),
                                    isPlaying = true
                                )
                            }
                            delay(80L)
                        }
                    }
                    return@launch
                } catch (_: Exception) {
                    player?.release()
                    player = null
                }
            }

            currentTotalMs = (durationSec.coerceAtLeast(1) * 1000L)
            currentElapsedMs = 0L
            _playbackState.value = VoicePlaybackState(
                playingMessageId = messageId,
                progress = 0f,
                isPlaying = true,
                playbackSpeed = activeSpeed
            )
            playJob = scope.launch {
                while (isActive && currentElapsedMs < currentTotalMs) {
                    delay(80L)
                    currentElapsedMs += (80L * _playbackState.value.playbackSpeed).toLong().coerceAtLeast(80L)
                    _playbackState.value = _playbackState.value.copy(
                        playingMessageId = messageId,
                        progress = (currentElapsedMs.toFloat() / currentTotalMs.toFloat()).coerceIn(0f, 1f),
                        isPlaying = true
                    )
                }
                stopPlayback()
            }
        }
    }

    fun stopPlayback() {
        val keepSpeed = _playbackState.value.playbackSpeed
        playJob?.cancel()
        playJob = null
        try {
            player?.stop()
        } catch (_: Exception) {
        }
        player?.release()
        player = null
        _playbackState.value = VoicePlaybackState(playbackSpeed = keepSpeed)
    }

    private suspend fun resolveLocalOrCachedVoiceFile(pathOrUrl: String?): File? {
        if (pathOrUrl.isNullOrBlank()) return null
        if (!pathOrUrl.startsWith("http://") && !pathOrUrl.startsWith("https://")) {
            return File(pathOrUrl).takeIf { it.exists() && it.length() > 0L }
        }
        return withContext(Dispatchers.IO) {
            runCatching {
                val cacheDir = File(context.cacheDir, "voice_cache").apply { mkdirs() }
                val cached = File(cacheDir, "v_${pathOrUrl.hashCode()}.m4a")
                if (cached.exists() && cached.length() > 0L) return@runCatching cached
                val conn = (URL(pathOrUrl).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 5000
                    readTimeout = 8000
                }
                if (conn.responseCode in 200..299) {
                    conn.inputStream.use { input ->
                        cached.outputStream().use { out -> input.copyTo(out) }
                    }
                    conn.disconnect()
                    cached.takeIf { it.exists() && it.length() > 0L }
                } else {
                    conn.disconnect()
                    null
                }
            }.getOrNull()
        }
    }

    private fun normalizeWaveform(samples: List<Float>): List<Float> {
        val count = 24
        if (samples.isEmpty()) {
            return List(count) { idx -> 0.25f + ((idx * 17) % 7) * 0.1f }
        }
        return List(count) { i ->
            val srcIdx = (i * samples.size) / count
            samples[srcIdx.coerceIn(0, samples.lastIndex)].coerceIn(0.15f, 1.0f)
        }
    }
}
