package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface UserAccountDao {
    @Query("SELECT * FROM user_accounts WHERE email = :email LIMIT 1")
    fun observeAccount(email: String): Flow<UserAccountEntity?>

    @Query("SELECT * FROM user_accounts WHERE email = :email LIMIT 1")
    suspend fun getAccount(email: String): UserAccountEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAccount(account: UserAccountEntity)
}

@Dao
interface ChatFolderDao {
    @Query("SELECT * FROM chat_folders WHERE ownerEmail = :ownerEmail ORDER BY orderIndex ASC")
    fun observeFolders(ownerEmail: String): Flow<List<ChatFolderEntity>>

    @Query("SELECT COUNT(*) FROM chat_folders WHERE ownerEmail = :ownerEmail")
    suspend fun countFolders(ownerEmail: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertFolder(folder: ChatFolderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertFolders(folders: List<ChatFolderEntity>)

    @Query("DELETE FROM chat_folders WHERE id = :id")
    suspend fun deleteFolder(id: String)
}

@Dao
interface ChatThreadDao {
    @Query("SELECT * FROM chat_threads WHERE ownerEmail = :ownerEmail ORDER BY isPinned DESC, lastMessageTimestamp DESC")
    fun observeChats(ownerEmail: String): Flow<List<ChatThreadEntity>>

    @Query("SELECT * FROM chat_threads WHERE id = :chatId LIMIT 1")
    fun observeChat(chatId: String): Flow<ChatThreadEntity?>

    @Query("SELECT * FROM chat_threads WHERE id = :chatId LIMIT 1")
    suspend fun getChat(chatId: String): ChatThreadEntity?

    @Query("SELECT COUNT(*) FROM chat_threads WHERE ownerEmail = :ownerEmail")
    suspend fun countChats(ownerEmail: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertChat(chat: ChatThreadEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertChats(chats: List<ChatThreadEntity>)

    @Query("DELETE FROM chat_threads WHERE id = :chatId")
    suspend fun deleteChat(chatId: String)
}

@Dao
interface ChatMessageDao {
    @Query("SELECT * FROM chat_messages WHERE chatId = :chatId ORDER BY timestampMillis ASC")
    fun observeMessages(chatId: String): Flow<List<ChatMessageEntity>>

    @Query("SELECT * FROM chat_messages WHERE id = :id LIMIT 1")
    suspend fun getMessage(id: String): ChatMessageEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMessage(message: ChatMessageEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMessages(messages: List<ChatMessageEntity>)

    @Query("SELECT * FROM chat_messages WHERE chatId = :chatId ORDER BY timestampMillis DESC LIMIT 1")
    suspend fun getLatestMessage(chatId: String): ChatMessageEntity?

    @Query("UPDATE chat_messages SET isRead = 1 WHERE chatId = :chatId AND isOutgoing = 1")
    suspend fun markOutgoingRead(chatId: String)

    @Query("DELETE FROM chat_messages WHERE id = :id")
    suspend fun deleteMessage(id: String)

    @Query("DELETE FROM chat_messages WHERE chatId = :chatId")
    suspend fun clearChatMessages(chatId: String)
}

@Dao
interface ContactDao {
    @Query("SELECT * FROM contacts WHERE ownerEmail = :ownerEmail ORDER BY firstName ASC")
    fun observeContacts(ownerEmail: String): Flow<List<ContactEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertContact(contact: ContactEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertContacts(contacts: List<ContactEntity>)

    @Query("DELETE FROM contacts WHERE id = :id")
    suspend fun deleteContact(id: String)
}

@Dao
interface OwnedGiftDao {
    @Query("SELECT * FROM owned_gifts WHERE ownerEmail = :ownerEmail ORDER BY isPinned DESC, receivedAt DESC")
    fun observeGifts(ownerEmail: String): Flow<List<OwnedGiftEntity>>

    @Query("SELECT * FROM owned_gifts WHERE id = :id LIMIT 1")
    suspend fun getGift(id: String): OwnedGiftEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertGift(gift: OwnedGiftEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertGifts(gifts: List<OwnedGiftEntity>)

    @Query("DELETE FROM owned_gifts WHERE id = :id")
    suspend fun deleteGift(id: String)

    @Query("UPDATE owned_gifts SET isWornAsStatus = 0 WHERE ownerEmail = :ownerEmail")
    suspend fun clearWornStatus(ownerEmail: String)
}

@Dao
interface GiftCollectionDao {
    @Query("SELECT * FROM gift_collections WHERE ownerEmail = :ownerEmail ORDER BY createdAt ASC")
    fun observeCollections(ownerEmail: String): Flow<List<GiftCollectionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCollection(collection: GiftCollectionEntity)

    @Query("DELETE FROM gift_collections WHERE id = :id")
    suspend fun deleteCollection(id: String)
}

@Dao
interface NftUsernameDao {
    @Query("SELECT * FROM nft_usernames WHERE ownerEmail = :ownerEmail ORDER BY isOwned DESC, priceGram ASC")
    fun observeNftUsernames(ownerEmail: String): Flow<List<NftUsernameEntity>>

    @Query("SELECT * FROM nft_usernames WHERE id = :id LIMIT 1")
    suspend fun getNftUsername(id: String): NftUsernameEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertNftUsername(item: NftUsernameEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertNftUsernames(items: List<NftUsernameEntity>)

    @Query("UPDATE nft_usernames SET isEquipped = 0 WHERE ownerEmail = :ownerEmail")
    suspend fun unequipAll(ownerEmail: String)

    @Query("DELETE FROM nft_usernames WHERE ownerEmail = :ownerEmail")
    suspend fun clearForOwner(ownerEmail: String)
}

@Dao
interface WalletTransactionDao {
    @Query("SELECT * FROM wallet_transactions WHERE ownerEmail = :ownerEmail ORDER BY timestampMillis DESC")
    fun observeTransactions(ownerEmail: String): Flow<List<WalletTransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(tx: WalletTransactionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransactions(txs: List<WalletTransactionEntity>)
}

@Dao
interface ProfilePostDao {
    @Query("SELECT * FROM profile_posts WHERE ownerEmail = :ownerEmail ORDER BY createdAt DESC")
    fun observePosts(ownerEmail: String): Flow<List<ProfilePostEntity>>

    @Query("SELECT * FROM profile_posts WHERE id = :id LIMIT 1")
    suspend fun getPost(id: String): ProfilePostEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPost(post: ProfilePostEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPosts(posts: List<ProfilePostEntity>)

    @Query("DELETE FROM profile_posts WHERE id = :id")
    suspend fun deletePost(id: String)
}
