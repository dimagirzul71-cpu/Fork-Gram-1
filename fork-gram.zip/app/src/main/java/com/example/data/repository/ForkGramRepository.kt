package com.example.data.repository

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.data.local.AppPreferencesState
import com.example.data.local.ChatFolderEntity
import com.example.data.local.ChatMessageEntity
import com.example.data.local.ChatThreadEntity
import com.example.data.local.ContactEntity
import com.example.data.local.ForkGramDatabase
import com.example.data.local.GiftCollectionEntity
import com.example.data.local.NftUsernameEntity
import com.example.data.local.OwnedGiftEntity
import com.example.data.local.ProfilePostEntity
import com.example.data.local.UserAccountEntity
import com.example.data.local.UserPreferences
import com.example.data.local.WalletTransactionEntity
import com.example.data.local.toDomain
import com.example.data.model.ChatFolder
import com.example.data.model.ChatMessage
import com.example.data.model.ChatThread
import com.example.data.model.ChatType
import com.example.data.model.ContactItem
import com.example.data.model.DeviceSession
import com.example.data.model.FragmentMarketPayload
import com.example.data.model.FragmentNftGiftListing
import com.example.data.model.GiftBackdrop
import com.example.data.model.GiftCollectionTab
import com.example.data.model.GiftKind
import com.example.data.model.GiftRarity
import com.example.data.model.GiftSymbol
import com.example.data.model.MessageKind
import com.example.data.model.NftUsernameItem
import com.example.data.model.OwnedGift
import com.example.data.model.PeerProfileData
import com.example.data.model.PollData
import com.example.data.model.PollOption
import com.example.data.model.ProfilePost
import com.example.data.model.UserAccount
import com.example.data.model.WalletTransaction
import com.example.data.remote.ForkGramRemoteApi
import com.example.data.remote.RemoteDirectoryUser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class ForkGramRepository(
    private val context: Context,
    private val db: ForkGramDatabase,
    val preferences: UserPreferences,
    private val remoteApi: ForkGramRemoteApi? = ForkGramRemoteApi()
) {
    private val accountDao = db.userAccountDao()
    private val folderDao = db.chatFolderDao()
    private val chatDao = db.chatThreadDao()
    private val messageDao = db.chatMessageDao()
    private val contactDao = db.contactDao()
    private val giftDao = db.ownedGiftDao()
    private val collectionDao = db.giftCollectionDao()
    private val nftUsernameDao = db.nftUsernameDao()
    private val txDao = db.walletTransactionDao()
    private val postDao = db.profilePostDao()

    private val _sessions = MutableStateFlow<List<DeviceSession>>(emptyList())
    val sessionsFlow: StateFlow<List<DeviceSession>> = _sessions.asStateFlow()

    private val _fragmentGiftListings = MutableStateFlow<List<FragmentNftGiftListing>>(emptyList())
    val fragmentGiftListingsFlow: StateFlow<List<FragmentNftGiftListing>> = _fragmentGiftListings.asStateFlow()

    val prefsFlow: Flow<AppPreferencesState> = preferences.state

    fun observeAccount(email: String): Flow<UserAccount?> =
        accountDao.observeAccount(email).map { it?.toDomain() }

    fun observeFolders(email: String): Flow<List<ChatFolder>> =
        folderDao.observeFolders(email).map { list -> list.map { it.toDomain() } }

    fun observeChats(email: String): Flow<List<ChatThread>> =
        chatDao.observeChats(email).map { list -> list.map { it.toDomain() } }

    fun observeChat(chatId: String): Flow<ChatThread?> =
        chatDao.observeChat(chatId).map { it?.toDomain() }

    fun observeMessages(chatId: String): Flow<List<ChatMessage>> =
        messageDao.observeMessages(chatId).map { list -> list.map { it.toDomain() } }

    fun observeContacts(email: String): Flow<List<ContactItem>> =
        contactDao.observeContacts(email).map { list -> list.map { it.toDomain() } }

    fun observeGifts(email: String): Flow<List<OwnedGift>> =
        giftDao.observeGifts(email).map { list -> list.map { it.toDomain() } }

    fun observeGiftCollections(email: String): Flow<List<GiftCollectionTab>> =
        collectionDao.observeCollections(email).map { list -> list.map { it.toDomain() } }

    fun observeNftUsernames(email: String): Flow<List<NftUsernameItem>> =
        nftUsernameDao.observeNftUsernames(email).map { list -> list.map { it.toDomain() } }

    fun observeTransactions(email: String): Flow<List<WalletTransaction>> =
        txDao.observeTransactions(email).map { list -> list.map { it.toDomain() } }

    fun observeProfilePosts(email: String): Flow<List<ProfilePost>> =
        postDao.observePosts(email).map { list -> list.map { it.toDomain() } }

    suspend fun checkExistingAccount(email: String): UserAccount? {
        val clean = email.trim().lowercase()
        val local = accountDao.getAccount(clean)?.toDomain()
        if (local != null) return local
        val remote = remoteApi?.checkAccount(clean) ?: return null
        return remote.toDomain()
    }

    suspend fun completeAuthOrRegister(
        rawEmail: String,
        firstName: String,
        lastName: String,
        avatarUri: String?
    ): UserAccount {
        val email = rawEmail.trim().lowercase()
        val now = System.currentTimeMillis()
        val timeText = formatTime(now)
        val existing = accountDao.getAccount(email)

        val savedAvatar = if (!avatarUri.isNullOrBlank() && avatarUri.startsWith("content://")) {
            copyUriToAppStorage(Uri.parse(avatarUri), "avatars", "avatar_${email.hashCode()}.jpg")
        } else {
            avatarUri
        }
        val uploadedAvatarUrl = if (!savedAvatar.isNullOrBlank() && !savedAvatar.startsWith("http")) {
            uploadLocalFile(savedAvatar, "avatar_${email.hashCode()}.jpg") ?: savedAvatar
        } else {
            savedAvatar
        }
        val sessionId = runCatching { preferences.ensureDeviceSessionId() }.getOrNull()
        val remoteAccount = remoteApi?.authOrRegister(email, firstName, lastName, uploadedAvatarUrl, sessionId)

        val accountEntity = if (existing != null) {
            existing.copy(
                firstName = firstName.ifBlank { existing.firstName },
                lastName = lastName,
                avatarUri = savedAvatar ?: existing.avatarUri
            )
        } else if (remoteAccount != null) {
            remoteAccount.copy(
                firstName = firstName.ifBlank { remoteAccount.firstName },
                lastName = lastName.ifBlank { remoteAccount.lastName },
                avatarUri = savedAvatar ?: remoteAccount.avatarUri
            )
        } else {
            val baseHandle = email.substringBefore("@")
                .replace(Regex("[^a-zA-Z0-9_]"), "")
                .take(16)
                .ifBlank { "forkuser" }
            UserAccountEntity(
                email = email,
                firstName = firstName.ifBlank { "Пользователь" },
                lastName = lastName,
                username = "@$baseHandle",
                activeNftUsername = null,
                bio = "На связи в Fork Gram",
                birthday = "",
                avatarUri = savedAvatar,
                isPremium = true,
                starsBalance = 1000L,
                gramBalance = 100.0,
                level = 1,
                statusGiftKindId = null,
                statusBackdropId = null,
                statusSymbolId = null,
                createdAt = now
            )
        }
        accountDao.upsertAccount(accountEntity)

        if (chatDao.countChats(email) == 0) {
            seedWorkspaceForAccount(email, accountEntity.firstName, now, timeText)
        } else {
            val serviceChatId = "${email}_service"
            val loginMsg = ChatMessageEntity(
                id = UUID.randomUUID().toString(),
                ownerEmail = email,
                chatId = serviceChatId,
                senderName = "Fork Gram",
                isOutgoing = false,
                kindName = MessageKind.TEXT.name,
                text = "Welcome to Fork Gram!\n\nA new sign-in to your account was just completed using your email ($email).\n\nIf this was you, no action is needed.",
                timestampText = timeText,
                timestampMillis = now,
                dateGroup = formatDateGroup(now),
                replyToId = null,
                replyPreviewSender = null,
                replyPreviewText = null,
                forwardedFrom = null,
                mediaUri = null,
                fileName = null,
                fileSizeText = null,
                voiceDurationSec = 0,
                voiceWaveformCsv = "",
                giftKindId = null,
                giftNumber = null,
                giftStarsValue = 0,
                isNftGift = false,
                gramAmount = 0.0,
                reactionKey = null,
                isEdited = false,
                isPinned = false,
                isRead = false
            )
            messageDao.upsertMessage(loginMsg)
            chatDao.getChat(serviceChatId)?.let { chat ->
                chatDao.upsertChat(
                    chat.copy(
                        lastMessagePreview = "Welcome to Fork Gram! A new sign-in to your account...",
                        lastMessageTime = timeText,
                        lastMessageTimestamp = now,
                        unreadCount = chat.unreadCount + 1
                    )
                )
            }
        }

        preferences.setActiveEmail(email)
        refreshFragmentMarket(email)
        return accountEntity.toDomain()
    }

    suspend fun logout() {
        preferences.setActiveEmail(null)
    }

    suspend fun updateProfile(
        email: String,
        firstName: String,
        lastName: String,
        username: String,
        bio: String,
        birthday: String? = null,
        avatarUri: String? = null
    ) {
        val current = accountDao.getAccount(email) ?: return
        val normalizedHandle = username.trim().let { if (it.startsWith("@")) it else "@$it" }
        val savedAvatar = if (!avatarUri.isNullOrBlank() && avatarUri.startsWith("content://")) {
            copyUriToAppStorage(Uri.parse(avatarUri), "avatars", "avatar_${UUID.randomUUID()}.jpg")
        } else {
            avatarUri ?: current.avatarUri
        }
        val remoteAvatar = if (!savedAvatar.isNullOrBlank() && !savedAvatar.startsWith("http")) {
            uploadLocalFile(savedAvatar, "avatar_${UUID.randomUUID()}.jpg") ?: savedAvatar
        } else {
            savedAvatar
        }
        val updated = current.copy(
            firstName = firstName.trim().ifBlank { current.firstName },
            lastName = lastName.trim(),
            username = normalizedHandle.ifBlank { current.username },
            bio = bio.trim(),
            birthday = birthday?.trim() ?: current.birthday,
            avatarUri = remoteAvatar
        )
        accountDao.upsertAccount(updated)
        remoteApi?.updateProfile(updated)
    }

    suspend fun markChatRead(chatId: String) {
        val chat = chatDao.getChat(chatId) ?: return
        if (chat.unreadCount > 0) {
            chatDao.upsertChat(chat.copy(unreadCount = 0))
        }
        val peerEmail = chat.email?.takeIf { it.contains("@") } ?: return
        remoteApi?.markRead(chat.ownerEmail, peerEmail)
    }

    suspend fun saveChatDraft(chatId: String, draft: String) {
        val chat = chatDao.getChat(chatId) ?: return
        val clean = draft.trimEnd()
        if (chat.draftText != clean) {
            chatDao.upsertChat(chat.copy(draftText = clean))
        }
    }

    suspend fun sendTextMessage(
        ownerEmail: String,
        chatId: String,
        text: String,
        replyTo: ChatMessage? = null,
        isSilent: Boolean = false,
        scheduleDelayMinutes: Int = 0
    ) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return
        val now = System.currentTimeMillis()
        val effectiveTs = if (scheduleDelayMinutes > 0) now + scheduleDelayMinutes * 60_000L else now
        val baseTime = formatTime(effectiveTs)
        val timeText = when {
            scheduleDelayMinutes > 0 -> "⏰ $baseTime"
            isSilent -> "🔇 $baseTime"
            else -> baseTime
        }
        val sender = accountDao.getAccount(ownerEmail)?.firstName ?: "Я"

        val msg = ChatMessageEntity(
            id = UUID.randomUUID().toString(),
            ownerEmail = ownerEmail,
            chatId = chatId,
            senderName = sender,
            isOutgoing = true,
            kindName = MessageKind.TEXT.name,
            text = trimmed,
            timestampText = timeText,
            timestampMillis = effectiveTs,
            dateGroup = formatDateGroup(effectiveTs),
            replyToId = replyTo?.id,
            replyPreviewSender = replyTo?.senderName,
            replyPreviewText = replyTo?.previewSummary(),
            forwardedFrom = null,
            mediaUri = null,
            fileName = null,
            fileSizeText = null,
            voiceDurationSec = 0,
            voiceWaveformCsv = "",
            giftKindId = null,
            giftNumber = null,
            giftStarsValue = 0,
            isNftGift = false,
            gramAmount = 0.0,
            reactionKey = null,
            isEdited = false,
            isPinned = false,
            isRead = false
        )
        messageDao.upsertMessage(msg)
        updateChatPreview(chatId, trimmed, timeText, effectiveTs, isOutgoing = true, isRead = false)
        val recipientEmail = chatDao.getChat(chatId)?.email
        if (!recipientEmail.isNullOrBlank() && recipientEmail.contains("@")) {
            remoteApi?.sendMessage(ownerEmail, recipientEmail, msg)
        } else {
            messageDao.upsertMessage(msg.copy(isRead = true))
            updateChatPreview(chatId, trimmed, timeText, effectiveTs, isOutgoing = true, isRead = true)
        }
    }

    suspend fun sendPollMessage(
        ownerEmail: String,
        chatId: String,
        question: String,
        options: List<String>
    ) {
        val cleanQ = question.trim()
        val cleanOpts = options.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        if (cleanQ.isBlank() || cleanOpts.size < 2) return
        val now = System.currentTimeMillis()
        val timeText = formatTime(now)
        val sender = accountDao.getAccount(ownerEmail)?.firstName ?: "Я"
        val pollJson = PollData(
            question = cleanQ,
            options = cleanOpts.map { PollOption(text = it, voters = emptyList()) }
        ).toJsonString()

        val msg = ChatMessageEntity(
            id = UUID.randomUUID().toString(),
            ownerEmail = ownerEmail,
            chatId = chatId,
            senderName = sender,
            isOutgoing = true,
            kindName = MessageKind.POLL.name,
            text = pollJson,
            timestampText = timeText,
            timestampMillis = now,
            dateGroup = formatDateGroup(now),
            replyToId = null,
            replyPreviewSender = null,
            replyPreviewText = null,
            forwardedFrom = null,
            mediaUri = null,
            fileName = null,
            fileSizeText = null,
            voiceDurationSec = 0,
            voiceWaveformCsv = "",
            giftKindId = null,
            giftNumber = null,
            giftStarsValue = 0,
            isNftGift = false,
            gramAmount = 0.0,
            reactionKey = null,
            isEdited = false,
            isPinned = false,
            isRead = false
        )
        messageDao.upsertMessage(msg)
        updateChatPreview(chatId, "Опрос: $cleanQ", timeText, now, isOutgoing = true, isRead = false)
        val recipientEmail = chatDao.getChat(chatId)?.email
        if (!recipientEmail.isNullOrBlank() && recipientEmail.contains("@")) {
            remoteApi?.sendMessage(ownerEmail, recipientEmail, msg)
        } else {
            messageDao.upsertMessage(msg.copy(isRead = true))
        }
    }

    suspend fun votePoll(ownerEmail: String, messageId: String, optionIndex: Int) {
        val existing = messageDao.getMessage(messageId) ?: return
        val current = PollData.fromJson(existing.text) ?: return
        if (optionIndex !in current.options.indices) return
        val cleanEmail = ownerEmail.trim().lowercase()
        val updatedOptions = current.options.mapIndexed { idx, opt ->
            val filtered = opt.voters.filterNot { it.equals(cleanEmail, ignoreCase = true) }
            if (idx == optionIndex && !opt.voters.any { it.equals(cleanEmail, ignoreCase = true) }) {
                opt.copy(voters = filtered + cleanEmail)
            } else {
                opt.copy(voters = filtered)
            }
        }
        val localUpdatedJson = current.copy(options = updatedOptions).toJsonString()
        messageDao.upsertMessage(existing.copy(text = localUpdatedJson))
        val remoteText = remoteApi?.votePoll(messageId, cleanEmail, optionIndex)
        if (!remoteText.isNullOrBlank()) {
            messageDao.upsertMessage(existing.copy(text = remoteText))
        }
    }

    suspend fun sendPhotoMessage(
        ownerEmail: String,
        chatId: String,
        sourceUri: Uri,
        caption: String,
        replyTo: ChatMessage? = null
    ) {
        val copiedPath = copyUriToAppStorage(sourceUri, "media", "photo_${UUID.randomUUID()}.jpg") ?: return
        val uploadedUrl = uploadLocalFile(copiedPath, "photo_${UUID.randomUUID()}.jpg") ?: copiedPath
        val now = System.currentTimeMillis()
        val timeText = formatTime(now)
        val sender = accountDao.getAccount(ownerEmail)?.firstName ?: "Я"
        val preview = if (caption.isNotBlank()) "Фотография: $caption" else "Фотография"

        val msg = ChatMessageEntity(
            id = UUID.randomUUID().toString(),
            ownerEmail = ownerEmail,
            chatId = chatId,
            senderName = sender,
            isOutgoing = true,
            kindName = MessageKind.PHOTO.name,
            text = caption.trim(),
            timestampText = timeText,
            timestampMillis = now,
            dateGroup = formatDateGroup(now),
            replyToId = replyTo?.id,
            replyPreviewSender = replyTo?.senderName,
            replyPreviewText = replyTo?.previewSummary(),
            forwardedFrom = null,
            mediaUri = uploadedUrl,
            fileName = null,
            fileSizeText = null,
            voiceDurationSec = 0,
            voiceWaveformCsv = "",
            giftKindId = null,
            giftNumber = null,
            giftStarsValue = 0,
            isNftGift = false,
            gramAmount = 0.0,
            reactionKey = null,
            isEdited = false,
            isPinned = false,
            isRead = false
        )
        messageDao.upsertMessage(msg)
        updateChatPreview(chatId, preview, timeText, now, isOutgoing = true, isRead = false)
        chatDao.getChat(chatId)?.email?.takeIf { it.contains("@") }?.let { recip ->
            remoteApi?.sendMessage(ownerEmail, recip, msg)
        }
    }

    suspend fun sendFileMessage(
        ownerEmail: String,
        chatId: String,
        sourceUri: Uri
    ) {
        val meta = queryFileMeta(sourceUri)
        val copiedPath = copyUriToAppStorage(sourceUri, "files", "doc_${UUID.randomUUID()}_${meta.first}")
        val uploadedUrl = copiedPath?.let { uploadLocalFile(it, meta.first) ?: it }
        val now = System.currentTimeMillis()
        val timeText = formatTime(now)
        val sender = accountDao.getAccount(ownerEmail)?.firstName ?: "Я"

        val msg = ChatMessageEntity(
            id = UUID.randomUUID().toString(),
            ownerEmail = ownerEmail,
            chatId = chatId,
            senderName = sender,
            isOutgoing = true,
            kindName = MessageKind.FILE.name,
            text = meta.first,
            timestampText = timeText,
            timestampMillis = now,
            dateGroup = formatDateGroup(now),
            replyToId = null,
            replyPreviewSender = null,
            replyPreviewText = null,
            forwardedFrom = null,
            mediaUri = uploadedUrl,
            fileName = meta.first,
            fileSizeText = meta.second,
            voiceDurationSec = 0,
            voiceWaveformCsv = "",
            giftKindId = null,
            giftNumber = null,
            giftStarsValue = 0,
            isNftGift = false,
            gramAmount = 0.0,
            reactionKey = null,
            isEdited = false,
            isPinned = false,
            isRead = false
        )
        messageDao.upsertMessage(msg)
        updateChatPreview(chatId, "Файл: ${meta.first}", timeText, now, isOutgoing = true, isRead = false)
        chatDao.getChat(chatId)?.email?.takeIf { it.contains("@") }?.let { recip ->
            remoteApi?.sendMessage(ownerEmail, recip, msg)
        }
    }

    suspend fun sendVoiceMessage(
        ownerEmail: String,
        chatId: String,
        filePath: String?,
        durationSec: Int,
        waveform: List<Float>
    ) {
        val uploadedVoiceUrl = filePath?.let { uploadLocalFile(it, "voice_${UUID.randomUUID()}.m4a") ?: it }
        val now = System.currentTimeMillis()
        val timeText = formatTime(now)
        val sender = accountDao.getAccount(ownerEmail)?.firstName ?: "Я"

        val msg = ChatMessageEntity(
            id = UUID.randomUUID().toString(),
            ownerEmail = ownerEmail,
            chatId = chatId,
            senderName = sender,
            isOutgoing = true,
            kindName = MessageKind.VOICE.name,
            text = "Голосовое сообщение",
            timestampText = timeText,
            timestampMillis = now,
            dateGroup = formatDateGroup(now),
            replyToId = null,
            replyPreviewSender = null,
            replyPreviewText = null,
            forwardedFrom = null,
            mediaUri = uploadedVoiceUrl,
            fileName = null,
            fileSizeText = null,
            voiceDurationSec = durationSec.coerceAtLeast(1),
            voiceWaveformCsv = waveform.joinToString(",") { "%.2f".format(Locale.US, it) },
            giftKindId = null,
            giftNumber = null,
            giftStarsValue = 0,
            isNftGift = false,
            gramAmount = 0.0,
            reactionKey = null,
            isEdited = false,
            isPinned = false,
            isRead = false
        )
        messageDao.upsertMessage(msg)
        updateChatPreview(chatId, "Голосовое сообщение (${formatDuration(durationSec)})", timeText, now, isOutgoing = true, isRead = false)
        chatDao.getChat(chatId)?.email?.takeIf { it.contains("@") }?.let { recip ->
            remoteApi?.sendMessage(ownerEmail, recip, msg)
        }
    }

    suspend fun sendLocationMessage(
        ownerEmail: String,
        chatId: String,
        locationLabel: String
    ) {
        val now = System.currentTimeMillis()
        val timeText = formatTime(now)
        val sender = accountDao.getAccount(ownerEmail)?.firstName ?: "Я"
        val msg = ChatMessageEntity(
            id = UUID.randomUUID().toString(),
            ownerEmail = ownerEmail,
            chatId = chatId,
            senderName = sender,
            isOutgoing = true,
            kindName = MessageKind.LOCATION.name,
            text = locationLabel,
            timestampText = timeText,
            timestampMillis = now,
            dateGroup = formatDateGroup(now),
            replyToId = null,
            replyPreviewSender = null,
            replyPreviewText = null,
            forwardedFrom = null,
            mediaUri = null,
            fileName = null,
            fileSizeText = null,
            voiceDurationSec = 0,
            voiceWaveformCsv = "",
            giftKindId = null,
            giftNumber = null,
            giftStarsValue = 0,
            isNftGift = false,
            gramAmount = 0.0,
            reactionKey = null,
            isEdited = false,
            isPinned = false,
            isRead = false
        )
        messageDao.upsertMessage(msg)
        updateChatPreview(chatId, "Геопозиция: $locationLabel", timeText, now, isOutgoing = true, isRead = false)
        chatDao.getChat(chatId)?.email?.takeIf { it.contains("@") }?.let { recip ->
            remoteApi?.sendMessage(ownerEmail, recip, msg)
        }
    }

    suspend fun forwardMessage(
        ownerEmail: String,
        original: ChatMessage,
        targetChatId: String
    ) {
        val now = System.currentTimeMillis()
        val timeText = formatTime(now)
        val sender = accountDao.getAccount(ownerEmail)?.firstName ?: "Я"
        val fromName = original.forwardedFrom ?: original.senderName

        val forwarded = ChatMessageEntity(
            id = UUID.randomUUID().toString(),
            ownerEmail = ownerEmail,
            chatId = targetChatId,
            senderName = sender,
            isOutgoing = true,
            kindName = original.kind.name,
            text = original.text,
            timestampText = timeText,
            timestampMillis = now,
            dateGroup = formatDateGroup(now),
            replyToId = null,
            replyPreviewSender = null,
            replyPreviewText = null,
            forwardedFrom = fromName,
            mediaUri = original.mediaUri,
            fileName = original.fileName,
            fileSizeText = original.fileSizeText,
            voiceDurationSec = original.voiceDurationSec,
            voiceWaveformCsv = original.voiceWaveform.joinToString(","),
            giftKindId = original.giftKind?.id,
            giftNumber = original.giftNumber,
            giftStarsValue = original.giftStarsValue,
            isNftGift = original.isNftGift,
            gramAmount = original.gramAmount,
            reactionKey = null,
            isEdited = false,
            isPinned = false,
            isRead = false
        )
        messageDao.upsertMessage(forwarded)
        updateChatPreview(targetChatId, "Переслано: ${original.previewSummary()}", timeText, now, isOutgoing = true, isRead = false)
        chatDao.getChat(targetChatId)?.email?.takeIf { it.contains("@") }?.let { recip ->
            remoteApi?.sendMessage(ownerEmail, recip, forwarded)
        }
    }

    suspend fun editMessage(messageId: String, newText: String) {
        val existing = messageDao.getMessage(messageId) ?: return
        val trimmed = newText.trim()
        if (trimmed.isEmpty()) return
        messageDao.upsertMessage(existing.copy(text = trimmed, isEdited = true))
        val chat = chatDao.getChat(existing.chatId)
        val latest = messageDao.getLatestMessage(existing.chatId)
        if (chat != null && latest?.id == existing.id) {
            chatDao.upsertChat(chat.copy(lastMessagePreview = trimmed))
        }
        remoteApi?.editMessage(messageId, trimmed)
    }

    suspend fun deleteMessage(messageId: String) {
        val existing = messageDao.getMessage(messageId) ?: return
        messageDao.deleteMessage(messageId)
        val chat = chatDao.getChat(existing.chatId)
        if (chat != null) {
            val latest = messageDao.getLatestMessage(existing.chatId)
            chatDao.upsertChat(
                chat.copy(
                    pinnedMessageId = if (chat.pinnedMessageId == messageId) null else chat.pinnedMessageId,
                    lastMessagePreview = latest?.toDomain()?.previewSummary() ?: "Сообщений пока нет",
                    lastMessageTime = latest?.timestampText ?: chat.lastMessageTime,
                    lastMessageTimestamp = latest?.timestampMillis ?: chat.lastMessageTimestamp
                )
            )
        }
        remoteApi?.deleteMessage(messageId)
    }

    suspend fun togglePinMessage(chatId: String, messageId: String) {
        val msg = messageDao.getMessage(messageId) ?: return
        val chat = chatDao.getChat(chatId) ?: return
        val newPinned = !msg.isPinned
        messageDao.upsertMessage(msg.copy(isPinned = newPinned))
        chatDao.upsertChat(chat.copy(pinnedMessageId = if (newPinned) messageId else null))
    }

    suspend fun toggleReaction(messageId: String, reactionKey: String) {
        val msg = messageDao.getMessage(messageId) ?: return
        val next = if (msg.reactionKey == reactionKey) null else reactionKey
        messageDao.upsertMessage(msg.copy(reactionKey = next))
        remoteApi?.reactMessage(messageId, next)
    }

    suspend fun toggleArchiveChat(chatId: String) {
        val chat = chatDao.getChat(chatId) ?: return
        chatDao.upsertChat(chat.copy(isArchived = !chat.isArchived))
    }

    suspend fun togglePinChat(chatId: String) {
        val chat = chatDao.getChat(chatId) ?: return
        chatDao.upsertChat(chat.copy(isPinned = !chat.isPinned))
    }

    suspend fun toggleMuteChat(chatId: String) {
        val chat = chatDao.getChat(chatId) ?: return
        chatDao.upsertChat(chat.copy(isMuted = !chat.isMuted))
    }

    suspend fun toggleBlockChat(chatId: String) {
        val chat = chatDao.getChat(chatId) ?: return
        chatDao.upsertChat(chat.copy(isBlocked = !chat.isBlocked))
    }

    suspend fun setAutoDelete(chatId: String, seconds: Int) {
        val chat = chatDao.getChat(chatId) ?: return
        chatDao.upsertChat(chat.copy(autoDeleteSeconds = seconds))
    }

    suspend fun createContactAndChat(
        ownerEmail: String,
        firstName: String,
        lastName: String,
        contactEmailOrHandle: String
    ): String {
        val cleanFirst = firstName.trim().ifBlank { "Новый контакт" }
        val cleanLast = lastName.trim()
        val fullName = listOf(cleanFirst, cleanLast).filter { it.isNotBlank() }.joinToString(" ")
        val handle = contactEmailOrHandle.trim().let {
            if (it.contains("@") && !it.startsWith("@")) "@${it.substringBefore("@")}"
            else if (it.startsWith("@")) it
            else "@${cleanFirst.lowercase().replace(" ", "_")}"
        }
        val emailValue = if (contactEmailOrHandle.contains("@") && !contactEmailOrHandle.startsWith("@")) {
            contactEmailOrHandle.trim()
        } else {
            "${handle.removePrefix("@")}@forkgram.me"
        }

        val paletteColors = listOf(0xFF2AABEE, 0xFF8A63D2, 0xFF46B966, 0xFFF2994A, 0xFFEB5777)
        val colorHex = paletteColors[kotlin.math.abs(fullName.hashCode()) % paletteColors.size]
        val contactId = "contact_${UUID.randomUUID()}"
        val chatId = "chat_${UUID.randomUUID()}"
        val now = System.currentTimeMillis()
        val timeText = formatTime(now)

        contactDao.upsertContact(
            ContactEntity(
                id = contactId,
                ownerEmail = ownerEmail,
                firstName = cleanFirst,
                lastName = cleanLast,
                email = emailValue,
                username = handle,
                bio = "Пользователь Fork Gram",
                statusText = "в сети",
                isOnline = true,
                avatarColorHex = colorHex,
                statusGiftKindId = null,
                isBlocked = false
            )
        )

        chatDao.upsertChat(
            ChatThreadEntity(
                id = chatId,
                ownerEmail = ownerEmail,
                title = fullName,
                subtitle = "в сети",
                chatTypeName = ChatType.DIRECT.name,
                avatarColorHex = colorHex,
                avatarUri = null,
                isVerified = false,
                isPremiumBadge = false,
                statusGiftKindId = null,
                lastMessagePreview = "Контакт добавлен в Fork Gram",
                lastMessageTime = timeText,
                lastMessageTimestamp = now,
                unreadCount = 0,
                isPinned = false,
                isArchived = false,
                isMuted = false,
                isBlocked = false,
                autoDeleteSeconds = 0,
                pinnedMessageId = null,
                username = handle,
                bio = "Пользователь Fork Gram",
                email = emailValue,
                subscriberCount = 0
            )
        )
        return chatId
    }

    suspend fun openOrCreateChatForContact(ownerEmail: String, contact: ContactItem): String {
        val existingChatId = "${ownerEmail}_contact_${contact.id}"
        val existing = chatDao.getChat(existingChatId)
        if (existing != null) return existing.id

        val now = System.currentTimeMillis()
        val timeText = formatTime(now)
        chatDao.upsertChat(
            ChatThreadEntity(
                id = existingChatId,
                ownerEmail = ownerEmail,
                title = contact.fullName,
                subtitle = contact.statusText,
                chatTypeName = ChatType.DIRECT.name,
                avatarColorHex = contact.avatarColorHex,
                avatarUri = null,
                isVerified = false,
                isPremiumBadge = contact.statusGiftKind != null,
                statusGiftKindId = contact.statusGiftKind?.id,
                lastMessagePreview = "Начните диалог с ${contact.firstName}",
                lastMessageTime = timeText,
                lastMessageTimestamp = now,
                unreadCount = 0,
                isPinned = false,
                isArchived = false,
                isMuted = false,
                isBlocked = contact.isBlocked,
                autoDeleteSeconds = 0,
                pinnedMessageId = null,
                username = contact.username,
                bio = contact.bio,
                email = contact.email,
                subscriberCount = 0
            )
        )
        return existingChatId
    }

    suspend fun createGroupOrChannel(
        ownerEmail: String,
        title: String,
        isChannel: Boolean,
        isSecret: Boolean = false
    ): String {
        val cleanTitle = title.trim().ifBlank { if (isChannel) "Новый канал" else "Новая группа" }
        val now = System.currentTimeMillis()
        val timeText = formatTime(now)
        val chatId = "group_${UUID.randomUUID()}"
        val type = when {
            isSecret -> ChatType.SECRET
            isChannel -> ChatType.CHANNEL
            else -> ChatType.GROUP
        }
        val color = if (isSecret) 0xFF2E9E5B else if (isChannel) 0xFF8A63D2 else 0xFF2AABEE
        val subtitle = when (type) {
            ChatType.CHANNEL -> "1 подписчик"
            ChatType.SECRET -> "Секретный чат со сквозным шифрованием"
            else -> "участников: 1"
        }

        chatDao.upsertChat(
            ChatThreadEntity(
                id = chatId,
                ownerEmail = ownerEmail,
                title = cleanTitle,
                subtitle = subtitle,
                chatTypeName = type.name,
                avatarColorHex = color,
                avatarUri = null,
                isVerified = false,
                isPremiumBadge = false,
                statusGiftKindId = null,
                lastMessagePreview = if (isChannel) "Канал создан" else if (isSecret) "Секретный чат создан" else "Группа создана",
                lastMessageTime = timeText,
                lastMessageTimestamp = now,
                unreadCount = 0,
                isPinned = false,
                isArchived = false,
                isMuted = false,
                isBlocked = false,
                autoDeleteSeconds = if (isSecret) 30 else 0,
                pinnedMessageId = null,
                username = if (isChannel) "@${cleanTitle.lowercase().replace(" ", "_").take(16)}" else null,
                bio = subtitle,
                email = null,
                subscriberCount = 1
            )
        )

        messageDao.upsertMessage(
            ChatMessageEntity(
                id = UUID.randomUUID().toString(),
                ownerEmail = ownerEmail,
                chatId = chatId,
                senderName = "Система",
                isOutgoing = false,
                kindName = MessageKind.SYSTEM.name,
                text = if (isChannel) "Канал «$cleanTitle» создан" else if (isSecret) "Секретный чат с «$cleanTitle» защищён сквозным шифрованием" else "Группа «$cleanTitle» создана",
                timestampText = timeText,
                timestampMillis = now,
                dateGroup = formatDateGroup(now),
                replyToId = null,
                replyPreviewSender = null,
                replyPreviewText = null,
                forwardedFrom = null,
                mediaUri = null,
                fileName = null,
                fileSizeText = null,
                voiceDurationSec = 0,
                voiceWaveformCsv = "",
                giftKindId = null,
                giftNumber = null,
                giftStarsValue = 0,
                isNftGift = false,
                gramAmount = 0.0,
                reactionKey = null,
                isEdited = false,
                isPinned = false,
                isRead = true
            )
        )
        return chatId
    }

    suspend fun saveFolder(
        ownerEmail: String,
        folderId: String?,
        name: String,
        includeTypes: Set<ChatType>,
        includedChatIds: Set<String>,
        onlyUnread: Boolean
    ) {
        val currentCount = folderDao.countFolders(ownerEmail)
        val id = folderId ?: "folder_${UUID.randomUUID()}"
        folderDao.upsertFolder(
            ChatFolderEntity(
                id = id,
                ownerEmail = ownerEmail,
                name = name.trim().ifBlank { "Папка" },
                includeTypesCsv = includeTypes.joinToString(",") { it.name },
                includedChatIdsCsv = includedChatIds.joinToString(","),
                onlyUnread = onlyUnread,
                orderIndex = currentCount
            )
        )
    }

    suspend fun deleteFolder(folderId: String) {
        folderDao.deleteFolder(folderId)
    }

    // --- Telegram Gifts, Collections, Stars & Gram ---

    suspend fun createGiftCollection(ownerEmail: String, name: String) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        collectionDao.upsertCollection(
            GiftCollectionEntity(
                id = "col_${UUID.randomUUID()}",
                ownerEmail = ownerEmail,
                name = clean,
                createdAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun assignGiftToCollection(giftId: String, collectionName: String) {
        val gift = giftDao.getGift(giftId) ?: return
        giftDao.upsertGift(gift.copy(collectionName = collectionName))
    }

    suspend fun topUpStars(ownerEmail: String, amount: Long): Boolean {
        val account = accountDao.getAccount(ownerEmail) ?: return false
        val now = System.currentTimeMillis()
        accountDao.upsertAccount(account.copy(starsBalance = account.starsBalance + amount))
        txDao.insertTransaction(
            WalletTransactionEntity(
                id = UUID.randomUUID().toString(),
                ownerEmail = ownerEmail,
                currency = "STARS",
                amountDisplay = "+$amount",
                isCredit = true,
                title = "Пополнение Fork Gram Звёзд",
                subtitle = "Пакет $amount звёзд",
                timestampText = formatTime(now),
                timestampMillis = now
            )
        )
        return true
    }

    suspend fun topUpGram(ownerEmail: String, amount: Double): Boolean {
        val account = accountDao.getAccount(ownerEmail) ?: return false
        val now = System.currentTimeMillis()
        accountDao.upsertAccount(account.copy(gramBalance = account.gramBalance + amount))
        txDao.insertTransaction(
            WalletTransactionEntity(
                id = UUID.randomUUID().toString(),
                ownerEmail = ownerEmail,
                currency = "GRAM",
                amountDisplay = "+${formatGram(amount)} GRAM",
                isCredit = true,
                title = "Пополнение кошелька Gram",
                subtitle = "Прямое зачисление",
                timestampText = formatTime(now),
                timestampMillis = now
            )
        )
        return true
    }

    suspend fun swapGramToStars(ownerEmail: String, gramAmount: Double): Boolean {
        val account = accountDao.getAccount(ownerEmail) ?: return false
        if (gramAmount <= 0.0 || account.gramBalance < gramAmount) return false
        val starsReceived = (gramAmount * 100.0).toLong().coerceAtLeast(1L)
        val now = System.currentTimeMillis()
        accountDao.upsertAccount(
            account.copy(
                gramBalance = account.gramBalance - gramAmount,
                starsBalance = account.starsBalance + starsReceived
            )
        )
        txDao.insertTransactions(
            listOf(
                WalletTransactionEntity(
                    id = UUID.randomUUID().toString(),
                    ownerEmail = ownerEmail,
                    currency = "GRAM",
                    amountDisplay = "-${formatGram(gramAmount)} GRAM",
                    isCredit = false,
                    title = "Обмен Gram на Звёзды",
                    subtitle = "Получено $starsReceived звёзд",
                    timestampText = formatTime(now),
                    timestampMillis = now
                ),
                WalletTransactionEntity(
                    id = UUID.randomUUID().toString(),
                    ownerEmail = ownerEmail,
                    currency = "STARS",
                    amountDisplay = "+$starsReceived",
                    isCredit = true,
                    title = "Обмен из Gram",
                    subtitle = "Списано ${formatGram(gramAmount)} GRAM",
                    timestampText = formatTime(now),
                    timestampMillis = now
                )
            )
        )
        return true
    }

    suspend fun sendGramInChat(
        ownerEmail: String,
        chatId: String,
        amount: Double,
        note: String
    ): Boolean {
        val account = accountDao.getAccount(ownerEmail) ?: return false
        if (amount <= 0.0 || account.gramBalance < amount) return false
        val now = System.currentTimeMillis()
        val timeText = formatTime(now)
        val chat = chatDao.getChat(chatId) ?: return false

        accountDao.upsertAccount(account.copy(gramBalance = account.gramBalance - amount))
        txDao.insertTransaction(
            WalletTransactionEntity(
                id = UUID.randomUUID().toString(),
                ownerEmail = ownerEmail,
                currency = "GRAM",
                amountDisplay = "-${formatGram(amount)} GRAM",
                isCredit = false,
                title = "Перевод для ${chat.title}",
                subtitle = note.ifBlank { "Перевод в чате" },
                timestampText = timeText,
                timestampMillis = now
            )
        )
        val msg = ChatMessageEntity(
            id = UUID.randomUUID().toString(),
            ownerEmail = ownerEmail,
            chatId = chatId,
            senderName = account.firstName,
            isOutgoing = true,
            kindName = MessageKind.GRAM_TRANSFER.name,
            text = note.trim().ifBlank { "Перевод Gram" },
            timestampText = timeText,
            timestampMillis = now,
            dateGroup = formatDateGroup(now),
            replyToId = null,
            replyPreviewSender = null,
            replyPreviewText = null,
            forwardedFrom = null,
            mediaUri = null,
            fileName = null,
            fileSizeText = null,
            voiceDurationSec = 0,
            voiceWaveformCsv = "",
            giftKindId = null,
            giftNumber = null,
            giftStarsValue = 0,
            isNftGift = false,
            gramAmount = amount,
            reactionKey = null,
            isEdited = false,
            isPinned = false,
            isRead = true
        )
        messageDao.upsertMessage(msg)
        updateChatPreview(chatId, "Перевод: ${formatGram(amount)} GRAM", timeText, now)
        chat.email?.takeIf { it.contains("@") }?.let { recip ->
            remoteApi?.sendMessage(ownerEmail, recip, msg)
        }
        remoteApi?.updateProfile(account.copy(gramBalance = account.gramBalance - amount))
        return true
    }

    suspend fun purchaseAndSendGift(
        ownerEmail: String,
        giftKind: GiftKind,
        asNft: Boolean,
        targetChatId: String?,
        giftComment: String
    ): Boolean {
        val account = accountDao.getAccount(ownerEmail) ?: return false
        val totalCost = if (asNft) giftKind.baseStars + giftKind.upgradeStars else giftKind.baseStars
        if (account.starsBalance < totalCost) return false

        val now = System.currentTimeMillis()
        val timeText = formatTime(now)
        // Для NFT итоговый номер выдаёт сервер (порядковый среди улучшенных этой коллекции).
        var edition = giftKind.validDemoEditions.randomOrNull() ?: (10..999).random()
        val modelPair = GiftRarity.rollModel(giftKind.models)
        val backdrop = if (asNft) GiftRarity.rollBackdrop() else giftKind.defaultBackdrop
        val symbol = if (asNft) GiftRarity.rollSymbol() else giftKind.defaultSymbol

        accountDao.upsertAccount(account.copy(starsBalance = account.starsBalance - totalCost))
        txDao.insertTransaction(
            WalletTransactionEntity(
                id = UUID.randomUUID().toString(),
                ownerEmail = ownerEmail,
                currency = "STARS",
                amountDisplay = "-$totalCost",
                isCredit = false,
                title = if (asNft) "Коллекционный подарок: ${giftKind.title}" else "Подарок: ${giftKind.title}",
                subtitle = if (targetChatId == null) "В свой профиль" else "Отправка в чат",
                timestampText = timeText,
                timestampMillis = now
            )
        )

        if (targetChatId == null || targetChatId.endsWith("_saved")) {
            val newGift = OwnedGiftEntity(
                id = UUID.randomUUID().toString(),
                ownerEmail = ownerEmail,
                giftKindId = giftKind.id,
                editionNumber = edition,
                collectionName = "Все подарки",
                modelName = modelPair.first,
                modelRarity = modelPair.second,
                backdropId = backdrop.id,
                symbolId = symbol.id,
                senderName = account.toDomain().fullName,
                messageText = giftComment.trim().ifBlank { "Подарок в коллекцию" },
                starsValue = totalCost,
                isNft = asNft,
                isPinned = true,
                isWornAsStatus = false,
                receivedAt = now
            )
            giftDao.upsertGift(newGift)
            if (asNft) {
                val serverNumber = remoteApi?.syncGiftEdition(newGift)
                if (serverNumber != null) {
                    edition = serverNumber
                    giftDao.upsertGift(newGift.copy(editionNumber = serverNumber))
                }
            } else {
                remoteApi?.syncGift(newGift)
            }
        } else {
            val targetPeerEmail = chatDao.getChat(targetChatId)?.email
            if (!targetPeerEmail.isNullOrBlank() && targetPeerEmail.contains("@")) {
                val peerGift = OwnedGiftEntity(
                    id = UUID.randomUUID().toString(),
                    ownerEmail = targetPeerEmail,
                    giftKindId = giftKind.id,
                    editionNumber = edition,
                    collectionName = "Все подарки",
                    modelName = modelPair.first,
                    modelRarity = modelPair.second,
                    backdropId = backdrop.id,
                    symbolId = symbol.id,
                    senderName = account.toDomain().fullName,
                    messageText = giftComment.trim().ifBlank { "Подарок из Fork Gram" },
                    starsValue = totalCost,
                    isNft = asNft,
                    isPinned = true,
                    isWornAsStatus = false,
                    receivedAt = now
                )
                if (asNft) {
                    remoteApi?.syncGiftEdition(peerGift)?.let { edition = it }
                } else {
                    remoteApi?.syncGift(peerGift)
                }
            }
        }

        if (targetChatId != null) {
            val msg = ChatMessageEntity(
                id = UUID.randomUUID().toString(),
                ownerEmail = ownerEmail,
                chatId = targetChatId,
                senderName = account.firstName,
                isOutgoing = true,
                kindName = MessageKind.GIFT.name,
                text = giftComment.trim().ifBlank { giftKind.title },
                timestampText = timeText,
                timestampMillis = now,
                dateGroup = formatDateGroup(now),
                replyToId = null,
                replyPreviewSender = null,
                replyPreviewText = null,
                forwardedFrom = null,
                mediaUri = null,
                fileName = null,
                fileSizeText = null,
                voiceDurationSec = 0,
                voiceWaveformCsv = "",
                giftKindId = giftKind.id,
                giftNumber = edition,
                giftStarsValue = totalCost,
                isNftGift = asNft,
                gramAmount = 0.0,
                reactionKey = null,
                isEdited = false,
                isPinned = false,
                isRead = true
            )
            messageDao.upsertMessage(msg)
            updateChatPreview(
                targetChatId,
                if (asNft) "Коллекционный подарок: ${giftKind.title} #$edition" else "Подарок: ${giftKind.title}",
                timeText,
                now
            )
            chatDao.getChat(targetChatId)?.email?.takeIf { it.contains("@") }?.let { recip ->
                remoteApi?.sendMessage(ownerEmail, recip, msg)
            }
        }
        remoteApi?.updateProfile(account.copy(starsBalance = account.starsBalance - totalCost))
        return true
    }

    /** NFT по ссылке/номеру: реальные атрибуты и владелец с сервера. */
    suspend fun lookupNft(kind: GiftKind, number: Int): OwnedGift? {
        val res = remoteApi?.fetchNft(kind.linkSlug, number) ?: return null
        val g = res.optJSONObject("gift") ?: return null
        val backdropId = g.optString("backdrop_id")
        val symbolId = g.optString("symbol_id")
        return OwnedGift(
            id = g.optString("id"),
            giftKind = kind,
            editionNumber = g.optInt("edition_number", number),
            collectionName = "",
            modelName = g.optString("model_name", kind.models.first().first),
            modelRarity = g.optString("model_rarity", kind.models.first().second),
            backdrop = GiftBackdrop.entries.firstOrNull { it.id == backdropId } ?: kind.defaultBackdrop,
            symbol = GiftSymbol.entries.firstOrNull { it.id == symbolId } ?: kind.defaultSymbol,
            senderName = g.optString("sender_name"),
            messageText = g.optString("message_text"),
            starsValue = g.optInt("stars_value", kind.baseStars),
            isNft = true,
            isPinned = false,
            isWornAsStatus = false,
            receivedAt = g.optLong("received_at"),
            ownerName = res.optString("ownerName"),
            ownerHandle = res.optString("ownerHandle"),
            forSaleGram = if (res.isNull("priceGram")) null else res.optDouble("priceGram")
        )
    }

    suspend fun upgradeGiftToNft(ownerEmail: String, giftId: String): OwnedGift? {
        val gift = giftDao.getGift(giftId) ?: return null
        val kind = GiftKind.entries.firstOrNull { it.id == gift.giftKindId } ?: return null
        if (gift.isNft) return gift.toDomain()
        val account = accountDao.getAccount(ownerEmail) ?: return null
        if (account.starsBalance < kind.upgradeStars) return null

        val now = System.currentTimeMillis()
        val rolledModel = GiftRarity.rollModel(kind.models)
        val rolledBackdrop = GiftRarity.rollBackdrop()
        val rolledSymbol = GiftRarity.rollSymbol()
        var updated = gift.copy(
            isNft = true,
            modelName = rolledModel.first,
            modelRarity = rolledModel.second,
            backdropId = rolledBackdrop.id,
            symbolId = rolledSymbol.id,
            starsValue = gift.starsValue + kind.upgradeStars
        )

        accountDao.upsertAccount(account.copy(starsBalance = account.starsBalance - kind.upgradeStars))
        // Номер NFT выдаёт сервер: порядковый среди улучшенных подарков этой коллекции.
        remoteApi?.syncGiftEdition(updated)?.let { updated = updated.copy(editionNumber = it) }
        giftDao.upsertGift(updated)
        remoteApi?.updateProfile(account.copy(starsBalance = account.starsBalance - kind.upgradeStars))
        txDao.insertTransaction(
            WalletTransactionEntity(
                id = UUID.randomUUID().toString(),
                ownerEmail = ownerEmail,
                currency = "STARS",
                amountDisplay = "-${kind.upgradeStars}",
                isCredit = false,
                title = "Улучшение до NFT: ${kind.title} #${gift.editionNumber}",
                subtitle = "${rolledModel.first} • ${rolledBackdrop.title}",
                timestampText = formatTime(now),
                timestampMillis = now
            )
        )
        return updated.toDomain()
    }

    suspend fun convertGiftToStars(ownerEmail: String, giftId: String): Int? {
        val gift = giftDao.getGift(giftId) ?: return null
        val account = accountDao.getAccount(ownerEmail) ?: return null
        val refund = (gift.starsValue * 0.85).toInt().coerceAtLeast(25)
        val now = System.currentTimeMillis()

        giftDao.deleteGift(giftId)
        val updatedAccount = if (gift.isWornAsStatus) {
            account.copy(
                starsBalance = account.starsBalance + refund,
                statusGiftKindId = null,
                statusBackdropId = null,
                statusSymbolId = null
            )
        } else {
            account.copy(starsBalance = account.starsBalance + refund)
        }
        accountDao.upsertAccount(updatedAccount)
        remoteApi?.deleteGift(giftId, ownerEmail)
        remoteApi?.updateProfile(updatedAccount)
        txDao.insertTransaction(
            WalletTransactionEntity(
                id = UUID.randomUUID().toString(),
                ownerEmail = ownerEmail,
                currency = "STARS",
                amountDisplay = "+$refund",
                isCredit = true,
                title = "Обмен подарка на Звёзды",
                subtitle = "Подарок #${gift.editionNumber}",
                timestampText = formatTime(now),
                timestampMillis = now
            )
        )
        return refund
    }

    suspend fun transferGiftToChat(ownerEmail: String, giftId: String, targetChatId: String): Boolean {
        val gift = giftDao.getGift(giftId) ?: return false
        val targetChat = chatDao.getChat(targetChatId) ?: return false
        val peerEmail = targetChat.email?.takeIf { it.contains("@") } ?: return false
        val account = accountDao.getAccount(ownerEmail) ?: return false
        val senderFullName = account.toDomain().fullName
        val now = System.currentTimeMillis()
        val timeText = formatTime(now)

        giftDao.deleteGift(giftId)
        if (gift.isWornAsStatus) {
            val cleaned = account.copy(statusGiftKindId = null, statusBackdropId = null, statusSymbolId = null)
            accountDao.upsertAccount(cleaned)
            remoteApi?.updateProfile(cleaned)
        }
        remoteApi?.transferGift(giftId, ownerEmail, peerEmail, senderFullName)

        val msg = ChatMessageEntity(
            id = UUID.randomUUID().toString(),
            ownerEmail = ownerEmail,
            chatId = targetChatId,
            senderName = account.firstName,
            isOutgoing = true,
            kindName = MessageKind.GIFT.name,
            text = "Передан коллекционный подарок #${gift.editionNumber}",
            timestampText = timeText,
            timestampMillis = now,
            dateGroup = formatDateGroup(now),
            replyToId = null,
            replyPreviewSender = null,
            replyPreviewText = null,
            forwardedFrom = null,
            mediaUri = null,
            fileName = null,
            fileSizeText = null,
            voiceDurationSec = 0,
            voiceWaveformCsv = "",
            giftKindId = gift.giftKindId,
            giftNumber = gift.editionNumber,
            giftStarsValue = gift.starsValue,
            isNftGift = gift.isNft,
            gramAmount = 0.0,
            reactionKey = null,
            isEdited = false,
            isPinned = false,
            isRead = false
        )
        messageDao.upsertMessage(msg)
        updateChatPreview(targetChatId, "Передан подарок #${gift.editionNumber}", timeText, now, isOutgoing = true, isRead = false)
        remoteApi?.sendMessage(ownerEmail, peerEmail, msg)
        return true
    }

    suspend fun togglePinGift(giftId: String) {
        val gift = giftDao.getGift(giftId) ?: return
        val updated = gift.copy(isPinned = !gift.isPinned)
        giftDao.upsertGift(updated)
        remoteApi?.syncGift(updated)
    }

    suspend fun toggleWearGiftStatus(ownerEmail: String, giftId: String) {
        val gift = giftDao.getGift(giftId) ?: return
        val account = accountDao.getAccount(ownerEmail) ?: return
        val nextWorn = !gift.isWornAsStatus
        giftDao.clearWornStatus(ownerEmail)
        val updatedGift = gift.copy(isWornAsStatus = nextWorn)
        giftDao.upsertGift(updatedGift)
        val updatedAccount = account.copy(
            statusGiftKindId = if (nextWorn) gift.giftKindId else null,
            statusBackdropId = if (nextWorn) gift.backdropId else null,
            statusSymbolId = if (nextWorn) gift.symbolId else null
        )
        accountDao.upsertAccount(updatedAccount)
        remoteApi?.syncGift(updatedGift)
        remoteApi?.updateProfile(updatedAccount)
    }

    suspend fun addChatPeerToContacts(ownerEmail: String, chatId: String): Boolean {
        val chat = chatDao.getChat(chatId) ?: return false
        val nameParts = chat.title.trim().split(Regex("\\s+"), limit = 2)
        val firstName = nameParts.getOrNull(0)?.ifBlank { "Контакт" } ?: "Контакт"
        val lastName = nameParts.getOrNull(1) ?: ""
        val emailValue = chat.email?.takeIf { it.isNotBlank() } ?: "${chat.id}@forkgram.me"
        contactDao.upsertContact(
            ContactEntity(
                id = "contact_${emailValue.lowercase().hashCode()}",
                ownerEmail = ownerEmail,
                firstName = firstName,
                lastName = lastName,
                email = emailValue,
                username = chat.username ?: "@${firstName.lowercase()}",
                bio = chat.bio ?: "На связи в Fork Gram",
                statusText = if (chat.isOnline) "в сети" else chat.subtitle,
                isOnline = chat.isOnline,
                avatarColorHex = chat.avatarColorHex,
                statusGiftKindId = chat.statusGiftKindId,
                isBlocked = chat.isBlocked
            )
        )
        return true
    }

    suspend fun fetchPeerProfile(ownerEmail: String, peerEmail: String): PeerProfileData? {
        return remoteApi?.fetchPeerProfile(peerEmail, ownerEmail)
    }

    suspend fun publishProfilePost(
        ownerEmail: String,
        sourceUri: Uri,
        caption: String = "",
        isArchived: Boolean = false
    ): ProfilePost? {
        val copied = copyUriToAppStorage(sourceUri, "posts", "post_${UUID.randomUUID()}.jpg") ?: return null
        val uploaded = uploadLocalFile(copied, "post_${UUID.randomUUID()}.jpg") ?: copied
        val entity = ProfilePostEntity(
            id = "post_${UUID.randomUUID()}",
            ownerEmail = ownerEmail.trim().lowercase(),
            mediaUrl = uploaded,
            caption = caption.trim(),
            isArchived = isArchived,
            createdAt = System.currentTimeMillis()
        )
        postDao.upsertPost(entity)
        remoteApi?.publishPost(entity)
        return entity.toDomain()
    }

    suspend fun toggleArchiveProfilePost(ownerEmail: String, postId: String) {
        val post = postDao.getPost(postId) ?: return
        val next = !post.isArchived
        postDao.upsertPost(post.copy(isArchived = next))
        remoteApi?.toggleArchivePost(postId, ownerEmail, next)
    }

    suspend fun deleteProfilePost(ownerEmail: String, postId: String) {
        postDao.deletePost(postId)
        remoteApi?.deletePost(postId, ownerEmail)
    }

    suspend fun sendHeartbeat(ownerEmail: String, isOnline: Boolean, typingToEmail: String? = null) {
        val sessId = runCatching { preferences.ensureDeviceSessionId() }.getOrNull()
        remoteApi?.sendHeartbeat(ownerEmail, isOnline, typingToEmail, sessId)
    }

    suspend fun terminateSession(ownerEmail: String, sessionId: String) {
        remoteApi?.terminateSession(sessionId, ownerEmail)
        _sessions.value = _sessions.value.filterNot { it.id == sessionId }
    }

    suspend fun deleteChat(chatId: String) {
        messageDao.clearChatMessages(chatId)
        chatDao.deleteChat(chatId)
    }

    suspend fun computeCacheBytes(): Long = withContext(Dispatchers.IO) {
        var total = 0L
        listOf(context.cacheDir, File(context.filesDir, "media"), File(context.filesDir, "voice")).forEach { dir ->
            if (dir.exists()) {
                dir.walkTopDown().filter { it.isFile }.forEach { total += it.length() }
            }
        }
        total
    }

    suspend fun clearAppCache(): Long = withContext(Dispatchers.IO) {
        context.cacheDir.listFiles()?.forEach { it.deleteRecursively() }
        computeCacheBytes()
    }

    suspend fun searchRemoteUsers(ownerEmail: String, query: String): List<RemoteDirectoryUser> {
        return remoteApi?.searchUsers(query, ownerEmail) ?: emptyList()
    }

    suspend fun openOrCreateChatForRemoteUser(ownerEmail: String, user: RemoteDirectoryUser): String {
        val peerEmail = user.email.trim().lowercase()
        val chatId = "${ownerEmail}_dm_${peerEmail.hashCode()}"
        val existing = chatDao.getChat(chatId)
        if (existing != null) return existing.id

        val now = System.currentTimeMillis()
        val timeText = formatTime(now)
        val paletteColors = listOf(0xFF2AABEE, 0xFF8A63D2, 0xFF46B966, 0xFFF2994A, 0xFFEB5777)
        val colorHex = paletteColors[kotlin.math.abs(user.fullName.hashCode()) % paletteColors.size]
        val statusLabel = when {
            user.isTypingToMe -> "печатает..."
            user.isOnline -> "в сети"
            else -> "был(а) недавно"
        }

        contactDao.upsertContact(
            ContactEntity(
                id = "remote_${peerEmail.hashCode()}",
                ownerEmail = ownerEmail,
                firstName = user.firstName,
                lastName = user.lastName,
                email = peerEmail,
                username = user.displayHandle,
                bio = user.bio,
                statusText = statusLabel,
                isOnline = user.isOnline,
                avatarColorHex = colorHex,
                statusGiftKindId = user.statusGiftKindId,
                isBlocked = false
            )
        )

        chatDao.upsertChat(
            ChatThreadEntity(
                id = chatId,
                ownerEmail = ownerEmail,
                title = user.fullName,
                subtitle = statusLabel,
                chatTypeName = ChatType.DIRECT.name,
                avatarColorHex = colorHex,
                avatarUri = user.avatarUri,
                isVerified = false,
                isPremiumBadge = user.statusGiftKindId != null,
                statusGiftKindId = user.statusGiftKindId,
                lastMessagePreview = "Пользователь Fork Gram",
                lastMessageTime = timeText,
                lastMessageTimestamp = now,
                unreadCount = 0,
                isPinned = false,
                isArchived = false,
                isMuted = false,
                isBlocked = false,
                autoDeleteSeconds = 0,
                pinnedMessageId = null,
                username = user.displayHandle,
                bio = user.bio,
                email = peerEmail,
                subscriberCount = 0,
                isOnline = user.isOnline,
                isTyping = user.isTypingToMe
            )
        )
        return chatId
    }

    suspend fun syncFromServer(ownerEmail: String, sinceMillis: Long = 0L): Long {
        val payload = remoteApi?.sync(ownerEmail, sinceMillis) ?: return sinceMillis
        val peersByEmail = payload.peers.associateBy { it.email.lowercase() }

        payload.gifts.forEach { gift ->
            giftDao.upsertGift(gift)
        }
        payload.posts.forEach { post ->
            postDao.upsertPost(post)
        }
        if (payload.sessions.isNotEmpty()) {
            _sessions.value = payload.sessions
        }

        // Refresh online / typing status on existing DM chats
        peersByEmail.forEach { (peerEmail, peer) ->
            val chatId = "${ownerEmail}_dm_${peerEmail.hashCode()}"
            val existingChat = chatDao.getChat(chatId)
            if (existingChat != null) {
                val nextSub = when {
                    peer.isTypingToMe -> "печатает..."
                    peer.isOnline -> "в сети"
                    else -> "был(а) недавно"
                }
                chatDao.upsertChat(
                    existingChat.copy(
                        title = peer.fullName,
                        subtitle = nextSub,
                        avatarUri = peer.avatarUri ?: existingChat.avatarUri,
                        statusGiftKindId = peer.statusGiftKindId,
                        isPremiumBadge = peer.statusGiftKindId != null,
                        bio = peer.bio,
                        username = peer.displayHandle,
                        isOnline = peer.isOnline,
                        isTyping = peer.isTypingToMe
                    )
                )
            }
        }

        for (rm in payload.messages) {
            val isOutgoing = rm.senderEmail.equals(ownerEmail, ignoreCase = true)
            val peerEmail = if (isOutgoing) rm.recipientEmail.lowercase() else rm.senderEmail.lowercase()
            if (peerEmail.isBlank()) continue
            val peer = peersByEmail[peerEmail]
            val chatId = "${ownerEmail}_dm_${peerEmail.hashCode()}"

            if (rm.isDeleted) {
                messageDao.deleteMessage(rm.id)
                continue
            }

            val existingMsg = messageDao.getMessage(rm.id)
            val existingChat = chatDao.getChat(chatId)
            val timeText = formatTime(rm.timestampMillis)
            val preview = when (rm.kindName) {
                MessageKind.PHOTO.name -> if (rm.text.isNotBlank()) "Фотография: ${rm.text}" else "Фотография"
                MessageKind.FILE.name -> "Файл: ${rm.fileName ?: rm.text}"
                MessageKind.VOICE.name -> "Голосовое сообщение (${formatDuration(rm.voiceDurationSec)})"
                MessageKind.LOCATION.name -> "Геопозиция: ${rm.text}"
                MessageKind.GIFT.name -> "Подарок"
                MessageKind.GRAM_TRANSFER.name -> "Перевод ${formatGram(rm.gramAmount)} GRAM"
                else -> rm.text
            }
            if (existingChat == null) {
                val title = peer?.fullName ?: rm.senderName
                val paletteColors = listOf(0xFF2AABEE, 0xFF8A63D2, 0xFF46B966, 0xFFF2994A, 0xFFEB5777)
                chatDao.upsertChat(
                    ChatThreadEntity(
                        id = chatId,
                        ownerEmail = ownerEmail,
                        title = title,
                        subtitle = if (peer?.isOnline == true) "в сети" else "был(а) недавно",
                        chatTypeName = ChatType.DIRECT.name,
                        avatarColorHex = paletteColors[kotlin.math.abs(title.hashCode()) % paletteColors.size],
                        avatarUri = peer?.avatarUri,
                        isVerified = false,
                        isPremiumBadge = peer?.statusGiftKindId != null,
                        statusGiftKindId = peer?.statusGiftKindId,
                        lastMessagePreview = preview,
                        lastMessageTime = timeText,
                        lastMessageTimestamp = rm.timestampMillis,
                        unreadCount = if (isOutgoing || rm.isRead) 0 else 1,
                        isPinned = false,
                        isArchived = false,
                        isMuted = false,
                        isBlocked = false,
                        autoDeleteSeconds = 0,
                        pinnedMessageId = null,
                        username = peer?.displayHandle ?: "@${peerEmail.substringBefore("@")}",
                        bio = peer?.bio ?: "На связи в Fork Gram",
                        email = peerEmail,
                        subscriberCount = 0,
                        isOnline = peer?.isOnline == true,
                        isTyping = peer?.isTypingToMe == true,
                        isLastMessageOutgoing = isOutgoing,
                        isLastOutgoingRead = rm.isRead
                    )
                )
            } else if (rm.timestampMillis >= existingChat.lastMessageTimestamp) {
                val unreadIncrement = if (existingMsg == null && !isOutgoing && !rm.isRead) 1 else 0
                chatDao.upsertChat(
                    existingChat.copy(
                        lastMessagePreview = preview,
                        lastMessageTime = timeText,
                        lastMessageTimestamp = rm.timestampMillis,
                        unreadCount = existingChat.unreadCount + unreadIncrement,
                        isLastMessageOutgoing = isOutgoing,
                        isLastOutgoingRead = rm.isRead
                    )
                )
            }

            messageDao.upsertMessage(
                ChatMessageEntity(
                    id = rm.id,
                    ownerEmail = ownerEmail,
                    chatId = chatId,
                    senderName = rm.senderName,
                    isOutgoing = isOutgoing,
                    kindName = rm.kindName,
                    text = rm.text,
                    timestampText = timeText,
                    timestampMillis = rm.timestampMillis,
                    dateGroup = formatDateGroup(rm.timestampMillis),
                    replyToId = existingMsg?.replyToId,
                    replyPreviewSender = rm.replyPreviewSender,
                    replyPreviewText = rm.replyPreviewText,
                    forwardedFrom = rm.forwardedFrom,
                    mediaUri = rm.mediaUri ?: existingMsg?.mediaUri,
                    fileName = rm.fileName ?: existingMsg?.fileName,
                    fileSizeText = rm.fileSizeText ?: existingMsg?.fileSizeText,
                    voiceDurationSec = if (rm.voiceDurationSec > 0) rm.voiceDurationSec else (existingMsg?.voiceDurationSec ?: 0),
                    voiceWaveformCsv = rm.voiceWaveformCsv.ifBlank { existingMsg?.voiceWaveformCsv ?: "" },
                    giftKindId = rm.giftKindId,
                    giftNumber = rm.giftNumber,
                    giftStarsValue = rm.giftStarsValue,
                    isNftGift = rm.isNftGift,
                    gramAmount = rm.gramAmount,
                    reactionKey = rm.reactionKey,
                    isEdited = rm.isEdited,
                    isPinned = existingMsg?.isPinned ?: false,
                    isRead = rm.isRead || (!isOutgoing && existingMsg?.isRead == true)
                )
            )
        }
        return payload.serverTime
    }

    private suspend fun syncAllLocalGiftsToServer(email: String) {
        val api = remoteApi ?: return
        val existingServer = api.sync(email, 0L)
        if (existingServer != null && existingServer.gifts.isEmpty()) {
            giftDao.observeGifts(email).first().forEach { gift ->
                api.syncGift(gift)
            }
        }
    }

    suspend fun refreshFragmentMarket(ownerEmail: String) {
        val api = remoteApi ?: return
        val payload = api.fetchFragmentMarket(ownerEmail) ?: return
        applyFragmentPayload(ownerEmail, payload)
    }

    private suspend fun applyFragmentPayload(ownerEmail: String, payload: FragmentMarketPayload) {
        _fragmentGiftListings.value = payload.giftListings
        nftUsernameDao.clearForOwner(ownerEmail)
        nftUsernameDao.upsertNftUsernames(
            payload.usernames.map { item ->
                NftUsernameEntity(
                    id = item.id,
                    ownerEmail = ownerEmail,
                    handle = item.handle,
                    priceGram = item.priceGram,
                    isOwned = item.isOwned,
                    isEquipped = item.isEquipped,
                    rarityTier = item.rarityTier,
                    acquiredAt = item.acquiredAt,
                    status = item.status,
                    topBidGram = item.topBidGram,
                    minBidGram = item.minBidGram,
                    topBidderName = item.topBidderName,
                    isHighestBidder = item.isHighestBidder,
                    bidsCount = item.bidsCount,
                    endsAt = item.endsAt,
                    itemOwnerEmail = item.ownerEmail,
                    ownerName = item.ownerName,
                    fragmentUrl = item.fragmentUrl
                )
            }
        )
        val existingAcc = accountDao.getAccount(ownerEmail)
        if (existingAcc != null) {
            val nextGram = payload.updatedGramBalance ?: existingAcc.gramBalance
            val nextHandle = payload.activeNftUsername
            accountDao.upsertAccount(
                existingAcc.copy(
                    gramBalance = nextGram,
                    activeNftUsername = nextHandle
                )
            )
        }
    }

    suspend fun buyOrMintNftUsername(
        ownerEmail: String,
        itemId: String? = null,
        customHandle: String? = null
    ): Boolean {
        return if (itemId != null) {
            buyFragmentUsername(ownerEmail, itemId).first
        } else if (!customHandle.isNullOrBlank()) {
            mintCustomNftUsername(ownerEmail, customHandle).first
        } else {
            false
        }
    }

    suspend fun buyFragmentUsername(ownerEmail: String, itemId: String): Pair<Boolean, String> {
        val account = accountDao.getAccount(ownerEmail) ?: return false to "Аккаунт не найден"
        val item = nftUsernameDao.getNftUsername(itemId) ?: return false to "Лот не найден"
        val now = System.currentTimeMillis()
        if (remoteApi != null) {
            val res = remoteApi.buyFragmentUsername(ownerEmail, itemId)
            res.market?.let { applyFragmentPayload(ownerEmail, it) }
            if (!res.ok) {
                return false to (res.error ?: "Не удалось купить юзернейм")
            }
            txDao.insertTransaction(
                WalletTransactionEntity(
                    id = UUID.randomUUID().toString(),
                    ownerEmail = ownerEmail,
                    currency = "GRAM",
                    amountDisplay = "-${formatGram(item.priceGram)} GRAM",
                    isCredit = false,
                    title = "Покупка на Fragment ${item.handle}",
                    subtitle = "Коллекционный юзернейм",
                    timestampText = formatTime(now),
                    timestampMillis = now
                )
            )
            return true to "NFT-юзернейм ${item.handle} куплен!"
        }

        if (item.isOwned || account.gramBalance < item.priceGram) return false to "Недостаточно GRAM"
        val updatedAcc = account.copy(
            gramBalance = account.gramBalance - item.priceGram,
            activeNftUsername = item.handle
        )
        accountDao.upsertAccount(updatedAcc)
        nftUsernameDao.unequipAll(ownerEmail)
        nftUsernameDao.upsertNftUsername(
            item.copy(isOwned = true, isEquipped = true, acquiredAt = now, status = "OWNED")
        )
        txDao.insertTransaction(
            WalletTransactionEntity(
                id = UUID.randomUUID().toString(),
                ownerEmail = ownerEmail,
                currency = "GRAM",
                amountDisplay = "-${formatGram(item.priceGram)} GRAM",
                isCredit = false,
                title = "Покупка на Fragment ${item.handle}",
                subtitle = "Коллекционный юзернейм (${item.rarityTier})",
                timestampText = formatTime(now),
                timestampMillis = now
            )
        )
        return true to "NFT-юзернейм ${item.handle} куплен!"
    }

    suspend fun bidFragmentUsername(
        ownerEmail: String,
        itemId: String,
        amountGram: Double
    ): Pair<Boolean, String> {
        val api = remoteApi ?: return false to "Требуется подключение к Fragment"
        val now = System.currentTimeMillis()
        val res = api.bidFragmentUsername(ownerEmail, itemId, amountGram)
        res.market?.let { applyFragmentPayload(ownerEmail, it) }
        if (!res.ok) return false to (res.error ?: "Ставка не принята")
        txDao.insertTransaction(
            WalletTransactionEntity(
                id = UUID.randomUUID().toString(),
                ownerEmail = ownerEmail,
                currency = "GRAM",
                amountDisplay = "-${formatGram(amountGram)} GRAM",
                isCredit = false,
                title = "Ставка на аукционе Fragment",
                subtitle = "Заморожено для аукциона",
                timestampText = formatTime(now),
                timestampMillis = now
            )
        )
        return true to "Ставка ${formatGram(amountGram)} GRAM принята!"
    }

    suspend fun mintCustomNftUsername(ownerEmail: String, customHandle: String): Pair<Boolean, String> {
        val account = accountDao.getAccount(ownerEmail) ?: return false to "Аккаунт не найден"
        val clean = customHandle.trim().lowercase().replace(Regex("[^a-z0-9_]"), "")
        if (clean.length < 3) return false to "Минимум 3 латинских символа"
        val handle = "@$clean"
        val mintPrice = if (clean.length <= 4) 18.0 else 6.0
        val now = System.currentTimeMillis()

        if (remoteApi != null) {
            val res = remoteApi.mintFragmentUsername(ownerEmail, handle)
            res.market?.let { applyFragmentPayload(ownerEmail, it) }
            if (!res.ok) {
                return false to (res.error ?: "Имя уже занято или недостаточно GRAM")
            }
            txDao.insertTransaction(
                WalletTransactionEntity(
                    id = UUID.randomUUID().toString(),
                    ownerEmail = ownerEmail,
                    currency = "GRAM",
                    amountDisplay = "-${formatGram(mintPrice)} GRAM",
                    isCredit = false,
                    title = "Минт на Fragment $handle",
                    subtitle = "Выпуск собственного NFT-имени",
                    timestampText = formatTime(now),
                    timestampMillis = now
                )
            )
            return true to "NFT-юзернейм $handle выпущен на Fragment!"
        }

        if (account.gramBalance < mintPrice) return false to "Недостаточно GRAM"
        val updatedAcc = account.copy(
            gramBalance = account.gramBalance - mintPrice,
            activeNftUsername = handle
        )
        accountDao.upsertAccount(updatedAcc)
        nftUsernameDao.unequipAll(ownerEmail)
        nftUsernameDao.upsertNftUsername(
            NftUsernameEntity(
                id = "nft_${UUID.randomUUID()}",
                ownerEmail = ownerEmail,
                handle = handle,
                priceGram = mintPrice,
                isOwned = true,
                isEquipped = true,
                rarityTier = if (clean.length <= 4) "Ультра-короткий NFT" else "Авторский NFT",
                acquiredAt = now,
                status = "OWNED"
            )
        )
        txDao.insertTransaction(
            WalletTransactionEntity(
                id = UUID.randomUUID().toString(),
                ownerEmail = ownerEmail,
                currency = "GRAM",
                amountDisplay = "-${formatGram(mintPrice)} GRAM",
                isCredit = false,
                title = "Минт NFT-юзернейма $handle",
                subtitle = "Выпуск собственного NFT-имени",
                timestampText = formatTime(now),
                timestampMillis = now
            )
        )
        return true to "NFT-юзернейм $handle выпущен!"
    }

    suspend fun sellFragmentUsername(
        ownerEmail: String,
        itemId: String,
        mode: String,
        priceGram: Double
    ): Pair<Boolean, String> {
        val api = remoteApi ?: return false to "Требуется подключение к Fragment"
        val res = api.sellFragmentUsername(ownerEmail, itemId, mode, priceGram)
        res.market?.let { applyFragmentPayload(ownerEmail, it) }
        return if (res.ok) true to "Выставлено на Fragment!"
        else false to (res.error ?: "Не удалось выставить на продажу")
    }

    suspend fun cancelFragmentSale(ownerEmail: String, itemId: String): Pair<Boolean, String> {
        val api = remoteApi ?: return false to "Требуется подключение к Fragment"
        val res = api.cancelFragmentSale(ownerEmail, itemId)
        res.market?.let { applyFragmentPayload(ownerEmail, it) }
        return if (res.ok) true to "Лот снят с продажи"
        else false to (res.error ?: "Не удалось снять с продажи")
    }

    suspend fun listGiftOnFragment(
        ownerEmail: String,
        giftId: String,
        priceGram: Double
    ): Pair<Boolean, String> {
        val api = remoteApi ?: return false to "Требуется подключение к Fragment"
        val res = api.listGiftOnFragment(ownerEmail, giftId, priceGram)
        res.market?.let { applyFragmentPayload(ownerEmail, it) }
        return if (res.ok) true to "NFT-подарок выставлен на Fragment!"
        else false to (res.error ?: "Не удалось выставить подарок")
    }

    suspend fun buyFragmentGift(ownerEmail: String, listingId: String): Pair<Boolean, String> {
        val api = remoteApi ?: return false to "Требуется подключение к Fragment"
        val now = System.currentTimeMillis()
        val listing = _fragmentGiftListings.value.firstOrNull { it.id == listingId }
        val res = api.buyFragmentGift(ownerEmail, listingId)
        res.market?.let { applyFragmentPayload(ownerEmail, it) }
        if (!res.ok) return false to (res.error ?: "Не удалось купить NFT-подарок")
        syncFromServer(ownerEmail, 0L)
        if (listing != null) {
            txDao.insertTransaction(
                WalletTransactionEntity(
                    id = UUID.randomUUID().toString(),
                    ownerEmail = ownerEmail,
                    currency = "GRAM",
                    amountDisplay = "-${formatGram(listing.priceGram)} GRAM",
                    isCredit = false,
                    title = "Покупка NFT-подарка #${listing.gift.editionNumber}",
                    subtitle = "Fragment • ${listing.gift.giftKind.title}",
                    timestampText = formatTime(now),
                    timestampMillis = now
                )
            )
        }
        return true to "NFT-подарок добавлен в ваш профиль!"
    }

    suspend fun toggleEquipNftUsername(ownerEmail: String, itemId: String) {
        if (remoteApi != null) {
            val res = remoteApi.assignFragmentUsername(ownerEmail, itemId)
            res.market?.let { applyFragmentPayload(ownerEmail, it) }
            if (res.ok) return
        }
        val item = nftUsernameDao.getNftUsername(itemId) ?: return
        if (!item.isOwned) return
        val account = accountDao.getAccount(ownerEmail) ?: return
        val nextEquipped = !item.isEquipped
        nftUsernameDao.unequipAll(ownerEmail)
        nftUsernameDao.upsertNftUsername(item.copy(isEquipped = nextEquipped))
        val updatedAcc = account.copy(activeNftUsername = if (nextEquipped) item.handle else null)
        accountDao.upsertAccount(updatedAcc)
        remoteApi?.updateProfile(updatedAcc)
    }

    suspend fun activatePremium(ownerEmail: String, useGram: Boolean): Boolean {
        val account = accountDao.getAccount(ownerEmail) ?: return false
        val now = System.currentTimeMillis()
        if (useGram) {
            if (account.gramBalance < 3.5) return false
            val updatedAcc = account.copy(gramBalance = account.gramBalance - 3.5, isPremium = true)
            accountDao.upsertAccount(updatedAcc)
            remoteApi?.updateProfile(updatedAcc)
            txDao.insertTransaction(
                WalletTransactionEntity(
                    id = UUID.randomUUID().toString(),
                    ownerEmail = ownerEmail,
                    currency = "GRAM",
                    amountDisplay = "-3.50 GRAM",
                    isCredit = false,
                    title = "Fork Gram Premium",
                    subtitle = "Подписка на 1 месяц",
                    timestampText = formatTime(now),
                    timestampMillis = now
                )
            )
        } else {
            if (account.starsBalance < 350L) return false
            val updatedAcc = account.copy(starsBalance = account.starsBalance - 350L, isPremium = true)
            accountDao.upsertAccount(updatedAcc)
            remoteApi?.updateProfile(updatedAcc)
            txDao.insertTransaction(
                WalletTransactionEntity(
                    id = UUID.randomUUID().toString(),
                    ownerEmail = ownerEmail,
                    currency = "STARS",
                    amountDisplay = "-350",
                    isCredit = false,
                    title = "Fork Gram Premium",
                    subtitle = "Подписка на 1 месяц",
                    timestampText = formatTime(now),
                    timestampMillis = now
                )
            )
        }
        return true
    }

    private suspend fun updateChatPreview(
        chatId: String,
        preview: String,
        timeText: String,
        now: Long,
        isOutgoing: Boolean = true,
        isRead: Boolean = true
    ) {
        val chat = chatDao.getChat(chatId) ?: return
        chatDao.upsertChat(
            chat.copy(
                lastMessagePreview = preview,
                lastMessageTime = timeText,
                lastMessageTimestamp = now,
                draftText = "",
                isLastMessageOutgoing = isOutgoing,
                isLastOutgoingRead = isRead
            )
        )
    }

    private suspend fun uploadLocalFile(localPath: String, filename: String): String? =
        withContext(Dispatchers.IO) {
            val api = remoteApi ?: return@withContext null
            val f = File(localPath)
            if (!f.exists() || f.length() == 0L || f.length() > 11 * 1024 * 1024) return@withContext null
            val bytes = runCatching { f.readBytes() }.getOrNull() ?: return@withContext null
            api.uploadMediaBytes(bytes, filename)
        }

    private suspend fun seedWorkspaceForAccount(
        email: String,
        firstName: String,
        now: Long,
        timeText: String
    ) {
        // ONLY TWO CHATS initially as explicitly requested: "Fork Gram" and "Избранное"!
        val serviceId = "${email}_service"
        val savedId = "${email}_saved"

        chatDao.upsertChats(
            listOf(
                ChatThreadEntity(
                    id = serviceId,
                    ownerEmail = email,
                    title = "Fork Gram",
                    subtitle = "Служебные уведомления",
                    chatTypeName = ChatType.SERVICE.name,
                    avatarColorHex = 0xFF2AABEE,
                    avatarUri = null,
                    isVerified = true,
                    isPremiumBadge = false,
                    statusGiftKindId = null,
                    lastMessagePreview = "Welcome to Fork Gram! A new sign-in to your account...",
                    lastMessageTime = timeText,
                    lastMessageTimestamp = now,
                    unreadCount = 1,
                    isPinned = false,
                    isArchived = false,
                    isMuted = false,
                    isBlocked = false,
                    autoDeleteSeconds = 0,
                    pinnedMessageId = null,
                    username = "@forkgram",
                    bio = "Официальные служебные уведомления Fork Gram",
                    email = null,
                    subscriberCount = 0
                ),
                ChatThreadEntity(
                    id = savedId,
                    ownerEmail = email,
                    title = "Избранное",
                    subtitle = "Облачное хранилище сообщений",
                    chatTypeName = ChatType.SAVED.name,
                    avatarColorHex = 0xFF229ED9,
                    avatarUri = null,
                    isVerified = false,
                    isPremiumBadge = false,
                    statusGiftKindId = null,
                    lastMessagePreview = "Ваши заметки, фото, файлы и пересланные сообщения",
                    lastMessageTime = timeText,
                    lastMessageTimestamp = now - 30_000,
                    unreadCount = 0,
                    isPinned = false,
                    isArchived = false,
                    isMuted = false,
                    isBlocked = false,
                    autoDeleteSeconds = 0,
                    pinnedMessageId = null,
                    username = null,
                    bio = null,
                    email = null,
                    subscriberCount = 0
                )
            )
        )

        messageDao.upsertMessages(
            listOf(
                ChatMessageEntity(
                    id = UUID.randomUUID().toString(),
                    ownerEmail = email,
                    chatId = serviceId,
                    senderName = "Fork Gram",
                    isOutgoing = false,
                    kindName = MessageKind.TEXT.name,
                    text = "Welcome to Fork Gram, $firstName!\n\nA new sign-in to your account was just completed using your email ($email).\n\nIf this was you, no action is needed.",
                    timestampText = timeText,
                    timestampMillis = now,
                    dateGroup = formatDateGroup(now),
                    replyToId = null,
                    replyPreviewSender = null,
                    replyPreviewText = null,
                    forwardedFrom = null,
                    mediaUri = null,
                    fileName = null,
                    fileSizeText = null,
                    voiceDurationSec = 0,
                    voiceWaveformCsv = "",
                    giftKindId = null,
                    giftNumber = null,
                    giftStarsValue = 0,
                    isNftGift = false,
                    gramAmount = 0.0,
                    reactionKey = null,
                    isEdited = false,
                    isPinned = false,
                    isRead = false
                ),
                ChatMessageEntity(
                    id = UUID.randomUUID().toString(),
                    ownerEmail = email,
                    chatId = savedId,
                    senderName = firstName,
                    isOutgoing = true,
                    kindName = MessageKind.TEXT.name,
                    text = "Избранное: сюда можно сохранять заметки, фотографии, документы, голосовые и пересланные сообщения.",
                    timestampText = timeText,
                    timestampMillis = now - 30_000,
                    dateGroup = formatDateGroup(now),
                    replyToId = null,
                    replyPreviewSender = null,
                    replyPreviewText = null,
                    forwardedFrom = null,
                    mediaUri = null,
                    fileName = null,
                    fileSizeText = null,
                    voiceDurationSec = 0,
                    voiceWaveformCsv = "",
                    giftKindId = null,
                    giftNumber = null,
                    giftStarsValue = 0,
                    isNftGift = false,
                    gramAmount = 0.0,
                    reactionKey = null,
                    isEdited = false,
                    isPinned = false,
                    isRead = true
                )
            )
        )

        // New accounts start cleanly with 0 gifts, 1000 Stars, 100.0 GRAM and active Premium.
        if (remoteApi == null) {
            nftUsernameDao.upsertNftUsernames(
                listOf(
                    NftUsernameEntity("${email}_nft_1", email, "@crypto", 28.0, false, false, "Ультра-редкий NFT", null, "AUCTION", 0.0, 28.0),
                    NftUsernameEntity("${email}_nft_2", email, "@ton", 65.0, false, false, "Легендарный 3-буквенный", null, "AUCTION", 0.0, 65.0),
                    NftUsernameEntity("${email}_nft_3", email, "@fork", 14.5, false, false, "Редкий NFT", null, "SALE", 0.0, 14.5),
                    NftUsernameEntity("${email}_nft_4", email, "@alpha", 19.0, false, false, "Премиум NFT", null, "SALE", 0.0, 19.0),
                    NftUsernameEntity("${email}_nft_5", email, "@gram", 40.0, false, false, "Коллекционный NFT", null, "SALE", 0.0, 40.0),
                    NftUsernameEntity("${email}_nft_6", email, "@neon", 12.0, false, false, "Коллекционный NFT", null, "SALE", 0.0, 12.0)
                )
            )
        }

        txDao.insertTransactions(
            listOf(
                WalletTransactionEntity(
                    id = UUID.randomUUID().toString(),
                    ownerEmail = email,
                    currency = "STARS",
                    amountDisplay = "+1000",
                    isCredit = true,
                    title = "Стартовый баланс Звёзд",
                    subtitle = "Fork Gram",
                    timestampText = timeText,
                    timestampMillis = now
                ),
                WalletTransactionEntity(
                    id = UUID.randomUUID().toString(),
                    ownerEmail = email,
                    currency = "GRAM",
                    amountDisplay = "+100.00 GRAM",
                    isCredit = true,
                    title = "Стартовый баланс Gram",
                    subtitle = "Кошелёк Fork Gram",
                    timestampText = timeText,
                    timestampMillis = now
                )
            )
        )
    }

    private suspend fun copyUriToAppStorage(uri: Uri, folder: String, filename: String): String? =
        withContext(Dispatchers.IO) {
            try {
                val dir = File(context.filesDir, folder).apply { mkdirs() }
                val dest = File(dir, filename.replace(Regex("[^a-zA-Z0-9._-]"), "_"))
                context.contentResolver.openInputStream(uri)?.use { input ->
                    dest.outputStream().use { output ->
                        input.copyTo(output)
                    }
                } ?: return@withContext null
                dest.absolutePath
            } catch (_: Exception) {
                null
            }
        }

    private fun queryFileMeta(uri: Uri): Pair<String, String> {
        var name = "document.bin"
        var sizeStr = "128 КБ"
        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx >= 0) name = cursor.getString(nameIdx) ?: name
                    if (sizeIdx >= 0) {
                        val bytes = cursor.getLong(sizeIdx)
                        sizeStr = when {
                            bytes >= 1024 * 1024 -> String.format(Locale.US, "%.1f МБ", bytes / (1024f * 1024f))
                            bytes >= 1024 -> "${bytes / 1024} КБ"
                            bytes > 0 -> "$bytes Б"
                            else -> "Файл"
                        }
                    }
                }
            }
        } catch (_: Exception) {
        }
        return name to sizeStr
    }

    private fun ChatMessage.previewSummary(): String = when (kind) {
        MessageKind.PHOTO -> if (text.isNotBlank()) "Фотография: $text" else "Фотография"
        MessageKind.FILE -> "Файл: ${fileName ?: text}"
        MessageKind.VOICE -> "Голосовое сообщение (${formatDuration(voiceDurationSec)})"
        MessageKind.GIFT -> "Подарок: ${giftKind?.title ?: text}"
        MessageKind.GRAM_TRANSFER -> "Перевод ${formatGram(gramAmount)} GRAM"
        MessageKind.LOCATION -> "Геопозиция: $text"
        MessageKind.POLL -> "Опрос: ${PollData.fromJson(text)?.question ?: "Голосование"}"
        else -> text
    }

    companion object {
        fun formatTime(millis: Long): String =
            SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(millis))

        fun formatDateGroup(millis: Long): String =
            SimpleDateFormat("d MMMM", Locale("ru")).format(Date(millis))

        fun formatDuration(sec: Int): String {
            val m = sec / 60
            val s = sec % 60
            return "%d:%02d".format(m, s)
        }

        fun formatGram(amount: Double): String =
            String.format(Locale.US, "%.2f", amount)
    }
}
