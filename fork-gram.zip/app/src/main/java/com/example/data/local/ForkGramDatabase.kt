package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        UserAccountEntity::class,
        ChatFolderEntity::class,
        ChatThreadEntity::class,
        ChatMessageEntity::class,
        ContactEntity::class,
        OwnedGiftEntity::class,
        GiftCollectionEntity::class,
        NftUsernameEntity::class,
        WalletTransactionEntity::class,
        ProfilePostEntity::class
    ],
    version = 4,
    exportSchema = false
)
abstract class ForkGramDatabase : RoomDatabase() {
    abstract fun userAccountDao(): UserAccountDao
    abstract fun chatFolderDao(): ChatFolderDao
    abstract fun chatThreadDao(): ChatThreadDao
    abstract fun chatMessageDao(): ChatMessageDao
    abstract fun contactDao(): ContactDao
    abstract fun ownedGiftDao(): OwnedGiftDao
    abstract fun giftCollectionDao(): GiftCollectionDao
    abstract fun nftUsernameDao(): NftUsernameDao
    abstract fun walletTransactionDao(): WalletTransactionDao
    abstract fun profilePostDao(): ProfilePostDao

    companion object {
        @Volatile
        private var INSTANCE: ForkGramDatabase? = null

        fun getInstance(context: Context): ForkGramDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    ForkGramDatabase::class.java,
                    "fork_gram_db"
                )
                    .fallbackToDestructiveMigration(true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
