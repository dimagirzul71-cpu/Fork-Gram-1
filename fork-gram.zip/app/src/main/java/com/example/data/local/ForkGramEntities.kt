package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.ChatFolder
import com.example.data.model.ChatMessage
import com.example.data.model.ChatThread
import com.example.data.model.ChatType
import com.example.data.model.ContactItem
import com.example.data.model.GiftBackdrop
import com.example.data.model.GiftCollectionTab
import com.example.data.model.GiftKind
import com.example.data.model.GiftSymbol
import com.example.data.model.MessageKind
import com.example.data.model.NftUsernameItem
import com.example.data.model.OwnedGift
import com.example.data.model.ProfilePost
import com.example.data.model.UserAccount
import com.example.data.model.WalletTransaction

@Entity(tableName = "user_accounts")
data class UserAccountEntity(
    @PrimaryKey val email: String,
    val firstName: String,
    val lastName: String,
    val username: String,
    val activeNftUsername: String?,
    val bio: String,
    val birthday: String,
    val avatarUri: String?,
    val isPremium: Boolean,
    val starsBalance: Long,
    val gramBalance: Double,
    val level: Int,
    val statusGiftKindId: String?,
    val statusBackdropId: String?,
    val statusSymbolId: String?,
    val createdAt: Long
)

@Entity(tableName = "chat_folders")
data class ChatFolderEntity(
    @PrimaryKey val id: String,
    val ownerEmail: String,
    val name: String,
    val includeTypesCsv: String,
    val includedChatIdsCsv: String,
    val onlyUnread: Boolean,
    val orderIndex: Int
)

@Entity(tableName = "chat_threads")
data class ChatThreadEntity(
    @PrimaryKey val id: String,
    val ownerEmail: String,
    val title: String,
    val subtitle: String,
    val chatTypeName: String,
    val avatarColorHex: Long,
    val avatarUri: String?,
    val isVerified: Boolean,
    val isPremiumBadge: Boolean,
    val statusGiftKindId: String?,
    val lastMessagePreview: String,
    val lastMessageTime: String,
    val lastMessageTimestamp: Long,
    val unreadCount: Int,
    val isPinned: Boolean,
    val isArchived: Boolean,
    val isMuted: Boolean,
    val isBlocked: Boolean,
    val autoDeleteSeconds: Int,
    val pinnedMessageId: String?,
    val username: String?,
    val bio: String?,
    val email: String?,
    val subscriberCount: Int,
    val draftText: String = "",
    val isOnline: Boolean = false,
    val isTyping: Boolean = false,
    val isLastMessageOutgoing: Boolean = false,
    val isLastOutgoingRead: Boolean = true
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val ownerEmail: String,
    val chatId: String,
    val senderName: String,
    val isOutgoing: Boolean,
    val kindName: String,
    val text: String,
    val timestampText: String,
    val timestampMillis: Long,
    val dateGroup: String,
    val replyToId: String?,
    val replyPreviewSender: String?,
    val replyPreviewText: String?,
    val forwardedFrom: String?,
    val mediaUri: String?,
    val fileName: String?,
    val fileSizeText: String?,
    val voiceDurationSec: Int,
    val voiceWaveformCsv: String,
    val giftKindId: String?,
    val giftNumber: Int?,
    val giftStarsValue: Int,
    val isNftGift: Boolean,
    val gramAmount: Double,
    val reactionKey: String?,
    val isEdited: Boolean,
    val isPinned: Boolean,
    val isRead: Boolean
)

@Entity(tableName = "contacts")
data class ContactEntity(
    @PrimaryKey val id: String,
    val ownerEmail: String,
    val firstName: String,
    val lastName: String,
    val email: String,
    val username: String,
    val bio: String,
    val statusText: String,
    val isOnline: Boolean,
    val avatarColorHex: Long,
    val statusGiftKindId: String?,
    val isBlocked: Boolean
)

@Entity(tableName = "owned_gifts")
data class OwnedGiftEntity(
    @PrimaryKey val id: String,
    val ownerEmail: String,
    val giftKindId: String,
    val editionNumber: Int,
    val collectionName: String,
    val modelName: String,
    val modelRarity: String,
    val backdropId: String,
    val symbolId: String,
    val senderName: String,
    val messageText: String,
    val starsValue: Int,
    val isNft: Boolean,
    val isPinned: Boolean,
    val isWornAsStatus: Boolean,
    val receivedAt: Long
)

@Entity(tableName = "gift_collections")
data class GiftCollectionEntity(
    @PrimaryKey val id: String,
    val ownerEmail: String,
    val name: String,
    val createdAt: Long
)

@Entity(tableName = "nft_usernames")
data class NftUsernameEntity(
    @PrimaryKey val id: String,
    val ownerEmail: String,
    val handle: String,
    val priceGram: Double,
    val isOwned: Boolean,
    val isEquipped: Boolean,
    val rarityTier: String,
    val acquiredAt: Long?,
    val status: String = if (isOwned) "OWNED" else "SALE",
    val topBidGram: Double = 0.0,
    val minBidGram: Double = priceGram,
    val topBidderName: String? = null,
    val isHighestBidder: Boolean = false,
    val bidsCount: Int = 0,
    val endsAt: Long? = null,
    val itemOwnerEmail: String? = null,
    val ownerName: String = "Fragment",
    val fragmentUrl: String = ""
)

@Entity(tableName = "wallet_transactions")
data class WalletTransactionEntity(
    @PrimaryKey val id: String,
    val ownerEmail: String,
    val currency: String,
    val amountDisplay: String,
    val isCredit: Boolean,
    val title: String,
    val subtitle: String,
    val timestampText: String,
    val timestampMillis: Long
)

@Entity(tableName = "profile_posts")
data class ProfilePostEntity(
    @PrimaryKey val id: String,
    val ownerEmail: String,
    val mediaUrl: String,
    val caption: String,
    val isArchived: Boolean,
    val createdAt: Long
)

fun UserAccountEntity.toDomain() = UserAccount(
    email = email,
    firstName = firstName,
    lastName = lastName,
    username = username,
    activeNftUsername = activeNftUsername,
    bio = bio,
    birthday = birthday,
    avatarUri = avatarUri,
    isPremium = isPremium,
    starsBalance = starsBalance,
    gramBalance = gramBalance,
    level = level,
    statusGiftKind = GiftKind.entries.firstOrNull { it.id == statusGiftKindId },
    statusBackdrop = GiftBackdrop.entries.firstOrNull { it.id == statusBackdropId },
    statusSymbol = GiftSymbol.entries.firstOrNull { it.id == statusSymbolId },
    createdAt = createdAt
)

fun ChatFolderEntity.toDomain() = ChatFolder(
    id = id,
    name = name,
    includeTypes = includeTypesCsv.split(",")
        .filter { it.isNotBlank() }
        .mapNotNull { name -> ChatType.entries.firstOrNull { it.name == name } }
        .toSet(),
    includedChatIds = includedChatIdsCsv.split(",").filter { it.isNotBlank() }.toSet(),
    onlyUnread = onlyUnread,
    orderIndex = orderIndex
)

fun ChatThreadEntity.toDomain() = ChatThread(
    id = id,
    title = title,
    subtitle = subtitle,
    chatType = ChatType.entries.firstOrNull { it.name == chatTypeName } ?: ChatType.DIRECT,
    avatarColorHex = avatarColorHex,
    avatarUri = avatarUri,
    isVerified = isVerified,
    isPremiumBadge = isPremiumBadge,
    statusGiftKind = GiftKind.entries.firstOrNull { it.id == statusGiftKindId },
    lastMessagePreview = lastMessagePreview,
    lastMessageTime = lastMessageTime,
    lastMessageTimestamp = lastMessageTimestamp,
    unreadCount = unreadCount,
    isPinned = isPinned,
    isArchived = isArchived,
    isMuted = isMuted,
    isBlocked = isBlocked,
    autoDeleteSeconds = autoDeleteSeconds,
    pinnedMessageId = pinnedMessageId,
    username = username,
    bio = bio,
    email = email,
    subscriberCount = subscriberCount,
    draftText = draftText,
    isOnline = isOnline,
    isTyping = isTyping,
    isLastMessageOutgoing = isLastMessageOutgoing,
    isLastOutgoingRead = isLastOutgoingRead
)

fun ChatMessageEntity.toDomain() = ChatMessage(
    id = id,
    chatId = chatId,
    senderName = senderName,
    isOutgoing = isOutgoing,
    kind = MessageKind.entries.firstOrNull { it.name == kindName } ?: MessageKind.TEXT,
    text = text,
    timestampText = timestampText,
    timestampMillis = timestampMillis,
    dateGroup = dateGroup,
    replyToId = replyToId,
    replyPreviewSender = replyPreviewSender,
    replyPreviewText = replyPreviewText,
    forwardedFrom = forwardedFrom,
    mediaUri = mediaUri,
    fileName = fileName,
    fileSizeText = fileSizeText,
    voiceDurationSec = voiceDurationSec,
    voiceWaveform = voiceWaveformCsv.split(",").mapNotNull { it.toFloatOrNull() },
    giftKind = GiftKind.entries.firstOrNull { it.id == giftKindId },
    giftNumber = giftNumber,
    giftStarsValue = giftStarsValue,
    isNftGift = isNftGift,
    gramAmount = gramAmount,
    reactionKey = reactionKey,
    isEdited = isEdited,
    isPinned = isPinned,
    isRead = isRead
)

fun ContactEntity.toDomain() = ContactItem(
    id = id,
    firstName = firstName,
    lastName = lastName,
    email = email,
    username = username,
    bio = bio,
    statusText = statusText,
    isOnline = isOnline,
    avatarColorHex = avatarColorHex,
    statusGiftKind = GiftKind.entries.firstOrNull { it.id == statusGiftKindId },
    isBlocked = isBlocked
)

fun OwnedGiftEntity.toDomain(): OwnedGift {
    val kind = GiftKind.entries.firstOrNull { it.id == giftKindId } ?: GiftKind.PLUSH_PEPE
    return OwnedGift(
        id = id,
        giftKind = kind,
        editionNumber = editionNumber,
        collectionName = collectionName,
        modelName = modelName,
        modelRarity = modelRarity,
        backdrop = GiftBackdrop.entries.firstOrNull { it.id == backdropId } ?: kind.defaultBackdrop,
        symbol = GiftSymbol.entries.firstOrNull { it.id == symbolId } ?: kind.defaultSymbol,
        senderName = senderName,
        messageText = messageText,
        starsValue = starsValue,
        isNft = isNft,
        isPinned = isPinned,
        isWornAsStatus = isWornAsStatus,
        receivedAt = receivedAt
    )
}

fun GiftCollectionEntity.toDomain() = GiftCollectionTab(
    id = id,
    name = name,
    createdAt = createdAt
)

fun NftUsernameEntity.toDomain() = NftUsernameItem(
    id = id,
    handle = handle,
    priceGram = priceGram,
    isOwned = isOwned,
    isEquipped = isEquipped,
    rarityTier = rarityTier,
    acquiredAt = acquiredAt,
    status = status,
    topBidGram = topBidGram,
    minBidGram = minBidGram,
    topBidderName = topBidderName,
    isHighestBidder = isHighestBidder,
    bidsCount = bidsCount,
    endsAt = endsAt,
    ownerEmail = itemOwnerEmail,
    ownerName = ownerName,
    fragmentUrl = fragmentUrl.ifBlank { "http://forkgram.xsph.ru/fragment?q=${handle.removePrefix("@")}" }
)

fun WalletTransactionEntity.toDomain() = WalletTransaction(
    id = id,
    currency = currency,
    amountDisplay = amountDisplay,
    isCredit = isCredit,
    title = title,
    subtitle = subtitle,
    timestampText = timestampText,
    timestampMillis = timestampMillis
)

fun ProfilePostEntity.toDomain() = ProfilePost(
    id = id,
    ownerEmail = ownerEmail,
    mediaUrl = mediaUrl,
    caption = caption,
    isArchived = isArchived,
    createdAt = createdAt
)
