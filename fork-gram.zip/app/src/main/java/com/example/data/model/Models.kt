package com.example.data.model

enum class ChatType {
    DIRECT,
    GROUP,
    CHANNEL,
    SERVICE,
    SAVED,
    SECRET
}

enum class MessageKind {
    TEXT,
    PHOTO,
    FILE,
    VOICE,
    GIFT,
    GRAM_TRANSFER,
    LOCATION,
    POLL,
    SYSTEM
}

enum class ReactionType(val key: String, val label: String) {
    HEART("heart", "Сердце"),
    THUMBS_UP("thumbs_up", "Класс"),
    FIRE("fire", "Огонь"),
    STAR("star", "Звезда"),
    SPARKLES("sparkles", "Искры"),
    CROWN("crown", "Корона")
}


/**
 * Рарность как в Telegram: rarity_per_mille — сколько подарков из 1000 улучшенных получают этот атрибут,
 * суммы по категории = 100%. Сырые значения в enum/списках моделей — это веса; здесь они нормализуются,
 * поэтому показанный процент = реальная вероятность выпадения при улучшении.
 */
object GiftRarity {
    fun weight(text: String): Double =
        text.trim().removeSuffix("%").replace(',', '.').toDoubleOrNull()?.takeIf { it > 0.0 } ?: 1.0

    fun format(percent: Double): String {
        val rounded = Math.round(percent * 10.0) / 10.0
        return if (rounded % 1.0 == 0.0) "${rounded.toInt()}%" else "$rounded%"
    }

    fun <T> normalized(items: List<T>, item: T, weightOf: (T) -> Double): String {
        val total = items.sumOf(weightOf)
        if (total <= 0.0) return "—"
        return format(weightOf(item) / total * 100.0)
    }

    fun <T> roll(items: List<T>, weightOf: (T) -> Double, random: java.util.Random = java.util.Random()): T {
        val total = items.sumOf(weightOf)
        var r = random.nextDouble() * total
        for (it in items) {
            r -= weightOf(it)
            if (r < 0.0) return it
        }
        return items.last()
    }

    fun modelsNormalized(models: List<Pair<String, String>>): List<Pair<String, String>> =
        models.map { m -> m.first to normalized(models, m) { weight(it.second) } }

    fun rollModel(models: List<Pair<String, String>>): Pair<String, String> {
        val picked = roll(models, { weight(it.second) })
        return picked.first to normalized(models, picked) { weight(it.second) }
    }

    fun rollBackdrop(): GiftBackdrop = roll(GiftBackdrop.entries, { weight(it.rarityText) })
    fun rollSymbol(): GiftSymbol = roll(GiftSymbol.entries, { weight(it.rarityText) })
}

enum class GiftSymbol(val id: String, val title: String, val rarityText: String) {
    DIAMOND("diamond", "Бриллиант", "0.8%"),
    CROWN("crown", "Корона", "1.1%"),
    STAR("star", "Звезда", "1.5%"),
    SPARKLE("sparkle", "Сияние", "2.0%"),
    MOON("moon", "Полумесяц", "1.3%"),
    HEART("heart", "Сердце", "1.8%"),
    BOLT("bolt", "Молния", "0.9%"),
    LEAF("leaf", "Клевер", "2.4%");

    /** Реальная вероятность (нормализованный вес). */
    val rarityPercent: String
        get() = GiftRarity.normalized(entries, this) { GiftRarity.weight(it.rarityText) }
}

enum class GiftBackdrop(
    val id: String,
    val title: String,
    val centerHex: Long,
    val edgeHex: Long,
    val patternHex: Long,
    val rarityText: String
) {
    ONYX_BLACK("onyx", "Onyx Black", 0xFF3E4652, 0xFF1A1F26, 0xFF748091, "1.2%"),
    SAPPHIRE("sapphire", "Sapphire", 0xFF428AD1, 0xFF215287, 0xFF8CC8FF, "1.5%"),
    EMERALD("emerald", "Emerald", 0xFF43AF7E, 0xFF1D6143, 0xFF8FEBC1, "1.4%"),
    AMBER_GOLD("amber", "Amber Gold", 0xFFDF913A, 0xFF935017, 0xFFFFCF80, "1.1%"),
    CYBER_PURPLE("cyber", "Cyber Purple", 0xFF8F61DD, 0xFF502A8F, 0xFFCBAEFF, "0.9%"),
    CRIMSON_VELVET("crimson", "Crimson Velvet", 0xFFD14F62, 0xFF7A2130, 0xFFFF9AA9, "1.6%"),
    MINT_FROST("mint", "Mint Frost", 0xFF4CBAB4, 0xFF1E6B68, 0xFFA2F7F2, "2.0%"),
    ROSE_QUARTZ("rose", "Rose Quartz", 0xFFCC70A3, 0xFF78315A, 0xFFFFB7E0, "1.8%"),
    MIDNIGHT_INDIGO("midnight", "Midnight Indigo", 0xFF4B5EC0, 0xFF212C6E, 0xFF92A4FF, "1.0%"),
    BRONZE_DUSK("bronze", "Bronze Dusk", 0xFFB06D56, 0xFF663627, 0xFFEEAF9A, "2.2%"),
    COPPER("copper", "Copper", 0xFFCA7D56, 0xFF7D4226, 0xFFFFBE9B, "1.5%"),
    LEMONGRASS("lemongrass", "Lemongrass", 0xFF7FB84E, 0xFF426E23, 0xFFC5F299, "1.5%"),
    SILVER_BLUE("silver_blue", "Silver Blue", 0xFF7496B8, 0xFF3B5674, 0xFFB8D4F0, "1.2%"),
    PACIFIC_CYAN("pacific_cyan", "Pacific Cyan", 0xFF4FA7C4, 0xFF23647C, 0xFF9FE4FA, "1.3%");

    /** Реальная вероятность (нормализованный вес). */
    val rarityPercent: String
        get() = GiftRarity.normalized(entries, this) { GiftRarity.weight(it.rarityText) }
}

enum class GiftKind(
    val id: String,
    val title: String,
    val fragmentSlug: String,
    val linkSlug: String,
    val baseStars: Int,
    val upgradeStars: Int,
    val defaultBackdrop: GiftBackdrop,
    val defaultSymbol: GiftSymbol,
    val models: List<Pair<String, String>>,
    val totalIssued: Int,
    val validDemoEditions: List<Int>
) {
    PLUSH_PEPE(
        id = "plush_pepe",
        title = "Plush Pepe",
        fragmentSlug = "plushpepe",
        linkSlug = "PlushPepe",
        baseStars = 500,
        upgradeStars = 350,
        defaultBackdrop = GiftBackdrop.COPPER,
        defaultSymbol = GiftSymbol.CROWN,
        models = listOf(
            "Marble" to "0.7%",
            "Emerald King" to "0.5%",
            "Cozy Hoodie" to "1.4%",
            "Classic Plush" to "2.5%"
        ),
        totalIssued = 2850,
        validDemoEditions = listOf(144, 1)
    ),
    DUROVS_CAP(
        id = "durovs_cap",
        title = "Durov's Cap",
        fragmentSlug = "durovscap",
        linkSlug = "DurovsCap",
        baseStars = 350,
        upgradeStars = 300,
        defaultBackdrop = GiftBackdrop.LEMONGRASS,
        defaultSymbol = GiftSymbol.DIAMOND,
        models = listOf(
            "Voltage" to "0.8%",
            "Onyx Classic" to "1.1%",
            "Cotton Candy" to "1.6%",
            "Tron Edition" to "0.6%"
        ),
        totalIssued = 4800,
        validDemoEditions = listOf(37, 1)
    ),
    LUNAR_SNAKE(
        id = "lunar_snake",
        title = "Lunar Snake",
        fragmentSlug = "lunarsnake",
        linkSlug = "LunarSnake",
        baseStars = 200,
        upgradeStars = 250,
        defaultBackdrop = GiftBackdrop.SILVER_BLUE,
        defaultSymbol = GiftSymbol.STAR,
        models = listOf(
            "Jade Serpent" to "0.9%",
            "Festive Emerald" to "1.5%",
            "Royal Sapphire" to "1.2%",
            "Crimson Dragon" to "1.8%"
        ),
        totalIssued = 45000,
        validDemoEditions = listOf(47, 1)
    ),
    LOL_POP(
        id = "lol_pop",
        title = "Lol Pop",
        fragmentSlug = "lolpop",
        linkSlug = "LolPop",
        baseStars = 100,
        upgradeStars = 150,
        defaultBackdrop = GiftBackdrop.PACIFIC_CYAN,
        defaultSymbol = GiftSymbol.SPARKLE,
        models = listOf(
            "Rising Star" to "1.2%",
            "Neon Swirl" to "1.9%",
            "Midnight Cherry" to "0.8%",
            "Rainbow Pop" to "2.4%"
        ),
        totalIssued = 120000,
        validDemoEditions = listOf(202, 1)
    ),
    HEART_LOCKET(
        id = "heart_locket",
        title = "Heart Locket",
        fragmentSlug = "heartlocket",
        linkSlug = "HeartLocket",
        baseStars = 450,
        upgradeStars = 300,
        defaultBackdrop = GiftBackdrop.ROSE_QUARTZ,
        defaultSymbol = GiftSymbol.HEART,
        models = listOf(
            "Rebellion" to "0.9%",
            "Rose Gold" to "1.5%",
            "Diamond Key" to "0.6%",
            "Velvet Heart" to "2.1%"
        ),
        totalIssued = 9500,
        validDemoEditions = listOf(45, 1)
    ),
    ETERNAL_ROSE(
        id = "eternal_rose",
        title = "Eternal Rose",
        fragmentSlug = "eternalrose",
        linkSlug = "EternalRose",
        baseStars = 300,
        upgradeStars = 250,
        defaultBackdrop = GiftBackdrop.MIDNIGHT_INDIGO,
        defaultSymbol = GiftSymbol.LEAF,
        models = listOf(
            "Glass Dome" to "1.3%",
            "Crystal Bloom" to "0.8%",
            "Golden Thorn" to "0.5%",
            "Crimson Dew" to "2.0%"
        ),
        totalIssued = 18000,
        validDemoEditions = listOf(1)
    ),
    CRYSTAL_BALL(
        id = "crystal_ball",
        title = "Crystal Ball",
        fragmentSlug = "crystalball",
        linkSlug = "CrystalBall",
        baseStars = 250,
        upgradeStars = 250,
        defaultBackdrop = GiftBackdrop.CYBER_PURPLE,
        defaultSymbol = GiftSymbol.MOON,
        models = listOf(
            "Tim Burton" to "1.1%",
            "Astral Nebula" to "1.4%",
            "Solar Eclipse" to "0.7%",
            "Frost Oracle" to "2.2%"
        ),
        totalIssued = 26000,
        validDemoEditions = listOf(77, 1)
    ),
    TOY_BEAR(
        id = "toy_bear",
        title = "Toy Bear",
        fragmentSlug = "toybear",
        linkSlug = "ToyBear",
        baseStars = 150,
        upgradeStars = 200,
        defaultBackdrop = GiftBackdrop.BRONZE_DUSK,
        defaultSymbol = GiftSymbol.HEART,
        models = listOf(
            "Velvet Teddy" to "1.8%",
            "Honey Bow" to "1.4%",
            "Starlight Bear" to "0.9%",
            "Classic Stitch" to "2.6%"
        ),
        totalIssued = 52000,
        validDemoEditions = listOf(10)
    ),
    SIGNET_RING(
        id = "signet_ring",
        title = "Signet Ring",
        fragmentSlug = "signetring",
        linkSlug = "SignetRing",
        baseStars = 400,
        upgradeStars = 300,
        defaultBackdrop = GiftBackdrop.EMERALD,
        defaultSymbol = GiftSymbol.CROWN,
        models = listOf(
            "Platinum" to "0.8%",
            "Imperial Gold" to "1.2%",
            "Emerald Seal" to "0.6%",
            "Obsidian Band" to "1.9%"
        ),
        totalIssued = 15000,
        validDemoEditions = listOf(50, 1)
    ),
    ION_GEM(
        id = "ion_gem",
        title = "Ion Gem",
        fragmentSlug = "iongem",
        linkSlug = "IonGem",
        baseStars = 350,
        upgradeStars = 300,
        defaultBackdrop = GiftBackdrop.MINT_FROST,
        defaultSymbol = GiftSymbol.BOLT,
        models = listOf(
            "Plasma Core" to "0.9%",
            "Cryo Prism" to "1.3%",
            "Quantum Shard" to "0.5%",
            "Azure Reactor" to "2.0%"
        ),
        totalIssued = 11200,
        validDemoEditions = listOf(1)
    ),
    SNOW_GLOBE(
        id = "snow_globe",
        title = "Snow Globe",
        fragmentSlug = "snowglobe",
        linkSlug = "SnowGlobe",
        baseStars = 200,
        upgradeStars = 200,
        defaultBackdrop = GiftBackdrop.SAPPHIRE,
        defaultSymbol = GiftSymbol.STAR,
        models = listOf(
            "Emerald" to "1.6%",
            "Northern Lights" to "0.9%",
            "Golden Pine" to "1.2%",
            "Winter Frost" to "2.5%"
        ),
        totalIssued = 34000,
        validDemoEditions = listOf(10, 1)
    ),
    STAR_TROPHY_2025(
        id = "star_trophy_2025",
        title = "Big Year 2025",
        fragmentSlug = "bigyear",
        linkSlug = "BigYear",
        baseStars = 250,
        upgradeStars = 250,
        defaultBackdrop = GiftBackdrop.AMBER_GOLD,
        defaultSymbol = GiftSymbol.SPARKLE,
        models = listOf(
            "Frida Kahlo" to "1.1%",
            "Cyber 2025" to "1.4%",
            "Solar Gold" to "0.7%",
            "Neon Ice" to "1.8%"
        ),
        totalIssued = 29000,
        validDemoEditions = listOf(100, 1)
    )
}

enum class WallpaperTheme(val title: String) {
    CLASSIC_GREEN("Классические зелёные"),
    OCEAN_BLUE("Океанский бриз"),
    LAVENDER_DUSK("Лавандовый закат"),
    MIDNIGHT_DARK("Ночное небо")
}

enum class MainTab {
    CHATS,
    CONTACTS,
    SETTINGS,
    PROFILE
}

data class UserAccount(
    val email: String,
    val firstName: String,
    val lastName: String,
    val username: String,
    val activeNftUsername: String?,
    val bio: String,
    val birthday: String,
    val avatarUri: String?,
    val isPremium: Boolean,
    val starsBalance: Long,
    val gramBalance: Double,
    val level: Int,
    val statusGiftKind: GiftKind?,
    val statusBackdrop: GiftBackdrop?,
    val statusSymbol: GiftSymbol?,
    val createdAt: Long
) {
    val fullName: String
        get() = listOf(firstName, lastName).filter { it.isNotBlank() }.joinToString(" ")

    val displayHandle: String
        get() = activeNftUsername?.takeIf { it.isNotBlank() } ?: username
}

data class ChatFolder(
    val id: String,
    val name: String,
    val includeTypes: Set<ChatType>,
    val includedChatIds: Set<String>,
    val onlyUnread: Boolean = false,
    val orderIndex: Int = 0
)

data class ChatThread(
    val id: String,
    val title: String,
    val subtitle: String,
    val chatType: ChatType,
    val avatarColorHex: Long,
    val avatarUri: String?,
    val isVerified: Boolean,
    val isPremiumBadge: Boolean,
    val statusGiftKind: GiftKind?,
    val lastMessagePreview: String,
    val lastMessageTime: String,
    val lastMessageTimestamp: Long,
    val unreadCount: Int,
    val isPinned: Boolean,
    val isArchived: Boolean,
    val isMuted: Boolean,
    val isBlocked: Boolean,
    val autoDeleteSeconds: Int,
    val pinnedMessageId: String?,
    val username: String?,
    val bio: String?,
    val email: String?,
    val subscriberCount: Int,
    val draftText: String = "",
    val isOnline: Boolean = false,
    val isTyping: Boolean = false,
    val isLastMessageOutgoing: Boolean = false,
    val isLastOutgoingRead: Boolean = true
)

data class ChatMessage(
    val id: String,
    val chatId: String,
    val senderName: String,
    val isOutgoing: Boolean,
    val kind: MessageKind,
    val text: String,
    val timestampText: String,
    val timestampMillis: Long,
    val dateGroup: String,
    val replyToId: String? = null,
    val replyPreviewSender: String? = null,
    val replyPreviewText: String? = null,
    val forwardedFrom: String? = null,
    val mediaUri: String? = null,
    val fileName: String? = null,
    val fileSizeText: String? = null,
    val voiceDurationSec: Int = 0,
    val voiceWaveform: List<Float> = emptyList(),
    val giftKind: GiftKind? = null,
    val giftNumber: Int? = null,
    val giftStarsValue: Int = 0,
    val isNftGift: Boolean = false,
    val gramAmount: Double = 0.0,
    val reactionKey: String? = null,
    val isEdited: Boolean = false,
    val isPinned: Boolean = false,
    val isRead: Boolean = true
) {
    val giftLinkUrl: String?
        get() = giftKind?.let { "http://forkgram.xsph.ru/nft/${it.linkSlug}-${giftNumber ?: 1}" }

    val forkGramGiftLinkUrl: String?
        get() = giftKind?.let { "http://forkgram.xsph.ru/nft/${it.linkSlug}-${giftNumber ?: 1}" }
}

data class ContactItem(
    val id: String,
    val firstName: String,
    val lastName: String,
    val email: String,
    val username: String,
    val bio: String,
    val statusText: String,
    val isOnline: Boolean,
    val avatarColorHex: Long,
    val statusGiftKind: GiftKind?,
    val isBlocked: Boolean
) {
    val fullName: String
        get() = listOf(firstName, lastName).filter { it.isNotBlank() }.joinToString(" ")
}

data class OwnedGift(
    val id: String,
    val giftKind: GiftKind,
    val editionNumber: Int,
    val collectionName: String,
    val modelName: String,
    val modelRarity: String,
    val backdrop: GiftBackdrop,
    val symbol: GiftSymbol,
    val senderName: String,
    val messageText: String,
    val starsValue: Int,
    val isNft: Boolean,
    val isPinned: Boolean,
    val isWornAsStatus: Boolean,
    val receivedAt: Long,
    val ownerName: String = "",
    val ownerHandle: String = "",
    val forSaleGram: Double? = null
) {
    val nftUrl: String
        get() = "http://forkgram.xsph.ru/nft/${giftKind.linkSlug}-$editionNumber"

    val forkGramNftUrl: String
        get() = "http://forkgram.xsph.ru/nft/${giftKind.linkSlug}-$editionNumber"
}

data class GiftCollectionTab(
    val id: String,
    val name: String,
    val createdAt: Long
)

data class NftUsernameItem(
    val id: String,
    val handle: String,
    val priceGram: Double,
    val isOwned: Boolean,
    val isEquipped: Boolean,
    val rarityTier: String,
    val acquiredAt: Long?,
    val status: String = if (isOwned) "OWNED" else "SALE",
    val topBidGram: Double = 0.0,
    val minBidGram: Double = priceGram,
    val topBidderName: String? = null,
    val isHighestBidder: Boolean = false,
    val bidsCount: Int = 0,
    val endsAt: Long? = null,
    val ownerEmail: String? = null,
    val ownerName: String = "Fragment",
    val fragmentUrl: String = "http://forkgram.xsph.ru/fragment?q=${handle.removePrefix("@")}"
)

data class FragmentNftGiftListing(
    val id: String,
    val sellerEmail: String,
    val sellerName: String,
    val priceGram: Double,
    val gift: OwnedGift,
    val listedAt: Long
)

data class FragmentMarketPayload(
    val usernames: List<NftUsernameItem>,
    val giftListings: List<FragmentNftGiftListing>,
    val updatedGramBalance: Double? = null,
    val activeNftUsername: String? = null
)

data class PollOption(
    val text: String,
    val voters: List<String> = emptyList()
)

data class PollData(
    val question: String,
    val options: List<PollOption>
) {
    val totalVotes: Int
        get() = options.sumOf { it.voters.size }

    fun toJsonString(): String {
        val root = org.json.JSONObject()
        root.put("question", question)
        val arr = org.json.JSONArray()
        options.forEach { opt ->
            val obj = org.json.JSONObject()
            obj.put("text", opt.text)
            val vArr = org.json.JSONArray()
            opt.voters.forEach { vArr.put(it) }
            obj.put("voters", vArr)
            arr.put(obj)
        }
        root.put("options", arr)
        return root.toString()
    }

    companion object {
        fun fromJson(raw: String): PollData? {
            return runCatching {
                val root = org.json.JSONObject(raw)
                val q = root.optString("question", "").takeIf { it.isNotBlank() } ?: return@runCatching null
                val arr = root.optJSONArray("options") ?: return@runCatching null
                val opts = buildList {
                    for (i in 0 until arr.length()) {
                        val obj = arr.optJSONObject(i) ?: continue
                        val text = obj.optString("text", "")
                        if (text.isBlank()) continue
                        val vArr = obj.optJSONArray("voters") ?: org.json.JSONArray()
                        val voters = buildList {
                            for (j in 0 until vArr.length()) {
                                vArr.optString(j).takeIf { it.isNotBlank() }?.let(::add)
                            }
                        }
                        add(PollOption(text = text, voters = voters))
                    }
                }
                if (opts.size < 2) return@runCatching null
                PollData(question = q, options = opts)
            }.getOrNull()
        }
    }
}

data class WalletTransaction(
    val id: String,
    val currency: String,
    val amountDisplay: String,
    val isCredit: Boolean,
    val title: String,
    val subtitle: String,
    val timestampText: String,
    val timestampMillis: Long
)

data class ProfilePost(
    val id: String,
    val ownerEmail: String,
    val mediaUrl: String,
    val caption: String,
    val isArchived: Boolean,
    val createdAt: Long
)

data class DeviceSession(
    val id: String,
    val ownerEmail: String,
    val deviceName: String,
    val platform: String,
    val location: String,
    val lastActiveAt: Long,
    val isCurrent: Boolean
)

data class PeerProfileData(
    val account: UserAccount,
    val gifts: List<OwnedGift>,
    val posts: List<ProfilePost>,
    val isOnline: Boolean,
    val lastSeenAt: Long,
    val isTypingToMe: Boolean
)

data class CallSessionState(
    val chatId: String,
    val peerName: String,
    val avatarUri: String?,
    val avatarColorHex: Long,
    val isVideo: Boolean,
    val isMuted: Boolean = false,
    val isSpeaker: Boolean = false,
    val startedAtMillis: Long = System.currentTimeMillis(),
    val statusLabel: String = "Ожидание ответа..."
)
