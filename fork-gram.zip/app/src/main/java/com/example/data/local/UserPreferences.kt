package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.WallpaperTheme
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.util.UUID

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "fork_gram_prefs")

data class AppPreferencesState(
    val activeEmail: String? = null,
    val isDarkTheme: Boolean = false,
    val wallpaperTheme: WallpaperTheme = WallpaperTheme.CLASSIC_GREEN,
    val chatTextSizeSp: Int = 15,
    val animationsEnabled: Boolean = true,
    val powerSavingEnabled: Boolean = false,
    val notificationsEnabled: Boolean = true,
    val showOnlineStatus: Boolean = true,
    val languageName: String = "Русский",
    val autoDownloadWifi: Boolean = true,
    val autoDownloadMobile: Boolean = true,
    val voicePlaybackSpeed: Float = 1f,
    val deviceSessionId: String = "",
    val passcodePin: String? = null
)

class UserPreferences(private val context: Context) {
    private object Keys {
        val ACTIVE_EMAIL = stringPreferencesKey("active_email")
        val IS_DARK_THEME = booleanPreferencesKey("is_dark_theme")
        val WALLPAPER_THEME = stringPreferencesKey("wallpaper_theme")
        val CHAT_TEXT_SIZE = intPreferencesKey("chat_text_size")
        val ANIMATIONS_ENABLED = booleanPreferencesKey("animations_enabled")
        val POWER_SAVING = booleanPreferencesKey("power_saving")
        val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val SHOW_ONLINE = booleanPreferencesKey("show_online")
        val LANGUAGE = stringPreferencesKey("language")
        val AUTO_DOWNLOAD_WIFI = booleanPreferencesKey("auto_download_wifi")
        val AUTO_DOWNLOAD_MOBILE = booleanPreferencesKey("auto_download_mobile")
        val VOICE_SPEED = floatPreferencesKey("voice_speed")
        val DEVICE_SESSION_ID = stringPreferencesKey("device_session_id")
        val PASSCODE_PIN = stringPreferencesKey("passcode_pin")
    }

    val state: Flow<AppPreferencesState> = context.dataStore.data.map { prefs ->
        AppPreferencesState(
            activeEmail = prefs[Keys.ACTIVE_EMAIL],
            isDarkTheme = prefs[Keys.IS_DARK_THEME] ?: false,
            wallpaperTheme = prefs[Keys.WALLPAPER_THEME]
                ?.let { name -> WallpaperTheme.entries.firstOrNull { it.name == name } }
                ?: WallpaperTheme.CLASSIC_GREEN,
            chatTextSizeSp = prefs[Keys.CHAT_TEXT_SIZE] ?: 15,
            animationsEnabled = prefs[Keys.ANIMATIONS_ENABLED] ?: true,
            powerSavingEnabled = prefs[Keys.POWER_SAVING] ?: false,
            notificationsEnabled = prefs[Keys.NOTIFICATIONS_ENABLED] ?: true,
            showOnlineStatus = prefs[Keys.SHOW_ONLINE] ?: true,
            languageName = prefs[Keys.LANGUAGE] ?: "Русский",
            autoDownloadWifi = prefs[Keys.AUTO_DOWNLOAD_WIFI] ?: true,
            autoDownloadMobile = prefs[Keys.AUTO_DOWNLOAD_MOBILE] ?: true,
            voicePlaybackSpeed = prefs[Keys.VOICE_SPEED] ?: 1f,
            deviceSessionId = prefs[Keys.DEVICE_SESSION_ID] ?: "",
            passcodePin = prefs[Keys.PASSCODE_PIN]
        )
    }

    suspend fun ensureDeviceSessionId(): String {
        val existing = context.dataStore.data.first()[Keys.DEVICE_SESSION_ID]
        if (!existing.isNullOrBlank()) return existing
        val created = "sess_${UUID.randomUUID()}"
        context.dataStore.edit { it[Keys.DEVICE_SESSION_ID] = created }
        return created
    }

    suspend fun setActiveEmail(email: String?) {
        context.dataStore.edit { prefs ->
            if (email.isNullOrBlank()) prefs.remove(Keys.ACTIVE_EMAIL)
            else prefs[Keys.ACTIVE_EMAIL] = email
        }
    }

    suspend fun setDarkTheme(enabled: Boolean) {
        context.dataStore.edit { it[Keys.IS_DARK_THEME] = enabled }
    }

    suspend fun setWallpaperTheme(theme: WallpaperTheme) {
        context.dataStore.edit { it[Keys.WALLPAPER_THEME] = theme.name }
    }

    suspend fun setChatTextSize(sizeSp: Int) {
        context.dataStore.edit { it[Keys.CHAT_TEXT_SIZE] = sizeSp.coerceIn(12, 22) }
    }

    suspend fun setAnimationsEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.ANIMATIONS_ENABLED] = enabled }
    }

    suspend fun setPowerSavingEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.POWER_SAVING] = enabled }
    }

    suspend fun setNotificationsEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.NOTIFICATIONS_ENABLED] = enabled }
    }

    suspend fun setShowOnlineStatus(enabled: Boolean) {
        context.dataStore.edit { it[Keys.SHOW_ONLINE] = enabled }
    }

    suspend fun setLanguage(language: String) {
        context.dataStore.edit { it[Keys.LANGUAGE] = language }
    }

    suspend fun setAutoDownloadWifi(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_DOWNLOAD_WIFI] = enabled }
    }

    suspend fun setAutoDownloadMobile(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_DOWNLOAD_MOBILE] = enabled }
    }

    suspend fun setVoicePlaybackSpeed(speed: Float) {
        context.dataStore.edit { it[Keys.VOICE_SPEED] = speed }
    }

    suspend fun setPasscodePin(pin: String?) {
        context.dataStore.edit { prefs ->
            if (pin.isNullOrBlank()) prefs.remove(Keys.PASSCODE_PIN)
            else prefs[Keys.PASSCODE_PIN] = pin
        }
    }
}
