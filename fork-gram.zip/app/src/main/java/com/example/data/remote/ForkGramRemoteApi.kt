package com.example.data.remote

import android.os.Build
import android.util.Base64
import com.example.BuildConfig
import com.example.data.local.ChatMessageEntity
import com.example.data.local.OwnedGiftEntity
import com.example.data.local.ProfilePostEntity
import com.example.data.local.UserAccountEntity
import com.example.data.local.toDomain
import com.example.data.model.DeviceSession
import com.example.data.model.FragmentMarketPayload
import com.example.data.model.FragmentNftGiftListing
import com.example.data.model.NftUsernameItem
import com.example.data.model.PeerProfileData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class RemoteDirectoryUser(
    val email: String,
    val firstName: String,
    val lastName: String,
    val username: String,
    val activeNftUsername: String?,
    val bio: String,
    val statusGiftKindId: String?,
    val avatarUri: String? = null,
    val isOnline: Boolean = false,
    val lastSeenAt: Long = 0L,
    val isTypingToMe: Boolean = false
) {
    val fullName: String
        get() = listOf(firstName, lastName).filter { it.isNotBlank() }.joinToString(" ")

    val displayHandle: String
        get() = activeNftUsername?.takeIf { it.isNotBlank() } ?: username
}

data class RemoteDmMessage(
    val id: String,
    val senderEmail: String,
    val recipientEmail: String,
    val senderName: String,
    val kindName: String,
    val text: String,
    val timestampMillis: Long,
    val replyPreviewSender: String?,
    val replyPreviewText: String?,
    val forwardedFrom: String?,
    val mediaUri: String? = null,
    val fileName: String? = null,
    val fileSizeText: String? = null,
    val voiceDurationSec: Int = 0,
    val voiceWaveformCsv: String = "",
    val giftKindId: String?,
    val giftNumber: Int?,
    val giftStarsValue: Int,
    val isNftGift: Boolean,
    val gramAmount: Double,
    val reactionKey: String?,
    val isEdited: Boolean,
    val isRead: Boolean = false,
    val isDeleted: Boolean = false
)

data class RemoteSyncPayload(
    val serverTime: Long,
    val messages: List<RemoteDmMessage>,
    val gifts: List<OwnedGiftEntity>,
    val posts: List<ProfilePostEntity> = emptyList(),
    val sessions: List<DeviceSession> = emptyList(),
    val peers: List<RemoteDirectoryUser>
)

data class RemoteFragmentActionResult(
    val ok: Boolean,
    val error: String? = null,
    val market: FragmentMarketPayload? = null
)

class ForkGramRemoteApi(
    private val baseUrl: String = BuildConfig.FORKGRAM_API_URL
) {
    suspend fun ping(): Boolean = withContext(Dispatchers.IO) {
        val res = getJson("ping") ?: return@withContext false
        res.optBoolean("ok", false)
    }

    suspend fun checkAccount(email: String): UserAccountEntity? = withContext(Dispatchers.IO) {
        val encoded = URLEncoder.encode(email.trim().lowercase(), "UTF-8")
        val res = getJson("check_account&email=$encoded") ?: return@withContext null
        if (!res.optBoolean("ok", false) || !res.optBoolean("exists", false)) return@withContext null
        res.optJSONObject("account")?.toAccountEntity()
    }

    suspend fun authOrRegister(
        email: String,
        firstName: String,
        lastName: String,
        avatarUri: String?,
        sessionId: String? = null
    ): UserAccountEntity? = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("email", email.trim().lowercase())
            put("firstName", firstName.trim())
            put("lastName", lastName.trim())
            if (!avatarUri.isNullOrBlank()) put("avatarUri", avatarUri)
            if (!sessionId.isNullOrBlank()) {
                put("sessionId", sessionId)
                put("deviceName", "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}")
                put("platform", "Fork Gram Android ${Build.VERSION.RELEASE}")
            }
        }
        val res = postJson("auth", body) ?: return@withContext null
        if (!res.optBoolean("ok", false)) return@withContext null
        res.optJSONObject("account")?.toAccountEntity()
    }

    suspend fun updateProfile(account: UserAccountEntity): Boolean = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("email", account.email)
            put("firstName", account.firstName)
            put("lastName", account.lastName)
            put("username", account.username)
            put("activeNftUsername", account.activeNftUsername ?: JSONObject.NULL)
            put("bio", account.bio)
            put("birthday", account.birthday)
            if (!account.avatarUri.isNullOrBlank() && account.avatarUri.startsWith("http")) {
                put("avatarUri", account.avatarUri)
            }
            put("isPremium", account.isPremium)
            put("starsBalance", account.starsBalance)
            put("gramBalance", account.gramBalance)
            put("statusGiftKindId", account.statusGiftKindId ?: JSONObject.NULL)
            put("statusBackdropId", account.statusBackdropId ?: JSONObject.NULL)
            put("statusSymbolId", account.statusSymbolId ?: JSONObject.NULL)
        }
        val res = postJson("update_profile", body) ?: return@withContext false
        res.optBoolean("ok", false)
    }

    suspend fun uploadMediaBytes(bytes: ByteArray, filename: String): String? = withContext(Dispatchers.IO) {
        if (bytes.isEmpty()) return@withContext null
        val encoded = Base64.encodeToString(bytes, Base64.NO_WRAP)
        val body = JSONObject().apply {
            put("filename", filename)
            put("base64", encoded)
        }
        val res = postJson("upload_media", body, readTimeoutMs = 15000) ?: return@withContext null
        if (!res.optBoolean("ok", false)) return@withContext null
        res.optNullableString("url")
    }

    suspend fun searchUsers(query: String, excludeEmail: String): List<RemoteDirectoryUser> =
        withContext(Dispatchers.IO) {
            val q = URLEncoder.encode(query.trim(), "UTF-8")
            val ex = URLEncoder.encode(excludeEmail.trim().lowercase(), "UTF-8")
            val res = getJson("search_users&q=$q&excludeEmail=$ex") ?: return@withContext emptyList()
            if (!res.optBoolean("ok", false)) return@withContext emptyList()
            val arr = res.optJSONArray("users") ?: return@withContext emptyList()
            buildList {
                for (i in 0 until arr.length()) {
                    arr.optJSONObject(i)?.toDirectoryUser()?.let(::add)
                }
            }
        }

    suspend fun fetchPeerProfile(peerEmail: String, viewerEmail: String): PeerProfileData? =
        withContext(Dispatchers.IO) {
            val pe = URLEncoder.encode(peerEmail.trim().lowercase(), "UTF-8")
            val ve = URLEncoder.encode(viewerEmail.trim().lowercase(), "UTF-8")
            val res = getJson("peer_profile&email=$pe&viewerEmail=$ve") ?: return@withContext null
            if (!res.optBoolean("ok", false)) return@withContext null
            val accObj = res.optJSONObject("account") ?: return@withContext null
            val accEntity = accObj.toAccountEntity() ?: return@withContext null
            val giftArr = res.optJSONArray("gifts") ?: JSONArray()
            val gifts = buildList {
                for (i in 0 until giftArr.length()) {
                    giftArr.optJSONObject(i)?.toOwnedGiftEntity()?.toDomain()?.let(::add)
                }
            }
            val postArr = res.optJSONArray("posts") ?: JSONArray()
            val posts = buildList {
                for (i in 0 until postArr.length()) {
                    postArr.optJSONObject(i)?.toProfilePostEntity()?.toDomain()?.let(::add)
                }
            }
            PeerProfileData(
                account = accEntity.toDomain(),
                gifts = gifts,
                posts = posts,
                isOnline = accObj.optBoolean("isOnline", false),
                lastSeenAt = accObj.optLong("lastSeenAt", 0L),
                isTypingToMe = accObj.optBoolean("isTypingToMe", false)
            )
        }

    suspend fun sendHeartbeat(
        email: String,
        isOnline: Boolean,
        typingToEmail: String? = null,
        sessionId: String? = null
    ): Boolean = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("email", email.trim().lowercase())
            put("isOnline", isOnline)
            if (!typingToEmail.isNullOrBlank()) put("typingToEmail", typingToEmail.trim().lowercase())
            if (!sessionId.isNullOrBlank()) {
                put("sessionId", sessionId)
                put("deviceName", "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}")
                put("platform", "Fork Gram Android ${Build.VERSION.RELEASE}")
            }
        }
        val res = postJson("heartbeat", body) ?: return@withContext false
        res.optBoolean("ok", false)
    }

    suspend fun sendMessage(
        senderEmail: String,
        recipientEmail: String,
        msg: ChatMessageEntity
    ): Boolean = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("id", msg.id)
            put("senderEmail", senderEmail.trim().lowercase())
            put("recipientEmail", recipientEmail.trim().lowercase())
            put("senderName", msg.senderName)
            put("kindName", msg.kindName)
            put("text", msg.text)
            put("timestampMillis", msg.timestampMillis)
            put("replyPreviewSender", msg.replyPreviewSender ?: JSONObject.NULL)
            put("replyPreviewText", msg.replyPreviewText ?: JSONObject.NULL)
            put("forwardedFrom", msg.forwardedFrom ?: JSONObject.NULL)
            put("mediaUri", msg.mediaUri ?: JSONObject.NULL)
            put("fileName", msg.fileName ?: JSONObject.NULL)
            put("fileSizeText", msg.fileSizeText ?: JSONObject.NULL)
            put("voiceDurationSec", msg.voiceDurationSec)
            put("voiceWaveformCsv", msg.voiceWaveformCsv)
            put("giftKindId", msg.giftKindId ?: JSONObject.NULL)
            put("giftNumber", msg.giftNumber ?: JSONObject.NULL)
            put("giftStarsValue", msg.giftStarsValue)
            put("isNftGift", msg.isNftGift)
            put("gramAmount", msg.gramAmount)
            put("reactionKey", msg.reactionKey ?: JSONObject.NULL)
            put("isEdited", msg.isEdited)
        }
        val res = postJson("send_message", body) ?: return@withContext false
        res.optBoolean("ok", false)
    }

    suspend fun editMessage(id: String, text: String): Boolean = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("id", id)
            put("text", text)
        }
        postJson("edit_message", body)?.optBoolean("ok", false) ?: false
    }

    suspend fun deleteMessage(id: String): Boolean = withContext(Dispatchers.IO) {
        val body = JSONObject().apply { put("id", id) }
        postJson("delete_message", body)?.optBoolean("ok", false) ?: false
    }

    suspend fun reactMessage(id: String, reactionKey: String?): Boolean = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("id", id)
            put("reactionKey", reactionKey ?: JSONObject.NULL)
        }
        postJson("react_message", body)?.optBoolean("ok", false) ?: false
    }

    suspend fun markRead(readerEmail: String, peerEmail: String): Boolean = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("readerEmail", readerEmail.trim().lowercase())
            put("peerEmail", peerEmail.trim().lowercase())
        }
        postJson("mark_read", body)?.optBoolean("ok", false) ?: false
    }

    suspend fun syncGift(gift: OwnedGiftEntity): Boolean = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("id", gift.id)
            put("ownerEmail", gift.ownerEmail.trim().lowercase())
            put("giftKindId", gift.giftKindId)
            put("editionNumber", gift.editionNumber)
            put("collectionName", gift.collectionName)
            put("modelName", gift.modelName)
            put("modelRarity", gift.modelRarity)
            put("backdropId", gift.backdropId)
            put("symbolId", gift.symbolId)
            put("senderName", gift.senderName)
            put("messageText", gift.messageText)
            put("starsValue", gift.starsValue)
            put("isNft", gift.isNft)
            put("isPinned", gift.isPinned)
            put("isWornAsStatus", gift.isWornAsStatus)
            put("receivedAt", gift.receivedAt)
        }
        val res = postJson("sync_gift", body) ?: return@withContext false
        res.optBoolean("ok", false)
    }

    /** Синхронизирует подарок и возвращает номер, выданный сервером (для NFT — порядковый в коллекции). */
    suspend fun syncGiftEdition(gift: OwnedGiftEntity): Int? = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("id", gift.id)
            put("ownerEmail", gift.ownerEmail.trim().lowercase())
            put("giftKindId", gift.giftKindId)
            put("editionNumber", gift.editionNumber)
            put("collectionName", gift.collectionName)
            put("modelName", gift.modelName)
            put("modelRarity", gift.modelRarity)
            put("backdropId", gift.backdropId)
            put("symbolId", gift.symbolId)
            put("senderName", gift.senderName)
            put("messageText", gift.messageText)
            put("starsValue", gift.starsValue)
            put("isNft", gift.isNft)
            put("isPinned", gift.isPinned)
            put("isWornAsStatus", gift.isWornAsStatus)
            put("receivedAt", gift.receivedAt)
        }
        val res = postJson("sync_gift", body) ?: return@withContext null
        if (!res.optBoolean("ok", false)) return@withContext null
        res.optInt("editionNumber", 0).takeIf { it > 0 }
    }

    /** NFT по ссылке: slug (PlushPepe) + номер. Возвращает сырой ответ сервера. */
    suspend fun fetchNft(slug: String, number: Int): JSONObject? = withContext(Dispatchers.IO) {
        val body = JSONObject().apply { put("slug", slug); put("number", number) }
        val res = postJson("get_nft", body) ?: return@withContext null
        if (res.optBoolean("ok", false)) res else null
    }

    suspend fun transferGift(
        giftId: String,
        fromEmail: String,
        toEmail: String,
        senderName: String
    ): Boolean = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("giftId", giftId)
            put("fromEmail", fromEmail.trim().lowercase())
            put("toEmail", toEmail.trim().lowercase())
            put("senderName", senderName)
        }
        val res = postJson("transfer_gift", body) ?: return@withContext false
        res.optBoolean("ok", false)
    }

    suspend fun deleteGift(giftId: String, ownerEmail: String): Boolean = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("giftId", giftId)
            put("ownerEmail", ownerEmail.trim().lowercase())
        }
        postJson("delete_gift", body)?.optBoolean("ok", false) ?: false
    }

    suspend fun publishPost(post: ProfilePostEntity): Boolean = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("id", post.id)
            put("ownerEmail", post.ownerEmail.trim().lowercase())
            put("mediaUrl", post.mediaUrl)
            put("caption", post.caption)
            put("isArchived", post.isArchived)
            put("createdAt", post.createdAt)
        }
        postJson("publish_post", body)?.optBoolean("ok", false) ?: false
    }

    suspend fun toggleArchivePost(id: String, ownerEmail: String, isArchived: Boolean): Boolean =
        withContext(Dispatchers.IO) {
            val body = JSONObject().apply {
                put("id", id)
                put("ownerEmail", ownerEmail.trim().lowercase())
                put("isArchived", isArchived)
            }
            postJson("toggle_archive_post", body)?.optBoolean("ok", false) ?: false
        }

    suspend fun deletePost(id: String, ownerEmail: String): Boolean = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("id", id)
            put("ownerEmail", ownerEmail.trim().lowercase())
        }
        postJson("delete_post", body)?.optBoolean("ok", false) ?: false
    }

    suspend fun terminateSession(id: String, ownerEmail: String): Boolean = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("id", id)
            put("ownerEmail", ownerEmail.trim().lowercase())
        }
        postJson("terminate_session", body)?.optBoolean("ok", false) ?: false
    }

    suspend fun votePoll(messageId: String, voterEmail: String, optionIndex: Int): String? =
        withContext(Dispatchers.IO) {
            val body = JSONObject().apply {
                put("messageId", messageId)
                put("voterEmail", voterEmail.trim().lowercase())
                put("optionIndex", optionIndex)
            }
            val res = postJson("vote_poll", body) ?: return@withContext null
            if (!res.optBoolean("ok", false)) return@withContext null
            res.optNullableString("text")
        }

    suspend fun fetchFragmentMarket(email: String): FragmentMarketPayload? = withContext(Dispatchers.IO) {
        val encoded = URLEncoder.encode(email.trim().lowercase(), "UTF-8")
        val res = getJson("fragment_list&email=$encoded") ?: return@withContext null
        if (!res.optBoolean("ok", false)) return@withContext null
        res.toFragmentMarketPayload()
    }

    suspend fun buyFragmentUsername(email: String, itemId: String): RemoteFragmentActionResult =
        withContext(Dispatchers.IO) {
            val body = JSONObject().apply {
                put("email", email.trim().lowercase())
                put("itemId", itemId)
            }
            postFragmentAction("fragment_buy", body)
        }

    suspend fun bidFragmentUsername(email: String, itemId: String, amountGram: Double): RemoteFragmentActionResult =
        withContext(Dispatchers.IO) {
            val body = JSONObject().apply {
                put("email", email.trim().lowercase())
                put("itemId", itemId)
                put("amountGram", amountGram)
            }
            postFragmentAction("fragment_bid", body)
        }

    suspend fun mintFragmentUsername(email: String, handle: String): RemoteFragmentActionResult =
        withContext(Dispatchers.IO) {
            val body = JSONObject().apply {
                put("email", email.trim().lowercase())
                put("handle", handle)
            }
            postFragmentAction("fragment_mint", body)
        }

    suspend fun sellFragmentUsername(
        email: String,
        itemId: String,
        mode: String,
        priceGram: Double
    ): RemoteFragmentActionResult = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("email", email.trim().lowercase())
            put("itemId", itemId)
            put("mode", mode)
            put("priceGram", priceGram)
        }
        postFragmentAction("fragment_sell", body)
    }

    suspend fun cancelFragmentSale(email: String, itemId: String): RemoteFragmentActionResult =
        withContext(Dispatchers.IO) {
            val body = JSONObject().apply {
                put("email", email.trim().lowercase())
                put("itemId", itemId)
            }
            postFragmentAction("fragment_cancel_sale", body)
        }

    suspend fun assignFragmentUsername(email: String, itemId: String): RemoteFragmentActionResult =
        withContext(Dispatchers.IO) {
            val body = JSONObject().apply {
                put("email", email.trim().lowercase())
                put("itemId", itemId)
            }
            postFragmentAction("fragment_assign", body)
        }

    suspend fun listGiftOnFragment(email: String, giftId: String, priceGram: Double): RemoteFragmentActionResult =
        withContext(Dispatchers.IO) {
            val body = JSONObject().apply {
                put("email", email.trim().lowercase())
                put("giftId", giftId)
                put("priceGram", priceGram)
            }
            postFragmentAction("fragment_list_gift", body)
        }

    suspend fun buyFragmentGift(email: String, listingId: String): RemoteFragmentActionResult =
        withContext(Dispatchers.IO) {
            val body = JSONObject().apply {
                put("email", email.trim().lowercase())
                put("listingId", listingId)
            }
            postFragmentAction("fragment_buy_gift", body)
        }

    private fun postFragmentAction(action: String, body: JSONObject): RemoteFragmentActionResult {
        val res = postJson(action, body)
            ?: return RemoteFragmentActionResult(ok = false, error = "Сервер Fragment недоступен")
        val ok = res.optBoolean("ok", false)
        val err = res.optNullableString("error")
        val payload = if (res.has("usernames") || res.has("nftListings")) res.toFragmentMarketPayload() else null
        return RemoteFragmentActionResult(ok = ok, error = err, market = payload)
    }

    suspend fun sync(email: String, sinceMillis: Long = 0L): RemoteSyncPayload? =
        withContext(Dispatchers.IO) {
            val encoded = URLEncoder.encode(email.trim().lowercase(), "UTF-8")
            val res = getJson("sync&email=$encoded&since=$sinceMillis") ?: return@withContext null
            if (!res.optBoolean("ok", false)) return@withContext null

            val msgArr = res.optJSONArray("messages") ?: JSONArray()
            val messages = buildList {
                for (i in 0 until msgArr.length()) {
                    msgArr.optJSONObject(i)?.toRemoteDmMessage()?.let(::add)
                }
            }

            val giftArr = res.optJSONArray("gifts") ?: JSONArray()
            val gifts = buildList {
                for (i in 0 until giftArr.length()) {
                    giftArr.optJSONObject(i)?.toOwnedGiftEntity()?.let(::add)
                }
            }

            val postArr = res.optJSONArray("posts") ?: JSONArray()
            val posts = buildList {
                for (i in 0 until postArr.length()) {
                    postArr.optJSONObject(i)?.toProfilePostEntity()?.let(::add)
                }
            }

            val sessArr = res.optJSONArray("sessions") ?: JSONArray()
            val sessions = buildList {
                for (i in 0 until sessArr.length()) {
                    sessArr.optJSONObject(i)?.toDeviceSession()?.let(::add)
                }
            }

            val peerArr = res.optJSONArray("peers") ?: JSONArray()
            val peers = buildList {
                for (i in 0 until peerArr.length()) {
                    peerArr.optJSONObject(i)?.toDirectoryUser()?.let(::add)
                }
            }

            RemoteSyncPayload(
                serverTime = res.optLong("serverTime", System.currentTimeMillis()),
                messages = messages,
                gifts = gifts,
                posts = posts,
                sessions = sessions,
                peers = peers
            )
        }

    private fun getJson(actionAndParams: String): JSONObject? {
        return try {
            val url = URL("$baseUrl?action=$actionAndParams")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 5000
                readTimeout = 6000
                setRequestProperty("Accept", "application/json")
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.use { BufferedReader(InputStreamReader(it)).readText() } ?: return null
            conn.disconnect()
            JSONObject(text)
        } catch (_: Exception) {
            null
        }
    }

    private fun postJson(action: String, body: JSONObject, readTimeoutMs: Int = 7000): JSONObject? {
        return try {
            val url = URL("$baseUrl?action=$action")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 5000
                readTimeout = readTimeoutMs
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json")
            }
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                writer.write(body.toString())
                writer.flush()
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.use { BufferedReader(InputStreamReader(it)).readText() } ?: return null
            conn.disconnect()
            JSONObject(text)
        } catch (_: Exception) {
            null
        }
    }

    private fun JSONObject.optNullableString(key: String): String? {
        if (!has(key) || isNull(key)) return null
        val s = optString(key, "")
        return s.takeIf { it.isNotBlank() && it != "null" }
    }

    private fun JSONObject.toAccountEntity(): UserAccountEntity? {
        val email = optString("email", "").trim().lowercase()
        if (email.isBlank()) return null
        return UserAccountEntity(
            email = email,
            firstName = optString("firstName", "Пользователь"),
            lastName = optString("lastName", ""),
            username = optString("username", "@forkgram"),
            activeNftUsername = optNullableString("activeNftUsername"),
            bio = optString("bio", "На связи в Fork Gram"),
            birthday = optString("birthday", ""),
            avatarUri = optNullableString("avatarUri"),
            isPremium = optBoolean("isPremium", true),
            starsBalance = optLong("starsBalance", 1000L),
            gramBalance = optDouble("gramBalance", 100.0),
            level = optInt("level", 1),
            statusGiftKindId = optNullableString("statusGiftKindId"),
            statusBackdropId = optNullableString("statusBackdropId"),
            statusSymbolId = optNullableString("statusSymbolId"),
            createdAt = optLong("createdAt", System.currentTimeMillis())
        )
    }

    private fun JSONObject.toDirectoryUser(): RemoteDirectoryUser? {
        val email = optString("email", "").trim().lowercase()
        if (email.isBlank()) return null
        return RemoteDirectoryUser(
            email = email,
            firstName = optString("firstName", "Пользователь"),
            lastName = optString("lastName", ""),
            username = optString("username", "@user"),
            activeNftUsername = optNullableString("activeNftUsername"),
            bio = optString("bio", "На связи в Fork Gram"),
            statusGiftKindId = optNullableString("statusGiftKindId"),
            avatarUri = optNullableString("avatarUri"),
            isOnline = optBoolean("isOnline", false),
            lastSeenAt = optLong("lastSeenAt", 0L),
            isTypingToMe = optBoolean("isTypingToMe", false)
        )
    }

    private fun JSONObject.toRemoteDmMessage(): RemoteDmMessage {
        return RemoteDmMessage(
            id = optString("id"),
            senderEmail = optString("sender_email"),
            recipientEmail = optString("recipient_email"),
            senderName = optString("sender_name"),
            kindName = optString("kind_name", "TEXT"),
            text = optString("text", ""),
            timestampMillis = optLong("timestamp_millis", System.currentTimeMillis()),
            replyPreviewSender = optNullableString("reply_preview_sender"),
            replyPreviewText = optNullableString("reply_preview_text"),
            forwardedFrom = optNullableString("forwarded_from"),
            mediaUri = optNullableString("media_uri"),
            fileName = optNullableString("file_name"),
            fileSizeText = optNullableString("file_size_text"),
            voiceDurationSec = optInt("voice_duration_sec", 0),
            voiceWaveformCsv = optString("voice_waveform_csv", ""),
            giftKindId = optNullableString("gift_kind_id"),
            giftNumber = if (has("gift_number") && !isNull("gift_number")) optInt("gift_number") else null,
            giftStarsValue = optInt("gift_stars_value", 0),
            isNftGift = optInt("is_nft_gift", 0) == 1,
            gramAmount = optDouble("gram_amount", 0.0),
            reactionKey = optNullableString("reaction_key"),
            isEdited = optInt("is_edited", 0) == 1,
            isRead = optInt("is_read", 0) == 1,
            isDeleted = optInt("is_deleted", 0) == 1
        )
    }

    private fun JSONObject.toOwnedGiftEntity(): OwnedGiftEntity {
        return OwnedGiftEntity(
            id = optString("id"),
            ownerEmail = optString("owner_email"),
            giftKindId = optString("gift_kind_id", "plush_pepe"),
            editionNumber = optInt("edition_number", 1),
            collectionName = optString("collection_name", "Все подарки"),
            modelName = optString("model_name", "Classic"),
            modelRarity = optString("model_rarity", "1.5%"),
            backdropId = optString("backdrop_id", "emerald"),
            symbolId = optString("symbol_id", "star"),
            senderName = optString("sender_name", "Fork Gram"),
            messageText = optString("message_text", ""),
            starsValue = optInt("stars_value", 100),
            isNft = optInt("is_nft", 0) == 1,
            isPinned = optInt("is_pinned", 0) == 1,
            isWornAsStatus = optInt("is_worn_as_status", 0) == 1,
            receivedAt = optLong("received_at", System.currentTimeMillis())
        )
    }

    private fun JSONObject.toProfilePostEntity(): ProfilePostEntity {
        return ProfilePostEntity(
            id = optString("id"),
            ownerEmail = optString("owner_email"),
            mediaUrl = optString("media_url", ""),
            caption = optString("caption", ""),
            isArchived = optInt("is_archived", 0) == 1,
            createdAt = optLong("created_at", System.currentTimeMillis())
        )
    }

    private fun JSONObject.toDeviceSession(): DeviceSession {
        return DeviceSession(
            id = optString("id"),
            ownerEmail = optString("owner_email"),
            deviceName = optString("device_name", "Android Device"),
            platform = optString("platform", "Fork Gram Android"),
            location = optString("location", "Fork Gram Cloud"),
            lastActiveAt = optLong("last_active_at", System.currentTimeMillis()),
            isCurrent = optInt("is_current", 0) == 1
        )
    }

    private fun JSONObject.toFragmentMarketPayload(): FragmentMarketPayload {
        val uArr = optJSONArray("usernames") ?: JSONArray()
        val usernames = buildList {
            for (i in 0 until uArr.length()) {
                val obj = uArr.optJSONObject(i) ?: continue
                val handle = obj.optString("handle", "").takeIf { it.isNotBlank() } ?: continue
                val acq = if (obj.has("acquiredAt") && !obj.isNull("acquiredAt")) obj.optLong("acquiredAt") else null
                val ends = if (obj.has("endsAt") && !obj.isNull("endsAt")) obj.optLong("endsAt") else null
                val price = obj.optDouble("priceGram", 10.0)
                add(
                    NftUsernameItem(
                        id = obj.optString("id"),
                        handle = handle,
                        priceGram = price,
                        isOwned = obj.optBoolean("isOwned", false),
                        isEquipped = obj.optBoolean("isEquipped", false),
                        rarityTier = obj.optString("rarityTier", "Коллекционный NFT"),
                        acquiredAt = acq,
                        status = obj.optString("status", if (obj.optBoolean("isOwned", false)) "OWNED" else "SALE"),
                        topBidGram = obj.optDouble("topBidGram", 0.0),
                        minBidGram = obj.optDouble("minBidGram", price),
                        topBidderName = obj.optNullableString("topBidderName"),
                        isHighestBidder = obj.optBoolean("isHighestBidder", false),
                        bidsCount = obj.optInt("bidsCount", 0),
                        endsAt = ends,
                        ownerEmail = obj.optNullableString("ownerEmail"),
                        ownerName = obj.optString("ownerName", "Fragment"),
                        fragmentUrl = obj.optString(
                            "fragmentUrl",
                            "http://forkgram.xsph.ru/fragment?q=${handle.removePrefix("@")}"
                        )
                    )
                )
            }
        }

        val gArr = optJSONArray("nftListings") ?: JSONArray()
        val listings = buildList {
            for (i in 0 until gArr.length()) {
                val obj = gArr.optJSONObject(i) ?: continue
                val giftObj = obj.optJSONObject("gift") ?: continue
                val gift = giftObj.toOwnedGiftEntity().toDomain()
                add(
                    FragmentNftGiftListing(
                        id = obj.optString("id"),
                        sellerEmail = obj.optString("sellerEmail", ""),
                        sellerName = obj.optString("sellerName", "Collector"),
                        priceGram = obj.optDouble("priceGram", 10.0),
                        gift = gift,
                        listedAt = obj.optLong("listedAt", System.currentTimeMillis())
                    )
                )
            }
        }

        val accObj = optJSONObject("account")
        return FragmentMarketPayload(
            usernames = usernames,
            giftListings = listings,
            updatedGramBalance = accObj?.optDouble("gramBalance"),
            activeNftUsername = accObj?.optNullableString("activeNftUsername")
        )
    }
}
