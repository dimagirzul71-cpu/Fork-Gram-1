package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.model.MainTab
import com.example.ui.components.FloatingBottomNavBar
import com.example.ui.components.TelegramCallOverlay
import com.example.ui.screens.AuthFlowScreen
import com.example.ui.screens.ChatDetailScreen
import com.example.ui.screens.ChatsScreen
import com.example.ui.screens.ContactsScreen
import com.example.ui.screens.PeerProfileScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SettingsDestination
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SettingsSubScreenRouter
import com.example.ui.theme.DangerRed
import com.example.ui.theme.ForkGramTheme
import com.example.ui.theme.TgBlue
import com.example.ui.viewmodel.ForkGramViewModel
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ForkGramRoot()
        }
    }
}

@Composable
fun ForkGramRoot(viewModel: ForkGramViewModel = viewModel()) {
    val prefs by viewModel.prefs.collectAsStateWithLifecycle()
    val account by viewModel.account.collectAsStateWithLifecycle()
    val chats by viewModel.chats.collectAsStateWithLifecycle()
    val folders by viewModel.folders.collectAsStateWithLifecycle()
    val contacts by viewModel.contacts.collectAsStateWithLifecycle()
    val ownedGifts by viewModel.ownedGifts.collectAsStateWithLifecycle()
    val giftCollections by viewModel.giftCollections.collectAsStateWithLifecycle()
    val nftUsernames by viewModel.nftUsernames.collectAsStateWithLifecycle()
    val transactions by viewModel.transactions.collectAsStateWithLifecycle()
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val selectedFolderId by viewModel.selectedFolderId.collectAsStateWithLifecycle()
    val voiceRecordingState by viewModel.voiceRecordingState.collectAsStateWithLifecycle()
    val voicePlaybackState by viewModel.voicePlaybackState.collectAsStateWithLifecycle()
    val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()
    val remoteDirectory by viewModel.remoteDirectory.collectAsStateWithLifecycle()
    val profilePosts by viewModel.profilePosts.collectAsStateWithLifecycle()
    val deviceSessions by viewModel.deviceSessions.collectAsStateWithLifecycle()
    val cacheSizeBytes by viewModel.cacheSizeBytes.collectAsStateWithLifecycle()
    val activeCall by viewModel.activeCall.collectAsStateWithLifecycle()
    val fragmentGiftListings by viewModel.fragmentGiftListings.collectAsStateWithLifecycle()

    val isLoggedIn = !prefs.activeEmail.isNullOrBlank()
    var passcodeCheckedOnLaunch by remember { mutableStateOf(false) }
    var isAppLocked by remember { mutableStateOf(false) }

    LaunchedEffect(isLoggedIn, prefs.passcodePin) {
        if (!isLoggedIn) {
            isAppLocked = false
            passcodeCheckedOnLaunch = false
        } else if (!passcodeCheckedOnLaunch) {
            passcodeCheckedOnLaunch = true
            isAppLocked = !prefs.passcodePin.isNullOrBlank()
        }
    }

    LaunchedEffect(toastMessage) {
        if (toastMessage != null) {
            delay(2300L)
            viewModel.clearToast()
        }
    }

    ForkGramTheme(darkTheme = prefs.isDarkTheme) {
        val navController = rememberNavController()

        Box(modifier = Modifier.fillMaxSize()) {
            if (!isLoggedIn) {
                AuthFlowScreen(
                    onCheckExistingAccount = { email -> viewModel.findExistingAccount(email) },
                    onCompleteAuth = { email, first, last, avatarUri ->
                        viewModel.completeAuth(email, first, last, avatarUri) {}
                    }
                )
            } else {
                NavHost(
                    navController = navController,
                    startDestination = "main",
                    enterTransition = {
                        if (prefs.animationsEnabled) {
                            slideInHorizontally(tween(240)) { it / 4 } + fadeIn(tween(200))
                        } else fadeIn(tween(0))
                    },
                    exitTransition = {
                        if (prefs.animationsEnabled) {
                            slideOutHorizontally(tween(240)) { -it / 6 } + fadeOut(tween(180))
                        } else fadeOut(tween(0))
                    },
                    popEnterTransition = {
                        if (prefs.animationsEnabled) {
                            slideInHorizontally(tween(240)) { -it / 6 } + fadeIn(tween(200))
                        } else fadeIn(tween(0))
                    },
                    popExitTransition = {
                        if (prefs.animationsEnabled) {
                            slideOutHorizontally(tween(240)) { it / 4 } + fadeOut(tween(180))
                        } else fadeOut(tween(0))
                    }
                ) {
                    composable("main") {
                        BackHandler(enabled = selectedTab != MainTab.CHATS) {
                            viewModel.selectTab(MainTab.CHATS)
                        }

                        Box(modifier = Modifier.fillMaxSize()) {
                            AnimatedContent(
                                targetState = selectedTab,
                                transitionSpec = { fadeIn(tween(160)) togetherWith fadeOut(tween(140)) },
                                label = "mainTabCrossfade"
                            ) { tab ->
                                when (tab) {
                                    MainTab.CHATS -> ChatsScreen(
                                        chats = chats,
                                        folders = folders,
                                        contacts = contacts,
                                        selectedFolderId = selectedFolderId,
                                        isDarkTheme = prefs.isDarkTheme,
                                        onSelectFolder = viewModel::selectFolder,
                                        onOpenChat = { chatId ->
                                            viewModel.markChatRead(chatId)
                                            navController.navigate("chat/$chatId")
                                        },
                                        onToggleNightMode = viewModel::toggleDarkMode,
                                        onOpenSavedMessages = {
                                            viewModel.openSavedMessages { savedId ->
                                                navController.navigate("chat/$savedId")
                                            }
                                        },
                                        onOpenFoldersEditor = {
                                            navController.navigate("settings_sub/${SettingsDestination.FOLDERS.name}")
                                        },
                                        onDeleteFolder = viewModel::deleteFolder,
                                        onCreateGroupOrChannel = { title, isChannel, isSecret ->
                                            viewModel.createGroupOrChannel(title, isChannel, isSecret) { chatId ->
                                                navController.navigate("chat/$chatId")
                                            }
                                        },
                                        onTogglePinChat = viewModel::togglePinChat,
                                        onToggleArchiveChat = viewModel::toggleArchiveChat,
                                        onToggleMuteChat = viewModel::toggleMuteChat,
                                        onMarkChatRead = viewModel::markChatRead,
                                        onDeleteChat = viewModel::deleteChat,
                                        onOpenContactChat = { contact ->
                                            viewModel.openContactChat(contact) { chatId ->
                                                navController.navigate("chat/$chatId")
                                            }
                                        },
                                        onPublishStoryPost = { uri, caption ->
                                            viewModel.publishPost(uri, caption)
                                        },
                                        onShowStoryTip = {
                                            viewModel.showToast("Выберите фото для истории профиля")
                                        }
                                    )

                                    MainTab.CONTACTS -> ContactsScreen(
                                        contacts = contacts,
                                        remoteDirectory = remoteDirectory,
                                        onSearchRemoteDirectory = viewModel::searchRemoteDirectory,
                                        onOpenRemoteUserChat = { remoteUser ->
                                            viewModel.openRemoteUserChat(remoteUser) { chatId ->
                                                navController.navigate("chat/$chatId")
                                            }
                                        },
                                        onOpenContactChat = { contact ->
                                            viewModel.openContactChat(contact) { chatId ->
                                                navController.navigate("chat/$chatId")
                                            }
                                        },
                                        onCreateContact = { first, last, emailOrHandle ->
                                            viewModel.createContact(first, last, emailOrHandle) { chatId ->
                                                navController.navigate("chat/$chatId")
                                            }
                                        },
                                        onShowToast = viewModel::showToast
                                    )

                                    MainTab.SETTINGS -> SettingsScreen(
                                        account = account,
                                        prefs = prefs,
                                        onNavigateSubScreen = { dest ->
                                            navController.navigate("settings_sub/${dest.name}")
                                        },
                                        onUpdateAvatar = { uri ->
                                            account?.let {
                                                viewModel.updateProfile(
                                                    firstName = it.firstName,
                                                    lastName = it.lastName,
                                                    username = it.username,
                                                    bio = it.bio,
                                                    birthday = it.birthday,
                                                    avatarUri = uri
                                                )
                                            }
                                        },
                                        onShowToast = viewModel::showToast,
                                        onLogout = viewModel::logout
                                    )

                                    MainTab.PROFILE -> ProfileScreen(
                                        account = account,
                                        gifts = ownedGifts,
                                        collections = giftCollections,
                                        posts = profilePosts,
                                        allChats = chats,
                                        onUpdateProfile = { first, last, handle, bio, birthday, avatarUri ->
                                            viewModel.updateProfile(first, last, handle, bio, birthday, avatarUri)
                                        },
                                        onOpenSettings = { viewModel.selectTab(MainTab.SETTINGS) },
                                        onOpenNftUsernames = {
                                            navController.navigate("settings_sub/${SettingsDestination.NFT_USERNAMES.name}")
                                        },
                                        onSendGiftToSelf = { kind, asNft, comment ->
                                            viewModel.sendGift(kind, asNft, null, comment)
                                        },
                                        onCreateGiftCollection = viewModel::createGiftCollection,
                                        onAssignGiftToCollection = viewModel::assignGiftToCollection,
                                        onTogglePinGift = viewModel::togglePinGift,
                                        onToggleWearGiftStatus = viewModel::toggleWearGiftStatus,
                                        onUpgradeGiftToNft = viewModel::upgradeGiftToNft,
                                        onConvertGiftToStars = viewModel::convertGiftToStars,
                                        onListGiftOnFragment = viewModel::listGiftOnFragment,
                                        onTransferGift = { giftId, targetChatId ->
                                            viewModel.transferGift(giftId, targetChatId)
                                        },
                                        onPublishPost = { uri, caption ->
                                            viewModel.publishPost(uri, caption)
                                        },
                                        onToggleArchivePost = viewModel::toggleArchivePost,
                                        onDeletePost = viewModel::deletePost,
                                        onLogout = viewModel::logout,
                                        onShowToast = viewModel::showToast
                                    )
                                }
                            }

                            FloatingBottomNavBar(
                                selectedTab = selectedTab,
                                account = account,
                                unreadChatsCount = chats.count { !it.isArchived && it.unreadCount > 0 },
                                onSelectTab = viewModel::selectTab,
                                modifier = Modifier.align(Alignment.BottomCenter)
                            )
                        }
                    }

                    composable(
                        route = "chat/{chatId}",
                        arguments = listOf(navArgument("chatId") { type = NavType.StringType })
                    ) { entry ->
                        val chatId = entry.arguments?.getString("chatId") ?: return@composable
                        val chat by viewModel.observeChat(chatId).collectAsState(initial = null)
                        val messages by viewModel.observeMessages(chatId).collectAsState(initial = emptyList())

                        ChatDetailScreen(
                            chat = chat,
                            messages = messages,
                            allChats = chats,
                            starsBalance = account?.starsBalance ?: 0L,
                            gramBalance = account?.gramBalance ?: 0.0,
                            wallpaperTheme = prefs.wallpaperTheme,
                            chatTextSizeSp = prefs.chatTextSizeSp,
                            voiceRecordingState = voiceRecordingState,
                            voicePlaybackState = voicePlaybackState,
                            currentUserEmail = prefs.activeEmail.orEmpty(),
                            onLookupNft = viewModel::lookupNft,
                            onBack = {
                                viewModel.setTyping(chat, false)
                                viewModel.audioManager.stopPlayback()
                                navController.popBackStack()
                            },
                            onOpenPeerProfile = { navController.navigate("peer/$chatId") },
                            onSendText = { text, reply, silent, delayMin ->
                                viewModel.sendText(chatId, text, reply, silent, delayMin)
                            },
                            onSendPhoto = { uri, caption, reply -> viewModel.sendPhoto(chatId, uri, caption, reply) },
                            onSendFile = { uri -> viewModel.sendFile(chatId, uri) },
                            onStartVoiceRecording = { hasMic -> viewModel.startVoiceRecording(hasMic) },
                            onFinishVoiceRecording = { save -> viewModel.finishVoiceRecording(chatId, save) },
                            onToggleVoicePlay = viewModel::toggleVoicePlay,
                            onSeekVoice = viewModel::seekVoice,
                            onCycleVoiceSpeed = viewModel::cycleVoiceSpeed,
                            onSendLocation = { label -> viewModel.sendLocation(chatId, label) },
                            onSendPoll = { q, opts -> viewModel.sendPoll(chatId, q, opts) },
                            onVotePoll = viewModel::votePoll,
                            onSendGift = { kind, asNft, comment ->
                                viewModel.sendGift(kind, asNft, chatId, comment)
                            },
                            onSendGram = { amount, note -> viewModel.sendGramInChat(chatId, amount, note) },
                            onForwardMessage = viewModel::forwardMessage,
                            onEditMessage = viewModel::editMessage,
                            onDeleteMessage = viewModel::deleteMessage,
                            onTogglePinMessage = { msgId -> viewModel.togglePinMessage(chatId, msgId) },
                            onToggleReaction = viewModel::toggleReaction,
                            onToggleBlockChat = { viewModel.toggleBlockChat(chatId) },
                            onToggleMuteChat = { viewModel.toggleMuteChat(chatId) },
                            onDraftChanged = { draft -> viewModel.saveDraft(chatId, draft) },
                            onTypingChanged = { isTyping -> viewModel.setTyping(chat, isTyping) },
                            onAddContact = { viewModel.addPeerToContacts(chatId) },
                            onStartCall = { isVideo -> chat?.let { viewModel.startCall(it, isVideo) } },
                            onShowToast = viewModel::showToast
                        )
                    }

                    composable(
                        route = "peer/{chatId}",
                        arguments = listOf(navArgument("chatId") { type = NavType.StringType })
                    ) { entry ->
                        val chatId = entry.arguments?.getString("chatId") ?: return@composable
                        val chat by viewModel.observeChat(chatId).collectAsState(initial = null)

                        PeerProfileScreen(
                            chat = chat,
                            starsBalance = account?.starsBalance ?: 0L,
                            onBack = { navController.popBackStack() },
                            onOpenChat = { navController.popBackStack() },
                            onToggleMute = { viewModel.toggleMuteChat(chatId) },
                            onToggleBlock = { viewModel.toggleBlockChat(chatId) },
                            onSetAutoDelete = { sec -> viewModel.setAutoDelete(chatId, sec) },
                            onStartSecretChat = {
                                viewModel.createGroupOrChannel(chat?.title ?: "Собеседник", false, true) { newId ->
                                    navController.navigate("chat/$newId")
                                }
                            },
                            onSendGift = { kind, asNft, comment ->
                                viewModel.sendGift(kind, asNft, chatId, comment)
                            },
                            onLoadPeerProfile = viewModel::fetchPeerProfile,
                            onAddToContacts = { viewModel.addPeerToContacts(chatId) },
                            onStartCall = { isVideo -> chat?.let { viewModel.startCall(it, isVideo) } },
                            onShowToast = viewModel::showToast
                        )
                    }

                    composable(
                        route = "settings_sub/{dest}",
                        arguments = listOf(navArgument("dest") { type = NavType.StringType })
                    ) { entry ->
                        val destName = entry.arguments?.getString("dest")
                        val dest = SettingsDestination.entries.firstOrNull { it.name == destName }
                            ?: SettingsDestination.ACCOUNT

                        LaunchedEffect(dest) {
                            if (dest == SettingsDestination.DATA_STORAGE) {
                                viewModel.refreshCacheSize()
                            } else if (dest == SettingsDestination.NFT_USERNAMES) {
                                viewModel.refreshFragmentMarket()
                            }
                        }

                        SettingsSubScreenRouter(
                            destination = dest,
                            account = account,
                            prefs = prefs,
                            folders = folders,
                            chats = chats,
                            nftUsernames = nftUsernames,
                            transactions = transactions,
                            onBack = { navController.popBackStack() },
                            onNavigate = { nextDest ->
                                navController.navigate("settings_sub/${nextDest.name}")
                            },
                            onUpdateProfile = viewModel::updateProfile,
                            onToggleNightMode = viewModel::toggleDarkMode,
                            onSetWallpaper = viewModel::setWallpaperTheme,
                            onSetTextSize = viewModel::setChatTextSize,
                            onSetAnimations = viewModel::setAnimationsEnabled,
                            onSetPowerSaving = viewModel::setPowerSaving,
                            onSetNotifications = viewModel::setNotifications,
                            onSetShowOnline = viewModel::setShowOnline,
                            onSetLanguage = viewModel::setLanguage,
                            onSaveFolder = viewModel::saveFolder,
                            onDeleteFolder = viewModel::deleteFolder,
                            onTopUpStars = viewModel::topUpStars,
                            onTopUpGram = viewModel::topUpGram,
                            onSwapGramToStars = viewModel::swapGramToStars,
                            onBuyNftUsername = viewModel::buyNftUsername,
                            onMintCustomNftUsername = viewModel::mintCustomNftUsername,
                            onToggleEquipNftUsername = viewModel::toggleEquipNftUsername,
                            onSendGiftToSelf = { kind, asNft, comment ->
                                viewModel.sendGift(kind, asNft, null, comment)
                            },
                            onActivatePremium = viewModel::activatePremium,
                            deviceSessions = deviceSessions,
                            cacheSizeBytes = cacheSizeBytes,
                            fragmentGiftListings = fragmentGiftListings,
                            onSetAutoDownloadWifi = viewModel::setAutoDownloadWifi,
                            onSetAutoDownloadMobile = viewModel::setAutoDownloadMobile,
                            onClearCache = viewModel::clearCache,
                            onTerminateSession = viewModel::terminateSession,
                            onBidNftUsername = viewModel::bidNftUsername,
                            onSellNftUsername = viewModel::sellNftUsername,
                            onCancelNftSale = viewModel::cancelNftSale,
                            onBuyFragmentGift = viewModel::buyFragmentGift,
                            onSetPasscodePin = viewModel::setPasscodePin
                        )
                    }
                }
            }

            activeCall?.let { call ->
                BackHandler { viewModel.endCall() }
                TelegramCallOverlay(
                    call = call,
                    onToggleMute = viewModel::toggleCallMute,
                    onToggleSpeaker = viewModel::toggleCallSpeaker,
                    onEndCall = viewModel::endCall
                )
            }

            if (isLoggedIn && isAppLocked && !prefs.passcodePin.isNullOrBlank()) {
                PasscodeLockOverlay(
                    expectedPin = prefs.passcodePin.orEmpty(),
                    onUnlocked = { isAppLocked = false }
                )
            }

            // Floating Toast Pill Banner
            AnimatedVisibility(
                visible = toastMessage != null,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(top = 12.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = Color(0xE61E2936),
                    shadowElevation = 6.dp
                ) {
                    Text(
                        text = toastMessage ?: "",
                        color = Color.White,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun PasscodeLockOverlay(
    expectedPin: String,
    onUnlocked: () -> Unit
) {
    BackHandler { /* keep lock screen active */ }
    var entered by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    val appendDigit: (String) -> Unit = { digit ->
        if (entered.length < 4) {
            val next = entered + digit
            entered = next
            errorMsg = null
            if (next.length == 4) {
                if (next == expectedPin) {
                    onUnlocked()
                } else {
                    errorMsg = "Неверный код-пароль"
                    entered = ""
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1A8AD8), Color(0xFF0E4B80))))
            .statusBarsPadding()
            .padding(horizontal = 32.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Rounded.Lock,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(44.dp)
        )
        Spacer(modifier = Modifier.height(14.dp))
        Text(
            text = "Введите код-пароль",
            color = Color.White,
            fontSize = 21.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(22.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            repeat(4) { idx ->
                val filled = idx < entered.length
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(if (filled) Color.White else Color.White.copy(alpha = 0.28f))
                )
            }
        }
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = errorMsg ?: "",
            color = if (errorMsg != null) Color(0xFFFFD1D1) else Color.Transparent,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
        )
        Spacer(modifier = Modifier.height(26.dp))

        val rows = listOf(
            listOf("1", "2", "3"),
            listOf("4", "5", "6"),
            listOf("7", "8", "9"),
            listOf("", "0", "DEL")
        )
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            rows.forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    row.forEach { key ->
                        when (key) {
                            "" -> Spacer(modifier = Modifier.size(72.dp))
                            "DEL" -> Box(
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(CircleShape)
                                    .clickable {
                                        if (entered.isNotEmpty()) entered = entered.dropLast(1)
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Rounded.Backspace,
                                    contentDescription = "Стереть",
                                    tint = Color.White,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                            else -> Surface(
                                shape = CircleShape,
                                color = Color.White.copy(alpha = 0.16f),
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(CircleShape)
                                    .clickable { appendDigit(key) }
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = key,
                                        color = Color.White,
                                        fontSize = 26.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
